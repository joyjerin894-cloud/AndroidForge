# PJ Techs Smart Home — Black & Gold Edition

Android smart-home UI prototype with custom colours, selectable opening animation and logo presets, customizable assistant/equipment names, music picker, and voice/text command demo.

## Build
Open this project in Android Studio or upload its files to the `PJTechsSmartHome_SmoothFast` project directory used by the AndroidForge GitHub Actions workflow. Commit the changes and run **Actions → Build Android APK**.

## Customization
Open **CUSTOMIZE PJ TECHS** in the dashboard to select the UI accent colour, background theme, one of 120 opening animation presets, and an opening logo. Save settings; the selected opening animation and logo are used the next time the app launches. Use **PREVIEW OPENING** to preview the selected style.

## Notes
This is a source ZIP; compilation has not been verified in this environment. Dashboard device toggles are demos until the ESP32 relay API is integrated. See `FEATURES_SHAPE.md` for details and limitations.

Boot audio: open Customization Settings, choose a local audio file, enable “Play selected audio when the app opens,” set the duration in seconds, and save. The app does not include copyrighted music; choose an audio file you have permission to use.

### Custom intro duration
In **CUSTOMIZE PJ TECHS**, set **CINEMATIC INTRO DURATION** from 1 to 30 seconds, then use **PREVIEW CINEMATIC OPENING + AUDIO** to preview it. Save settings to persist the duration. Select a boot audio file, enable playback, and set its separate duration (1–180 seconds) to preview audio with the intro.

### Custom opening logo image
Open Settings → Customization → **Choose Custom Logo Image** and select a PNG, JPG, or other supported image from your device. The app persists access to the selected image and uses it in the cinematic opening animation. Choose “Use text logo instead” to clear the custom image and return to the selected text brand. Preview the opening and save your other settings as usual.

### Slider controls
The customization screen includes sliders for cinematic intro duration (1–30 seconds), opening logo image size (50%–150%), and boot-audio playback duration (1–180 seconds). Values display live while sliding and persist with Save settings.


## Opening theme menu and liquid buttons
- Added a dedicated Opening Look theme menu: Gold Cinema, Ice Neon, Violet Galaxy, Crimson Beast, Emerald Pulse, Arctic Chrome, Solar Flare, and Midnight Blue.
- Selected theme is saved and applied to the cinematic opening/preview palette.
- Clickable app controls use Android ripple feedback with a soft press/rebound animation inspired by liquid-glass interactions.
