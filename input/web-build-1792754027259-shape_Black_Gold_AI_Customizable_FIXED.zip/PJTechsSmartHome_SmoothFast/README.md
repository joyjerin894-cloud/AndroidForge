# shape — Black Glass & Gold Smart Home

Native Kotlin Android project targeting Java/Kotlin JVM 17, intended for AndroidForge / GitHub Actions APK builds.

### UI
- Near-black glass panels, gold accents and fine metallic borders.
- Cinematic black-and-gold animated `shape` title card; tap to skip.
- Customizable assistant name, four equipment labels and accent palette.
- Add/connect ESP32 entry from the gold plus button and customization settings.

### Assistant and audio
- Typed command panel, speech recognition when available, and Android Text-to-Speech replies.
- Local rule-based assistant handles common smart-home intents and explains unsupported actions.
- Select an audio file from device storage for looping background music. The song “One Sun One Moon” is not included; select your own legally obtained copy.

### Build
Open the project root in Android Studio or upload the project files to GitHub with the Gradle structure preserved, then run the repository's Android APK workflow.

### Hardware integration status
This is a UI/demo baseline. Equipment toggles and assistant commands do not yet actuate real relays. The saved ESP32 address is a setup value only. Implement and secure a matching ESP32 API before connecting mains-voltage equipment. Do not expose an unauthenticated relay endpoint to the public internet.
