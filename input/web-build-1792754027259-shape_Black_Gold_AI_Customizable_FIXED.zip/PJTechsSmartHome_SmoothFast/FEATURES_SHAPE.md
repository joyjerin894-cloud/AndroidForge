# shape — Black Glass & Gold Edition

## Added in this update
- Custom assistant display name, saved locally.
- Four editable equipment names, saved locally.
- Accent palette choices: ice cyan, violet, gold, emerald, rose.
- Background music picker for a user-selected audio file, loop playback, and pause control.
- Black-and-gold cinematic glass intro with moving light curtains, floating particles, animated rings, metallic title reveal, and tap-to-skip.
- Assistant panel with typed commands, Android speech recognition when available, spoken responses using Android Text-to-Speech, command suggestions through prompts, and local offline responses.
- A gold `+` button and a settings-panel `+ ADD / CONNECT ESP32 DEVICE` action.
- ESP32 address is saved in app preferences for setup.

## Important limits
- The copyrighted song “One Sun One Moon” is not bundled. Use the music picker to select an audio file you are legally allowed to use on your device.
- The assistant is a local rule-based demo, not a connected large-language-model AI service.
- ESP32 address saving and UI device toggles do not yet send relay commands. Live control needs a matching authenticated HTTP/API endpoint in the ESP32 firmware, plus network error handling.
- The selected audio starts after the user picks a file; background playback is not configured as an Android foreground service.
