/*
 Electro / EDITH — ESP32-C3 Super Mini relay firmware
 IMPORTANT: Relay board control voltage and trigger polarity are unverified.
 Keep the relay module disconnected until its electrical interface is confirmed.
 Do not connect mains AC while testing.
*/
#include <WiFi.h>
#include <WebServer.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* AP_SSID = "Electro-ESP32";
const char* AP_PASSWORD = "electro123";

const uint8_t RELAY_PINS[4] = {4, 5, 6, 7};
// Common assumption only; verify before connecting relay inputs.
const bool ACTIVE_LOW = true;

WebServer server(80);
bool relayOn[4] = {false, false, false, false};
bool apMode = false;

void writeRelay(uint8_t i, bool on) {
  if (i >= 4) return;
  relayOn[i] = on;
  digitalWrite(RELAY_PINS[i], on ? (ACTIVE_LOW ? LOW : HIGH)
                                 : (ACTIVE_LOW ? HIGH : LOW));
}
void cors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
}
String statusJson() {
  String s = "{\"device\":\"Electro-ESP32\",\"mode\":\"";
  s += apMode ? "ap" : "wifi";
  s += "\",\"relays\":[";
  for (int i=0;i<4;i++) { if(i) s += ","; s += relayOn[i] ? "true" : "false"; }
  s += "]}";
  return s;
}
void root() {
  cors();
  String page = R"HTML(<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Electro</title><style>
body{font-family:Arial;background:#101010;color:#f4d27a;padding:20px}
.card{background:#1e1e1e;border:1px solid #665326;border-radius:16px;padding:15px;margin:12px 0}
button{padding:12px 20px;border:0;border-radius:10px;font-weight:bold;margin-right:8px}
.on{background:#e6bd55;color:#111}.off{background:#444;color:white}
</style></head><body><h1>ELECTRO</h1><p>Local relay control</p><div id="list"></div>
<script>
async function load(){try{let d=await(await fetch('/api/status')).json(),h='';
d.relays.forEach((v,i)=>h+=`<div class="card"><b>Light ${i+1}</b><p>${v?'ON':'OFF'}</p>
<button class="${v?'on':'off'}" onclick="setR(${i+1},'on')">ON</button>
<button class="${!v?'on':'off'}" onclick="setR(${i+1},'off')">OFF</button></div>`);
document.getElementById('list').innerHTML=h}catch(e){document.getElementById('list').innerText='Connection error'}}
async function setR(id,state){await fetch(`/api/relay?id=${id}&state=${state}`);load()}
load();setInterval(load,3000);
</script></body></html>)HTML";
  server.send(200, "text/html", page);
}
void statusRoute() { cors(); server.send(200, "application/json", statusJson()); }
void relayRoute() {
  cors();
  if (!server.hasArg("id") || !server.hasArg("state")) {
    server.send(400,"application/json","{\"ok\":false,\"error\":\"Use id=1..4 and state=on/off/toggle\"}"); return;
  }
  int id=server.arg("id").toInt();
  String state=server.arg("state"); state.toLowerCase();
  if(id<1 || id>4 || (state!="on" && state!="off" && state!="toggle")) {
    server.send(400,"application/json","{\"ok\":false,\"error\":\"Invalid relay id or state\"}"); return;
  }
  bool next = state=="toggle" ? !relayOn[id-1] : state=="on";
  writeRelay(id-1,next);
  server.send(200,"application/json",
    String("{\"ok\":true,\"id\":")+id+",\"on\":"+(next?"true":"false")+"}");
}
void optionsRoute(){ cors(); server.send(204); }
void startAP() {
  apMode=true; WiFi.mode(WIFI_AP); WiFi.softAP(AP_SSID,AP_PASSWORD);
  Serial.print("AP address: "); Serial.println(WiFi.softAPIP());
}
void setup() {
  Serial.begin(115200); delay(200);
  for(int i=0;i<4;i++){ pinMode(RELAY_PINS[i],OUTPUT); digitalWrite(RELAY_PINS[i],ACTIVE_LOW?HIGH:LOW); }
  WiFi.mode(WIFI_STA); WiFi.begin(WIFI_SSID,WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  unsigned long t=millis();
  while(WiFi.status()!=WL_CONNECTED && millis()-t<15000){delay(300);Serial.print(".");}
  Serial.println();
  if(WiFi.status()==WL_CONNECTED){apMode=false;Serial.print("Device IP: ");Serial.println(WiFi.localIP());}
  else {Serial.println("Starting Electro AP");startAP();}
  server.on("/",HTTP_GET,root);
  server.on("/api/status",HTTP_GET,statusRoute);
  server.on("/api/relay",HTTP_GET,relayRoute);
  server.on("/api/relay",HTTP_POST,relayRoute);
  server.on("/api/status",HTTP_OPTIONS,optionsRoute);
  server.on("/api/relay",HTTP_OPTIONS,optionsRoute);
  server.onNotFound([](){cors();server.send(404,"application/json","{\"ok\":false,\"error\":\"Not found\"}");});
  server.begin(); Serial.println("Electro server ready");
}
void loop(){ server.handleClient(); }
