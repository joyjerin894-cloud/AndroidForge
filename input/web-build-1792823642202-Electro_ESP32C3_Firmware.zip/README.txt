ELECTRO / EDITH — ESP32-C3 firmware

SAFETY FIRST
The photos do not verify the relay board's control input voltage or trigger polarity.
Keep relay power and IN wires disconnected until confirmed from its product listing/schematic.
Do not connect mains AC during testing. Do not put 12 V on an ESP32 GPIO or 3.3 V pin.

SETUP
1. Install Arduino IDE and Espressif's ESP32 board package.
2. Open Electro_ESP32C3.ino and select an ESP32-C3 board profile.
3. Replace YOUR_WIFI_NAME and YOUR_WIFI_PASSWORD.
4. Upload while the relay module is disconnected.
5. Open Serial Monitor at 115200 baud.
6. If home Wi-Fi fails, the board creates Electro-ESP32 (password electro123), usually at http://192.168.4.1.
   Otherwise use the IP printed in Serial Monitor.

PROVISIONAL GPIO MAP
GPIO4 -> IN1 (Light 1)
GPIO5 -> IN2 (Light 2)
GPIO6 -> IN3 (Light 3)
GPIO7 -> IN4 (Light 4)

The sketch assumes ACTIVE_LOW=true, a common arrangement, but this is NOT confirmed.
Verify the relay board's control circuit before connecting it; change ACTIVE_LOW only after safe verification.

APP HTTP API
GET /api/status
GET /api/relay?id=1&state=on
GET /api/relay?id=1&state=off
GET /api/relay?id=1&state=toggle
IDs 1–4 map to GPIO4–GPIO7. The sketch includes a basic browser test page.
This does not modify your existing Android APK. To integrate the native Electro app, its source code/project is needed.
