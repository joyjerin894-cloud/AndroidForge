# PJ TECHS opening animation

This version uses an original, high-energy South Indian action-cinema mood: neon cyan/violet/pink beams, floating sparks, a rotating energy ring, metallic lettering, short glitch accents, frame brackets and a timed impact flash. It is inspired by broad action-title-card techniques, not a recreation of the *Beast* film title, its exact animation, footage, or soundtrack.

The intro is drawn at runtime using Android Canvas at the phone's screen resolution, lasts about 5.2 seconds, and can be skipped by tapping. No movie footage or copyrighted soundtrack is bundled.
