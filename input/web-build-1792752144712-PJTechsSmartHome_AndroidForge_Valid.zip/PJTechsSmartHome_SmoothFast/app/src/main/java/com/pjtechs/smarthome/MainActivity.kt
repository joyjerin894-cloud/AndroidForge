package com.pjtechs.smarthome

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.*
import android.animation.ValueAnimator
import android.view.View
import android.view.Gravity
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import kotlin.math.abs
import kotlin.math.sin

private const val BG = 0xFF080B16.toInt()
private const val PANEL = 0xFF151B2D.toInt()
private const val WHITE = 0xFFF4F7FF.toInt()
private const val MUTED = 0xFF9CA8C5.toInt()
private const val CYAN = 0xFF30E7F2.toInt()
private const val VIOLET = 0xFF9B6BFF.toInt()
private const val PINK = 0xFFFF4D91.toInt()
private const val AMBER = 0xFFFFB454.toInt()

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = 0
        setContentView(CinematicSplash(this) { showDashboard() })
    }

    private fun showDashboard() {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        val scroll = ScrollView(this).apply { clipToPadding = false; isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(26))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF11172B.toInt(), BG, BG))
        }
        scroll.addView(root)
        page.addView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = "PJ"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(BG)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(CYAN, VIOLET)).apply { cornerRadius = dp(15).toFloat() }
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val brandCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, 0, 0) }
        brandCol.addView(label("PJ TECHS", 20f, WHITE, true))
        brandCol.addView(label("SMART LIVING SYSTEM", 9f, CYAN, true).apply { letterSpacing = .14f; setPadding(0, dp(2), 0, 0) })
        top.addView(brandCol, LinearLayout.LayoutParams(0, wrap, 1f))
        val profile = TextView(this).apply { text = "✦"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(AMBER); background = rounded(0xFF20243A.toInt(), 16) }
        top.addView(profile, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(top)

        root.addView(label("YOUR SPACE. YOUR RULES.", 11f, MUTED, true).apply { letterSpacing = .18f; setPadding(0, dp(25), 0, dp(7)) })
        root.addView(label("Welcome back 👋", 28f, WHITE, true))
        root.addView(label("Make every moment feel just right.", 13f, MUTED).apply { setPadding(0, dp(5), 0, dp(18)) })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(19), dp(18), dp(18), dp(17))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF22214A.toInt(), 0xFF172E48.toInt(), 0xFF172036.toInt())).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), 0x665D8DFF) }
        }
        val heroTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val live = TextView(this).apply { text = "● SYSTEM ONLINE"; textSize = 10f; letterSpacing = .08f; setTextColor(CYAN); background = rounded(0x3330E7F2, 20); setPadding(dp(10), dp(7), dp(10), dp(7)) }
        heroTop.addView(live)
        val spacer = Space(this); heroTop.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        heroTop.addView(label("⌁", 26f, VIOLET, true))
        hero.addView(heroTop)
        hero.addView(label("A smarter home\nstarts here.", 26f, WHITE, true).apply { setPadding(0, dp(15), 0, dp(7)) })
        hero.addView(label("Control your lights and connected devices from one beautiful dashboard.", 12f, 0xFFBAC7E3.toInt()))
        val heroButton = TextView(this).apply {
            text = "  EXPLORE CONTROLS     ↗"; textSize = 11f; letterSpacing = .05f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BG); gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(CYAN, 0xFF8AF7DB.toInt())).apply { cornerRadius = dp(13).toFloat() }
            setPadding(dp(13), 0, dp(13), 0); setOnClickListener { Toast.makeText(this@MainActivity, "Choose a device below", Toast.LENGTH_SHORT).show() }
        }
        hero.addView(heroButton, LinearLayout.LayoutParams(wrap, dp(42)).apply { topMargin = dp(17) })
        root.addView(hero, lp(match, wrap, 0, 0, 0, 24))

        val section = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        section.addView(label("QUICK CONTROL", 13f, WHITE, true))
        section.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        section.addView(label("4 DEVICES", 10f, MUTED, true))
        root.addView(section, lp(match, wrap, 0, 0, 0, 12))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(deviceCard("☼", "Living room", "MAIN LIGHT", true, CYAN), LinearLayout.LayoutParams(0, dp(144), 1f).apply { marginEnd = dp(7) })
        row1.addView(deviceCard("◒", "Bedroom", "AMBIENT", false, VIOLET), LinearLayout.LayoutParams(0, dp(144), 1f).apply { marginStart = dp(7) })
        row2.addView(deviceCard("✣", "Ceiling fan", "RELAY 02", false, AMBER), LinearLayout.LayoutParams(0, dp(144), 1f).apply { marginEnd = dp(7) })
        row2.addView(deviceCard("▣", "Accent strip", "RGB PIXELS", true, PINK), LinearLayout.LayoutParams(0, dp(144), 1f).apply { marginStart = dp(7) })
        root.addView(row1); root.addView(row2, lp(match, wrap, 0, 13, 0, 22))

        val voice = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF27203F.toInt(), 0xFF182A42.toInt())).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), 0x559B6BFF) }
            setOnClickListener { showCommands() }
        }
        val mic = TextView(this).apply { text = "◉"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(VIOLET); background = rounded(0x332F2A5D, 15) }
        voice.addView(mic, LinearLayout.LayoutParams(dp(50), dp(50)))
        val voiceCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        voiceCol.addView(label("Talk to JIVA", 16f, WHITE, true))
        voiceCol.addView(label("Tap to view voice commands", 11f, MUTED).apply { setPadding(0, dp(3), 0, 0) })
        voice.addView(voiceCol, LinearLayout.LayoutParams(0, wrap, 1f))
        voice.addView(label("↗", 20f, CYAN, true))
        root.addView(voice, lp(match, wrap, 0, 0, 0, 15))

        val connect = TextView(this).apply {
            text = "⚙   CONNECT ESP32"; textSize = 12f; letterSpacing = .06f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; setTextColor(WHITE)
            background = GradientDrawable().apply { setColor(0xFF20263A.toInt()); cornerRadius = dp(15).toFloat(); setStroke(dp(1), 0xFF38445F.toInt()) }
            setOnClickListener { showConnectionDialog() }
        }
        root.addView(connect, lp(match, dp(52)))
        root.addView(label("PJ TECHS  •  BUILT FOR YOUR HOME", 9f, 0xFF6D7895.toInt(), true).apply { gravity = Gravity.CENTER; letterSpacing = .12f; setPadding(0, dp(18), 0, 0) })
        setContentView(page)
    }

    private fun deviceCard(icon: String, title: String, subtitle: String, initiallyOn: Boolean, accent: Int): View {
        var on = initiallyOn
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(12), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF1A2034.toInt(), 0xFF111727.toInt())).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), if (initiallyOn) (accent and 0x00FFFFFF) or 0x66000000 else 0xFF27304A.toInt()) }
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val glyph = TextView(this).apply { text = icon; textSize = 28f; gravity = Gravity.CENTER; setTextColor(accent); background = rounded(0x332B4260, 14) }
        top.addView(glyph, LinearLayout.LayoutParams(dp(49), dp(49)))
        top.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        val dot = TextView(this).apply { text = if (on) "●" else "○"; textSize = 13f; setTextColor(if (on) accent else MUTED) }
        top.addView(dot)
        box.addView(top)
        box.addView(label(title, 14f, WHITE, true).apply { setPadding(0, dp(12), 0, dp(3)) })
        val sub = label(if (on) "ON  •  $subtitle" else "OFF  •  $subtitle", 9f, if (on) accent else MUTED, true).apply { letterSpacing = .03f }
        box.addView(sub)
        box.setOnClickListener {
            on = !on; dot.text = if (on) "●" else "○"; dot.setTextColor(if (on) accent else MUTED)
            sub.text = (if (on) "ON  •  " else "OFF  •  ") + subtitle; sub.setTextColor(if (on) accent else MUTED)
            Toast.makeText(this, "$title ${if (on) "on" else "off"} (demo only)", Toast.LENGTH_SHORT).show()
        }
        return box
    }

    private fun showCommands() {
        val items = arrayOf("JIVA, turn on living room light", "JIVA, turn off bedroom light", "JIVA, turn on fan", "JIVA, all lights off")
        AlertDialog.Builder(this).setTitle("JIVA • Voice commands")
            .setItems(items) { _, which -> Toast.makeText(this, "Sample command: ${items[which]}", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Close", null).show()
    }

    private fun showConnectionDialog() {
        val input = EditText(this).apply { hint = "http://192.168.1.50"; setTextColor(WHITE); setHintTextColor(MUTED); setSingleLine(true) }
        val holder = LinearLayout(this).apply { setPadding(dp(22), dp(8), dp(22), 0); addView(input) }
        AlertDialog.Builder(this).setTitle("Connect ESP32")
            .setMessage("Enter the local IP shown by your ESP32 firmware. This build has a visual demo interface; relay API integration is not enabled yet.")
            .setView(holder).setPositiveButton("Save for setup") { _, _ ->
                val address = input.text.toString().trim()
                Toast.makeText(this, if (address.isBlank()) "No address entered" else "Address entered: $address", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun lp(w: Int, h: Int, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val match get() = LinearLayout.LayoutParams.MATCH_PARENT
    private val wrap get() = LinearLayout.LayoutParams.WRAP_CONTENT

    /** Original high-energy action-film title reveal: neon streaks, RGB glitch, particles and impact flash. */
    private class CinematicSplash(activity: MainActivity, val done: () -> Unit) : View(activity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var progress = 0f
        private val cyan = CYAN
        private val violet = VIOLET
        private val pink = PINK
        private val particleX = FloatArray(56) { ((it * 83 + 37) % 997) / 997f }
        private val particleY = FloatArray(56) { ((it * 149 + 13) % 991) / 991f }
        private val particleSize = FloatArray(56) { 1f + ((it * 11) % 4) }
        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2850L; interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { if (!finished) { finished = true; done() } }
            })
        }
        private var finished = false
        init {
            // Keep drawing on Android's GPU pipeline; software rendering caused avoidable jank.
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            post { if (isAttachedToWindow && !finished) animator.start() }
            setOnClickListener { finishNow() }
        }
        private fun finishNow() {
            if (finished) return
            finished = true
            if (animator.isRunning) animator.cancel()
            done()
        }
        override fun onDetachedFromWindow() {
            if (animator.isRunning) animator.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2f; val cy = h * .445f
            canvas.drawColor(0xFF050711.toInt())
            p.shader = RadialGradient(cx, cy, w * .88f, intArrayOf(0xFF1A1640.toInt(), 0xFF10172B.toInt(), 0xFF050711.toInt()), floatArrayOf(0f, .48f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            // Diagonal animated neon beams
            for (i in 0..4) {
                val drift = (progress * 1.4f + i * .21f) % 1.6f
                val x = w * (drift - .3f)
                p.shader = LinearGradient(x - w*.20f, 0f, x + w*.20f, h, intArrayOf(0x00000000, if (i % 2 == 0) 0x2230E7F2 else 0x229B6BFF, 0x00000000), null, Shader.TileMode.CLAMP)
                canvas.save(); canvas.rotate(-13f, cx, cy); canvas.drawRect(x-w*.20f, 0f, x+w*.20f, h, p); canvas.restore(); p.shader = null
            }
            // Floating sparks
            for (i in particleX.indices) {
                val x = particleX[i] * w + sin(progress * 7f + i).toFloat() * w * .018f
                val y = h * (1f - ((particleY[i] + progress * (.22f + (i % 6) * .025f)) % 1f))
                val flicker = .25f + .75f * abs(sin(progress * 18f + i)).toFloat()
                p.color = when (i % 3) { 0 -> cyan; 1 -> violet; else -> pink }; p.alpha = (210 * flicker).toInt()
                canvas.drawCircle(x, y, dp(particleSize[i].toInt().coerceAtLeast(1)).toFloat() * flicker, p)
            }
            p.alpha = 255
            // Thin sci-fi frame brackets
            val frame = ((progress - .05f) / .28f).coerceIn(0f, 1f)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat(); p.color = cyan; p.alpha = (155 * frame).toInt()
            val inset = w * (.10f + .04f * (1f-frame))
            val top = h * .20f; val bottom = h * .72f; val len = w * .15f * frame
            canvas.drawLine(inset, top, inset+len, top, p); canvas.drawLine(inset, top, inset, top+len, p)
            canvas.drawLine(w-inset, top, w-inset-len, top, p); canvas.drawLine(w-inset, top, w-inset, top+len, p)
            canvas.drawLine(inset, bottom, inset+len, bottom, p); canvas.drawLine(inset, bottom, inset, bottom-len, p)
            canvas.drawLine(w-inset, bottom, w-inset-len, bottom, p); canvas.drawLine(w-inset, bottom, w-inset, bottom-len, p)
            p.style = Paint.Style.FILL; p.alpha = 255
            // Orbiting energy ring
            val reveal = ((progress - .10f) / .36f).coerceIn(0f, 1f)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.color = cyan; p.alpha = (210*reveal).toInt(); p.setShadowLayer(dp(10).toFloat(), 0f, 0f, cyan)
            canvas.drawArc(cx-w*.31f, cy-w*.31f, cx+w*.31f, cy+w*.31f, -105f + progress*90f, 275f*reveal, false, p)
            p.clearShadowLayer(); p.color = violet; p.alpha = (155*reveal).toInt(); p.strokeWidth = dp(1).toFloat()
            canvas.drawArc(cx-w*.34f, cy-w*.34f, cx+w*.34f, cy+w*.34f, 75f-progress*110f, 100f*reveal, false, p)
            p.style = Paint.Style.FILL; p.alpha = 255
            // Impact flash and horizontal glitch slices
            val flash = if (progress in .40f.. .48f) 1f - abs(progress-.44f)/.04f else 0f
            if (flash > 0f) { p.color = 0xFFDAFFFF.toInt(); p.alpha = (flash*85).toInt(); canvas.drawRect(0f,0f,w,h,p); p.alpha=255 }
            val titleAlpha = ((progress-.24f)/.28f).coerceIn(0f,1f)
            val scale = (.72f + .28f * DecelerateInterpolator().getInterpolation(titleAlpha)) * (if (progress in .39f.. .52f) 1f + .018f*(1f-abs(progress-.455f)/.065f) else 1f)
            canvas.save(); canvas.scale(scale, scale, cx, cy)
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD); p.textSize = w*.135f
            p.color = pink; p.alpha = (170*titleAlpha).toInt(); p.setShadowLayer(dp(12).toFloat(), 0f, 0f, pink); canvas.drawText("PJ TECHS", cx+dp(2), cy+dp(8), p); p.clearShadowLayer()
            p.shader = LinearGradient(cx, cy-w*.10f, cx, cy+w*.02f, intArrayOf(0xFFFFFFFF.toInt(), 0xFFBDFBFF.toInt(), 0xFF7188FF.toInt(), 0xFFF4F7FF.toInt()), null, Shader.TileMode.CLAMP)
            p.alpha = (255*titleAlpha).toInt(); canvas.drawText("PJ TECHS", cx, cy+dp(5), p); p.shader = null
            // Short glitch bars shift in and out around the title
            if (progress in .37f.. .57f) {
                val gp = (progress-.37f)/.20f
                p.alpha = (140*(1f-abs(gp-.5f)*2f)).toInt(); p.color = cyan
                canvas.drawRect(cx-w*.37f, cy-w*.075f, cx-w*.20f, cy-w*.068f, p)
                p.color = pink; canvas.drawRect(cx+w*.19f, cy+w*.015f, cx+w*.36f, cy+w*.022f, p)
            }
            canvas.restore(); p.alpha = 255
            val line = ((progress-.51f)/.16f).coerceIn(0f,1f)
            p.shader = LinearGradient(cx-w*.28f, cy+w*.105f, cx+w*.28f, cy+w*.105f, intArrayOf(0x0030E7F2, cyan, violet, 0x00FF4D91), null, Shader.TileMode.CLAMP)
            canvas.drawRect(cx-w*.28f, cy+w*.105f, cx-w*.28f+w*.56f*line, cy+w*.109f, p); p.shader = null
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); p.textSize = w*.027f; p.color = WHITE
            p.alpha = (235*((progress-.56f)/.19f).coerceIn(0f,1f)).toInt(); canvas.drawText("SMART HOME  •  NEXT-LEVEL CONTROL", cx, cy+w*.17f, p)
            p.textSize = w*.026f; p.color = cyan; p.alpha = (230*((progress-.70f)/.18f).coerceIn(0f,1f)).toInt(); canvas.drawText("POWERED BY JIVA", cx, h*.82f, p)
            p.textSize = w*.023f; p.color = 0xFFB6C2DE.toInt(); p.alpha = (145*(1f-progress)).toInt(); canvas.drawText("TAP TO ENTER", cx, h*.92f, p)
            p.alpha = 255
        }
        private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    }
}
