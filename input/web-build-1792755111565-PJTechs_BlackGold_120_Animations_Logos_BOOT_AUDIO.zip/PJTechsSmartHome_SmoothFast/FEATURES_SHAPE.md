# PJ Techs Smart Home — Black & Gold Customizable Build

## Included in this source ZIP
- Black and gold dashboard styling with configurable accent colour.
- UI background presets: Obsidian Black, Midnight Blue, Forest Black, Plum Black, Warm Charcoal, and Slate.
- 120 selectable opening-animation presets. The selected preset affects the opening splash animation's palette, ring motion, and timing.
- Opening-logo menu with PJ TECHS, PJ, SHAPE, JIVA, NOVA, ONYX, AURA, PULSE, VOLT, LUX, NEXUS, ORBIT, PHANTOM, BEAST, APEX, and INFINITY. Selected logo is used in the opening and dashboard brand.
- Preview Opening control in customization settings.
- Custom assistant name and four equipment labels.
- Local audio file picker with looping background playback.
- Voice input, typed local command recognition, and Android text-to-speech.
- Main dashboard ESP32 connect button and plus shortcut removed.

## Important limitations
- This ZIP is source code, not a compiled APK. Run the GitHub Actions build to verify compilation.
- The 120 animation entries are preset variations built from shared animation effects; they are not 120 completely unrelated animation engines.
- Device tiles remain demo controls. Live relay control requires an ESP32 HTTP/API integration and matching firmware.
- The assistant uses Android speech recognition and local command matching; it is not a full cloud AI assistant.

## Boot audio customization
- Settings include a separate boot-audio picker for a user-owned audio file (for example, a legally obtained copy of “One Sun One Moon”).
- Enable or disable boot audio independently from background music.
- Set the playback duration from 1 to 180 seconds; playback begins when the app opens, alongside the opening animation, and pauses after the selected duration.
- The audio file is selected on the device and is not bundled with the project.
