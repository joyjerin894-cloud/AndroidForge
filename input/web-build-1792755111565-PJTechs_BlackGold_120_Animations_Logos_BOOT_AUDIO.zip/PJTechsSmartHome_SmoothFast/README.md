# PJ Techs Smart Home — Black & Gold Edition

Android smart-home UI prototype with custom colours, selectable opening animation and logo presets, customizable assistant/equipment names, music picker, and voice/text command demo.

## Build
Open this project in Android Studio or upload its files to the `PJTechsSmartHome_SmoothFast` project directory used by the AndroidForge GitHub Actions workflow. Commit the changes and run **Actions → Build Android APK**.

## Customization
Open **CUSTOMIZE PJ TECHS** in the dashboard to select the UI accent colour, background theme, one of 120 opening animation presets, and an opening logo. Save settings; the selected opening animation and logo are used the next time the app launches. Use **PREVIEW OPENING** to preview the selected style.

## Notes
This is a source ZIP; compilation has not been verified in this environment. Dashboard device toggles are demos until the ESP32 relay API is integrated. See `FEATURES_SHAPE.md` for details and limitations.

Boot audio: open Customization Settings, choose a local audio file, enable “Play selected audio when the app opens,” set the duration in seconds, and save. The app does not include copyrighted music; choose an audio file you have permission to use.
