package com.pjtechs.smarthome

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.*
import android.animation.ValueAnimator
import android.view.View
import android.view.Gravity
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.content.Intent
import android.net.Uri
import android.media.MediaPlayer
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

private const val BG = 0xFF050607.toInt()
private const val PANEL = 0x66303036.toInt()
private const val GLASS_EDGE = 0x889DAAB8.toInt()
private const val GLASS_FILL = 0x332C333D.toInt()
private const val WHITE = 0xFFF5F6F8.toInt()
private const val MUTED = 0xFF9BA3AD.toInt()
private const val CYAN = 0xFF8DEBFF.toInt()
private const val VIOLET = 0xFFB4A5FF.toInt()
private const val PINK = 0xFFB8C4D1.toInt()
private const val AMBER = 0xFFD5DCE5.toInt()

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("shape_settings", MODE_PRIVATE) }
    private var accent = 0xFFFFC56A.toInt()
    private var uiBackground = 0xFF050505.toInt()
    private var animationStyle = 0
    private var openingLogo = "PJ TECHS"
    private var musicPlayer: MediaPlayer? = null
    private var musicUri: Uri? = null
    private var bootAudioPlayer: MediaPlayer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var stopBootAudioTask: Runnable? = null
    private var tts: TextToSpeech? = null
    private var assistantName: String = "JIVA"
    private val equipmentDefaults = arrayOf("Living room", "Bedroom", "Ceiling fan", "Accent strip")
    private var assistantInput: EditText? = null

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == 7002) {
            val spoken = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            assistantInput?.setText(spoken)
            if (spoken.isNotBlank()) handleAssistantCommand(spoken)
            return
        }
        val selectedUri = data.data ?: return
        if (requestCode == 7001) {
            musicUri = selectedUri
            prefs.edit().putString("music_uri", musicUri.toString()).apply()
            try {
                musicPlayer?.release()
                musicPlayer = MediaPlayer().apply {
                    setDataSource(this@MainActivity, musicUri!!)
                    isLooping = true
                    setOnPreparedListener { it.start(); Toast.makeText(this@MainActivity, "Background music playing", Toast.LENGTH_SHORT).show() }
                    setOnErrorListener { _, _, _ -> Toast.makeText(this@MainActivity, "Could not play this audio file", Toast.LENGTH_SHORT).show(); true }
                    prepareAsync()
                }
            } catch (_: Exception) { Toast.makeText(this, "Could not open this audio file", Toast.LENGTH_SHORT).show() }
        } else if (requestCode == 7003) {
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(selectedUri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            prefs.edit().putString("boot_audio_uri", selectedUri.toString()).apply()
            Toast.makeText(this, "Boot audio selected. Enable it and save settings.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        musicPlayer?.release(); musicPlayer = null
        stopBootAudioTask?.let { mainHandler.removeCallbacks(it) }
        bootAudioPlayer?.release(); bootAudioPlayer = null
        tts?.shutdown(); tts = null
        super.onDestroy()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assistantName = prefs.getString("assistant_name", "JIVA") ?: "JIVA"
        accent = prefs.getInt("accent_color", 0xFFFFC56A.toInt())
        uiBackground = prefs.getInt("ui_background", 0xFF050505.toInt())
        animationStyle = prefs.getInt("opening_animation", 0)
        openingLogo = prefs.getString("opening_logo", "PJ TECHS") ?: "PJ TECHS"
        window.statusBarColor = uiBackground
        window.navigationBarColor = uiBackground
        window.decorView.systemUiVisibility = 0
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
        setContentView(CinematicSplash(this, animationStyle, openingLogo, accent, uiBackground) { showDashboard() })
        playBootAudioIfEnabled()
    }

    private fun playBootAudioIfEnabled() {
        if (!prefs.getBoolean("boot_audio_enabled", false)) return
        val uriText = prefs.getString("boot_audio_uri", null) ?: return
        val seconds = prefs.getInt("boot_audio_seconds", 8).coerceIn(1, 180)
        try {
            stopBootAudioTask?.let { mainHandler.removeCallbacks(it) }
            bootAudioPlayer?.release()
            bootAudioPlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, Uri.parse(uriText))
                isLooping = true
                setOnPreparedListener { player ->
                    player.start()
                    stopBootAudioTask = Runnable { try { if (player.isPlaying) player.pause(); player.seekTo(0) } catch (_: Exception) {} }
                    mainHandler.postDelayed(stopBootAudioTask!!, seconds * 1000L)
                }
                setOnErrorListener { _, _, _ -> Toast.makeText(this@MainActivity, "Unable to play boot audio. Select the file again in Settings.", Toast.LENGTH_LONG).show(); true }
                prepareAsync()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Boot audio unavailable. Select the audio file again in Settings.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showDashboard() {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(uiBackground) }
        val scroll = ScrollView(this).apply { clipToPadding = false; isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(26))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(uiBackground, 0xFF17130D.toInt(), 0xFF080808.toInt()))
        }
        scroll.addView(root)
        page.addView(scroll)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = openingLogo.take(2); textSize = 16f; gravity = Gravity.CENTER; setTextColor(BG)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFFE2A0.toInt(), 0xFF9A671F.toInt())).apply { cornerRadius = dp(15).toFloat() }
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val brandCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, 0, 0) }
        brandCol.addView(label(openingLogo.lowercase(Locale.ROOT), 20f, WHITE, true))
        brandCol.addView(label("BLACK & GOLD SMART LIVING", 9f, accent, true).apply { letterSpacing = .14f; setPadding(0, dp(2), 0, 0) })
        top.addView(brandCol, LinearLayout.LayoutParams(0, wrap, 1f))
        val profile = TextView(this).apply { text = "✦"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(AMBER); background = glass(0x44373B42, 16, 0x66D9E3EF) }
        top.addView(profile, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(top)

        root.addView(label("YOUR SPACE. YOUR RULES.", 11f, MUTED, true).apply { letterSpacing = .18f; setPadding(0, dp(25), 0, dp(7)) })
        root.addView(label("Welcome back 👋", 28f, WHITE, true))
        root.addView(label("Make every moment feel just right.", 13f, MUTED).apply { setPadding(0, dp(5), 0, dp(18)) })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(19), dp(18), dp(18), dp(17))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x553F454E.toInt(), 0x44303640.toInt(), 0x33212630.toInt())).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), 0x889DAAB8.toInt()) }
        }
        val heroTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val live = TextView(this).apply { text = "● SYSTEM ONLINE"; textSize = 10f; letterSpacing = .08f; setTextColor(accent); background = rounded(0x334C3A1B, 20); setPadding(dp(10), dp(7), dp(10), dp(7)) }
        heroTop.addView(live)
        val spacer = Space(this); heroTop.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        heroTop.addView(label("⌁", 26f, accent, true))
        hero.addView(heroTop)
        hero.addView(label("A smarter home\nstarts here.", 26f, WHITE, true).apply { setPadding(0, dp(15), 0, dp(7)) })
        hero.addView(label("Control your lights and connected devices from one beautiful dashboard.", 12f, 0xFFC3CAD2.toInt()))
        val heroButton = TextView(this).apply {
            text = "  EXPLORE CONTROLS     ↗"; textSize = 11f; letterSpacing = .05f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BG); gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFFFE5A3.toInt(), 0xFFC18A36.toInt())).apply { cornerRadius = dp(13).toFloat() }
            setPadding(dp(13), 0, dp(13), 0); setOnClickListener { Toast.makeText(this@MainActivity, "Choose a device below", Toast.LENGTH_SHORT).show() }
        }
        hero.addView(heroButton, LinearLayout.LayoutParams(wrap, dp(42)).apply { topMargin = dp(17) })
        root.addView(hero, lp(match, wrap, 0, 0, 0, 24))

        val section = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        section.addView(label("QUICK CONTROL", 13f, WHITE, true))
        section.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        section.addView(label("4 DEVICES", 10f, MUTED, true))
        root.addView(section, lp(match, wrap, 0, 0, 0, 12))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(deviceCard("☼", equipmentName(0), "MAIN LIGHT", true, accent), LinearLayout.LayoutParams(0, dp(144), 1f).apply { marginEnd = dp(7) })
        row1.addView(deviceCard("◒", equipmentName(1), "AMBIENT", false, accent), LinearLayout.LayoutParams(0, dp(144), 1f).apply { marginStart = dp(7) })
        row2.addView(deviceCard("✣", equipmentName(2), "RELAY 02", false, accent), LinearLayout.LayoutParams(0, dp(144), 1f).apply { marginEnd = dp(7) })
        row2.addView(deviceCard("▣", equipmentName(3), "RGB PIXELS", true, accent), LinearLayout.LayoutParams(0, dp(144), 1f).apply { marginStart = dp(7) })
        root.addView(row1); root.addView(row2, lp(match, wrap, 0, 13, 0, 22))

        val voice = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0x55404750.toInt(), 0x4430353D.toInt())).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), 0x8899D9FF.toInt()) }
            setOnClickListener { showCommands() }
        }
        val mic = TextView(this).apply { text = "◉"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(accent); background = rounded(0x334C3A1B, 15) }
        voice.addView(mic, LinearLayout.LayoutParams(dp(50), dp(50)))
        val voiceCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        voiceCol.addView(label("Talk to $assistantName", 16f, WHITE, true))
        voiceCol.addView(label("Tap to view voice commands", 11f, MUTED).apply { setPadding(0, dp(3), 0, 0) })
        voice.addView(voiceCol, LinearLayout.LayoutParams(0, wrap, 1f))
        voice.addView(label("↗", 20f, accent, true))
        root.addView(voice, lp(match, wrap, 0, 0, 0, 15))

        // ESP32 connect control removed from the main dashboard as requested.
        val settingsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val settings = TextView(this).apply {
            text = "⚙  CUSTOMIZE PJ TECHS"; textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; setTextColor(WHITE)
            background = glass(0x332D3036, 15, 0x887D8794.toInt()); setOnClickListener { showSettingsDialog() }
        }
        settingsRow.addView(settings, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(8) })
        root.addView(settingsRow)
        root.addView(label("shape  •  BLACK GLASS / GOLD EDITION", 9f, 0xFF9299A3.toInt(), true).apply { gravity = Gravity.CENTER; letterSpacing = .12f; setPadding(0, dp(18), 0, 0) })
        setContentView(page)
    }

    private fun deviceCard(icon: String, title: String, subtitle: String, initiallyOn: Boolean, accent: Int): View {
        var on = initiallyOn
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(12), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (initiallyOn) (accent and 0x00FFFFFF) or 0x44303A50 else 0x4432363D, 0x2221262D)).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), if (initiallyOn) (accent and 0x00FFFFFF) or 0x99000000.toInt() else 0x669DAAB8.toInt()) }
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val glyph = TextView(this).apply { text = icon; textSize = 28f; gravity = Gravity.CENTER; setTextColor(accent); background = rounded(0x33424852, 14) }
        top.addView(glyph, LinearLayout.LayoutParams(dp(49), dp(49)))
        top.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        val dot = TextView(this).apply { text = if (on) "●" else "○"; textSize = 13f; setTextColor(if (on) accent else MUTED) }
        top.addView(dot)
        box.addView(top)
        box.addView(label(title, 14f, WHITE, true).apply { setPadding(0, dp(12), 0, dp(3)) })
        val sub = label(if (on) "ON  •  $subtitle" else "OFF  •  $subtitle", 9f, if (on) accent else MUTED, true).apply { letterSpacing = .03f }
        box.addView(sub)
        box.setOnClickListener {
            on = !on; dot.text = if (on) "●" else "○"; dot.setTextColor(if (on) accent else MUTED)
            sub.text = (if (on) "ON  •  " else "OFF  •  ") + subtitle; sub.setTextColor(if (on) accent else MUTED)
            Toast.makeText(this, "$title ${if (on) "on" else "off"} (demo only)", Toast.LENGTH_SHORT).show()
        }
        return box
    }

    private fun showCommands() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val input = EditText(this).apply { hint = "Try: turn on living room light"; setTextColor(WHITE); setHintTextColor(MUTED); setSingleLine(false) }
        assistantInput = input
        panel.addView(input, lp(match, wrap, 0, 0, 0, 10))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val mic = TextView(this).apply { text = "🎙  SPEAK"; gravity = Gravity.CENTER; setTextColor(WHITE); background = glass(0x44282E38, 14, 0x887D8794.toInt()); setPadding(dp(12), dp(12), dp(12), dp(12)); setOnClickListener { startSpeechInput() } }
        val send = TextView(this).apply { text = "  RUN COMMAND  ➜  "; gravity = Gravity.CENTER; setTextColor(0xFF08090B.toInt()); background = goldButton(); setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener { handleAssistantCommand(input.text.toString()) } }
        actions.addView(mic, LinearLayout.LayoutParams(0, wrap, 1f).apply { marginEnd = dp(8) }); actions.addView(send, LinearLayout.LayoutParams(0, wrap, 1f))
        panel.addView(actions)
        AlertDialog.Builder(this).setTitle("$assistantName • Smart assistant")
            .setMessage("Offline assistant tools: typed commands, speech recognition and spoken replies. Try ‘turn on all lights’, ‘choose music’, ‘settings’ or ‘connect ESP32’. Real hardware control needs ESP32 API integration.")
            .setView(panel)
            .setPositiveButton("Run command") { _, _ -> handleAssistantCommand(input.text.toString()) }
            .setNeutralButton("Speak") { _, _ -> startSpeechInput() }
            .setNegativeButton("Close", null).show()
    }

    private fun handleAssistantCommand(raw: String) {
        val command = raw.trim().lowercase(Locale.ROOT)
        val response = when {
            command.isBlank() -> "Please enter a command."
            "connect" in command && "esp32" in command -> { showConnectionDialog(); "Opening ESP32 setup." }
            "setting" in command || "custom" in command -> { showSettingsDialog(); "Opening customization settings." }
            "music" in command -> { chooseMusic(); "Choose an audio file for background music." }
            "turn off all" in command || "all lights off" in command -> "All-off command recognized. Connect ESP32 to control real devices."
            "turn on" in command || "switch on" in command -> "On command recognized: $raw. Connect ESP32 to send it to hardware."
            "turn off" in command || "switch off" in command -> "Off command recognized: $raw. Connect ESP32 to send it to hardware."
            "hello" in command || "hi" == command -> "Hello! I'm $assistantName. How can I help with your smart home?"
            else -> "I can help with lights, devices, music, settings and ESP32 setup. This is an offline demo assistant, not a cloud AI model."
        }
        AlertDialog.Builder(this).setTitle(assistantName).setMessage(response).setPositiveButton("OK", null).show()
        try { tts?.speak(response, TextToSpeech.QUEUE_FLUSH, null, "shape-response") } catch (_: Exception) {}
    }

    private fun startSpeechInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a smart-home command")
            }
            startActivityForResult(intent, 7002)
        } catch (_: Exception) { Toast.makeText(this, "Speech recognition is not available on this device", Toast.LENGTH_LONG).show() }
    }

    private fun equipmentName(index: Int) = prefs.getString("equipment_$index", equipmentDefaults[index]) ?: equipmentDefaults[index]

    private fun showSettingsDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), 0) }
        fun edit(hintText: String, value: String): EditText = EditText(this).apply {
            hint = hintText; setText(value); setTextColor(WHITE); setHintTextColor(MUTED); setSingleLine(true)
        }
        val assistant = edit("Assistant name", assistantName)
        panel.addView(label("AI ASSISTANT NAME", 10f, accent, true)); panel.addView(assistant, lp(match, wrap, 0, 0, 0, 8))
        val names = Array(4) { edit("Equipment ${it + 1} name", equipmentName(it)) }
        panel.addView(label("EQUIPMENT NAMES", 10f, accent, true))
        names.forEachIndexed { i, field -> panel.addView(field, lp(match, wrap, 0, 0, 0, 3)) }
        panel.addView(label("ACCENT COLOUR", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(5)) })
        val colors = linkedMapOf("Gold" to 0xFFFFC56A.toInt(), "Ice cyan" to CYAN, "Violet" to VIOLET, "Emerald" to 0xFF65E6B3.toInt(), "Rose" to 0xFFFF86AD.toInt(), "White" to 0xFFF5F6F8.toInt())
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        colors.forEach { (name, color) ->
            val swatch = TextView(this).apply { text = "●"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(color); contentDescription = name; setOnClickListener { accent = color; prefs.edit().putInt("accent_color", color).apply(); Toast.makeText(this@MainActivity, "$name accent selected", Toast.LENGTH_SHORT).show() } }
            colorRow.addView(swatch, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        panel.addView(colorRow)
        panel.addView(label("UI BACKGROUND THEME", 10f, accent, true).apply { setPadding(0, dp(10), 0, dp(4)) })
        val backgrounds = linkedMapOf("Obsidian Black" to 0xFF050505.toInt(), "Midnight Blue" to 0xFF07111D.toInt(), "Forest Black" to 0xFF07150F.toInt(), "Plum Black" to 0xFF160B18.toInt(), "Warm Charcoal" to 0xFF17120B.toInt(), "Slate" to 0xFF111820.toInt())
        val bgSpinner = Spinner(this)
        bgSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, backgrounds.keys.toList())
        val savedBg = prefs.getInt("ui_background", 0xFF050505.toInt())
        bgSpinner.setSelection(backgrounds.values.indexOf(savedBg).coerceAtLeast(0))
        bgSpinner.setBackgroundColor(0xFF252525.toInt())
        panel.addView(bgSpinner, lp(match, dp(48), 0, 0, 0, 6))
        panel.addView(label("OPENING ANIMATION • 120 PRESETS", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        val animationSpinner = Spinner(this)
        val animationNames = (1..120).map { i -> String.format(Locale.ROOT, "%03d • %s", i, arrayOf("Gold Cinematic", "Neon Orbit", "Particle Storm", "Laser Sweep", "Pulse Reveal", "Prism Burst", "Ring Reactor", "Starlight", "Glitch Flash", "Aurora Flow")[((i - 1) % 10)] + " ${((i - 1) / 10) + 1}") }
        animationSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, animationNames)
        animationSpinner.setSelection(prefs.getInt("opening_animation", 0).coerceIn(0, 119))
        animationSpinner.setBackgroundColor(0xFF252525.toInt())
        panel.addView(animationSpinner, lp(match, dp(48), 0, 0, 0, 6))
        panel.addView(label("OPENING LOGO • CHOOSE BRAND", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        val logoChoices = listOf("PJ TECHS", "PJ", "SHAPE", "JIVA", "NOVA", "ONYX", "AURA", "PULSE", "VOLT", "LUX", "NEXUS", "ORBIT", "PHANTOM", "BEAST", "APEX", "INFINITY")
        val logoSpinner = Spinner(this)
        logoSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, logoChoices)
        logoSpinner.setSelection(logoChoices.indexOf(openingLogo).coerceAtLeast(0))
        logoSpinner.setBackgroundColor(0xFF252525.toInt())
        panel.addView(logoSpinner, lp(match, dp(48), 0, 0, 0, 8))
        val preview = TextView(this).apply { text = "▶  PREVIEW OPENING"; gravity = Gravity.CENTER; setTextColor(0xFF090909.toInt()); background = goldButton(); setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener { animationStyle = animationSpinner.selectedItemPosition; openingLogo = logoSpinner.selectedItem.toString(); uiBackground = backgrounds.values.toList()[bgSpinner.selectedItemPosition]; window.statusBarColor = uiBackground; window.navigationBarColor = uiBackground; setContentView(CinematicSplash(this@MainActivity, animationStyle, openingLogo, accent, uiBackground) { showDashboard() }) } }
        panel.addView(preview, lp(match, wrap, 0, 2, 0, 8))
        val music = TextView(this).apply { text = "♫  CHOOSE BACKGROUND MUSIC"; gravity = Gravity.CENTER; setTextColor(WHITE); background = glass(0x442D3038, 14, 0x88FFC56A.toInt()); setPadding(dp(10), dp(13), dp(10), dp(13)); setOnClickListener { chooseMusic() } }
        panel.addView(music, lp(match, wrap, 0, 8, 0, 8))
        val stopMusic = TextView(this).apply { text = "■  STOP MUSIC"; gravity = Gravity.CENTER; setTextColor(MUTED); setPadding(dp(10), dp(10), dp(10), dp(10)); setOnClickListener { musicPlayer?.pause(); Toast.makeText(this@MainActivity, "Music paused", Toast.LENGTH_SHORT).show() } }
        panel.addView(stopMusic)
        panel.addView(label("BOOT AUDIO • PLAY DURING OPENING", 10f, accent, true).apply { setPadding(0, dp(12), 0, dp(4)) })
        val bootAudioInfo = TextView(this).apply {
            val selected = prefs.getString("boot_audio_uri", null)
            text = if (selected.isNullOrBlank()) "No boot audio selected. Choose your own ‘One Sun One Moon’ audio file." else "Boot audio file selected ✓"
            textSize = 12f; setTextColor(MUTED); setPadding(dp(2), dp(2), dp(2), dp(8))
        }
        panel.addView(bootAudioInfo)
        val chooseBootAudio = TextView(this).apply {
            text = "♫  CHOOSE BOOT AUDIO FILE"; gravity = Gravity.CENTER; setTextColor(WHITE)
            background = glass(0x442D3038, 14, 0x88FFC56A.toInt()); setPadding(dp(10), dp(13), dp(10), dp(13))
            setOnClickListener { chooseBootAudio() }
        }
        panel.addView(chooseBootAudio, lp(match, wrap, 0, 2, 0, 6))
        val bootAudioEnabled = CheckBox(this).apply {
            text = "Play selected audio when the app opens"; setTextColor(WHITE)
            buttonTintList = ColorStateList.valueOf(accent)
            isChecked = prefs.getBoolean("boot_audio_enabled", false)
        }
        panel.addView(bootAudioEnabled)
        val bootSeconds = edit("Boot audio duration in seconds (1–180)", prefs.getInt("boot_audio_seconds", 8).toString()).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setTextColor(WHITE) }
        panel.addView(label("AUDIO PLAYBACK DURATION (SECONDS)", 10f, accent, true).apply { setPadding(0, dp(4), 0, dp(2)) })
        panel.addView(bootSeconds, lp(match, wrap, 0, 0, 0, 6))
        AlertDialog.Builder(this).setTitle("shape • Customization")
            .setView(ScrollView(this).apply { addView(panel) })
            .setPositiveButton("Save settings") { _, _ ->
                assistantName = assistant.text.toString().trim().ifBlank { "JIVA" }
                animationStyle = animationSpinner.selectedItemPosition
                openingLogo = logoSpinner.selectedItem.toString()
                uiBackground = backgrounds.values.toList()[bgSpinner.selectedItemPosition]
                window.statusBarColor = uiBackground; window.navigationBarColor = uiBackground
                val edit = prefs.edit().putString("assistant_name", assistantName)
                    .putInt("opening_animation", animationStyle).putString("opening_logo", openingLogo)
                    .putInt("ui_background", uiBackground).putInt("accent_color", accent)
                    .putBoolean("boot_audio_enabled", bootAudioEnabled.isChecked)
                    .putInt("boot_audio_seconds", (bootSeconds.text.toString().toIntOrNull() ?: 8).coerceIn(1, 180))
                names.forEachIndexed { i, field -> edit.putString("equipment_$i", field.text.toString().trim().ifBlank { equipmentDefaults[i] }) }
                edit.apply(); showDashboard()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseMusic() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        try { startActivityForResult(intent, 7001) } catch (_: Exception) { Toast.makeText(this, "No audio picker available", Toast.LENGTH_SHORT).show() }
    }

    private fun chooseBootAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        try { startActivityForResult(intent, 7003) } catch (_: Exception) { Toast.makeText(this, "No audio picker available", Toast.LENGTH_SHORT).show() }
    }

    private fun goldButton() = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFFFD783.toInt(), 0xFFC18A36.toInt())).apply { cornerRadius = dp(13).toFloat() }

    private fun showConnectionDialog() {
        val input = EditText(this).apply { hint = "http://192.168.1.50"; setText(prefs.getString("esp32_address", "") ?: ""); setTextColor(WHITE); setHintTextColor(MUTED); setSingleLine(true) }
        val holder = LinearLayout(this).apply { setPadding(dp(22), dp(8), dp(22), 0); addView(input) }
        AlertDialog.Builder(this).setTitle("Connect ESP32")
            .setMessage("Add an ESP32 device using its local IP address. This build saves setup details only; live relay API integration still needs matching ESP32 firmware endpoints.")
            .setView(holder).setPositiveButton("Save for setup") { _, _ ->
                val address = input.text.toString().trim()
                if (address.isNotBlank()) prefs.edit().putString("esp32_address", address).apply()
                Toast.makeText(this, if (address.isBlank()) "No address entered" else "Saved ESP32 address: $address (API control not yet implemented)", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun glass(color: Int, radius: Int, edge: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(color, (color and 0x00FFFFFF) or 0x22000000)).apply { cornerRadius = dp(radius).toFloat(); setStroke(dp(1), edge) }
    private fun lp(w: Int, h: Int, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val match get() = LinearLayout.LayoutParams.MATCH_PARENT
    private val wrap get() = LinearLayout.LayoutParams.WRAP_CONTENT

    /** Glass-tech intro: holographic reveal, floating blue particles and luminous glass rings. */
    private class CinematicSplash(activity: MainActivity, private val style: Int, private val logoText: String, private val accentColor: Int, private val backgroundColor: Int, val done: () -> Unit) : View(activity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var progress = 0f
        private val gold = accentColor
        private val red = intArrayOf(0xFFB8873E.toInt(), 0xFF54C9FF.toInt(), 0xFF9A69FF.toInt(), 0xFFFF4D6D.toInt(), 0xFF65E6B3.toInt(), 0xFFFF8C42.toInt())[style % 6]
        private val ember = 0xFFEEE4D3.toInt()
        private val particleX = FloatArray(64) { ((it * 83 + 37) % 997) / 997f }
        private val particleY = FloatArray(64) { ((it * 149 + 13) % 991) / 991f }
        private val particleSize = FloatArray(64) { 1f + ((it * 11) % 4) }
        private var finished = false
        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = (2400L + (style % 7) * 180L)
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { if (!finished) { finished = true; done() } }
            })
        }
        init {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            post { if (isAttachedToWindow && !finished) animator.start() }
            setOnClickListener { finishNow() }
        }
        private fun finishNow() {
            if (finished) return
            finished = true
            if (animator.isRunning) animator.cancel()
            done()
        }
        override fun onDetachedFromWindow() {
            if (animator.isRunning) animator.cancel()
            super.onDetachedFromWindow()
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2f; val cy = h * .445f
            canvas.drawColor(backgroundColor)
            p.shader = RadialGradient(cx, cy, w * .9f, intArrayOf(0xFF252019.toInt(), 0xFF101010.toInt(), 0xFF030303.toInt()), floatArrayOf(0f, .48f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            // Deep-red cinematic light curtains slide across the screen.
            for (i in 0..3) {
                val drift = (progress * 1.25f + i * .29f) % 1.7f
                val x = w * (drift - .28f)
                p.shader = LinearGradient(x - w*.16f, 0f, x + w*.16f, h,
                    intArrayOf(0x00000000, if (i % 2 == 0) 0x33FFC56A else 0x33B8873E, 0x00000000), null, Shader.TileMode.CLAMP)
                canvas.save(); canvas.rotate(-11f, cx, cy); canvas.drawRect(x-w*.16f, 0f, x+w*.16f, h, p); canvas.restore(); p.shader = null
            }
            // Floating ember particles.
            for (i in particleX.indices) {
                val x = particleX[i] * w + sin(progress * 6f + i).toFloat() * w * .018f
                val y = h * (1f - ((particleY[i] + progress * (.2f + (i % 6) * .025f)) % 1f))
                val flicker = .22f + .78f * abs(sin(progress * 17f + i)).toFloat()
                p.color = when (i % 3) { 0 -> gold; 1 -> red; else -> ember }
                p.alpha = (210 * flicker).toInt()
                canvas.drawCircle(x, y, dp(particleSize[i].toInt().coerceAtLeast(1)).toFloat() * flicker, p)
            }
            p.alpha = 255
            // Thin ice-blue corner marks draw in like a glass-tech frame.
            val frame = ((progress - .04f) / .26f).coerceIn(0f, 1f)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat(); p.color = gold; p.alpha = (190 * frame).toInt()
            val inset = w * (.09f + .035f * (1f-frame)); val top = h*.20f; val bottom = h*.72f; val len = w*.15f*frame
            canvas.drawLine(inset,top,inset+len,top,p); canvas.drawLine(inset,top,inset,top+len,p)
            canvas.drawLine(w-inset,top,w-inset-len,top,p); canvas.drawLine(w-inset,top,w-inset,top+len,p)
            canvas.drawLine(inset,bottom,inset+len,bottom,p); canvas.drawLine(inset,bottom,inset,bottom-len,p)
            canvas.drawLine(w-inset,bottom,w-inset-len,bottom,p); canvas.drawLine(w-inset,bottom,w-inset,bottom-len,p)
            p.style = Paint.Style.FILL; p.alpha = 255
            // Two rotating rings form a clean tech insignia behind the logo.
            val reveal = ((progress-.10f)/.34f).coerceIn(0f,1f)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.color = gold; p.alpha = (215*reveal).toInt(); p.setShadowLayer(dp(9).toFloat(),0f,0f,gold)
            canvas.drawArc(cx-w*.31f,cy-w*.31f,cx+w*.31f,cy+w*.31f,-100f+progress*(100f + (style % 12) * 20f),280f*reveal,false,p)
            p.clearShadowLayer(); p.color = red; p.alpha = (190*reveal).toInt(); p.strokeWidth = dp(1).toFloat()
            canvas.drawArc(cx-w*.35f,cy-w*.35f,cx+w*.35f,cy+w*.35f,70f-progress*120f,95f*reveal,false,p)
            p.style = Paint.Style.FILL; p.alpha = 255
            // A cool holographic flash as the title locks into place.
            val flash = if (progress in .42f.. .49f) 1f-abs(progress-.455f)/.035f else 0f
            if (flash > 0f) { p.color = 0xFFE8FAFF.toInt(); p.alpha = (flash*95).toInt(); canvas.drawRect(0f,0f,w,h,p); p.alpha=255 }
            val titleAlpha = ((progress-.23f)/.28f).coerceIn(0f,1f)
            val scale = (.68f + .32f*DecelerateInterpolator().getInterpolation(titleAlpha)) * (if (progress in .40f.. .53f) 1f+.022f*(1f-abs(progress-.465f)/.065f) else 1f)
            canvas.save(); canvas.scale(scale,scale,cx,cy)
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-black",Typeface.BOLD); p.textSize = w*.137f
            p.color = red; p.alpha = (170*titleAlpha).toInt(); p.setShadowLayer(dp(13).toFloat(),0f,dp(2).toFloat(),red); canvas.drawText(logoText,cx+dp(2),cy+dp(8),p); p.clearShadowLayer()
            p.shader = LinearGradient(cx,cy-w*.10f,cx,cy+w*.02f,intArrayOf(0xFFFFFFFF.toInt(),0xFFFFE6B5.toInt(),0xFFC18A36.toInt(),0xFFFFF5DB.toInt()),null,Shader.TileMode.CLAMP)
            p.alpha = (255*titleAlpha).toInt(); canvas.drawText(logoText,cx,cy+dp(5),p); p.shader=null
            // Brief horizontal light streaks give the title a sharp cinematic finish.
            if (progress in .38f.. .58f) {
                val gp=(progress-.38f)/.20f; p.alpha=(150*(1f-abs(gp-.5f)*2f)).toInt(); p.color=gold
                canvas.drawRect(cx-w*.39f,cy-w*.075f,cx-w*.18f,cy-w*.068f,p)
                p.color=red; canvas.drawRect(cx+w*.17f,cy+w*.015f,cx+w*.39f,cy+w*.022f,p)
            }
            canvas.restore(); p.alpha=255
            val line=((progress-.51f)/.16f).coerceIn(0f,1f)
            p.shader=LinearGradient(cx-w*.28f,cy+w*.105f,cx+w*.28f,cy+w*.105f,intArrayOf(0x00FFC56A,gold,red,0x00ED593D),null,Shader.TileMode.CLAMP)
            canvas.drawRect(cx-w*.28f,cy+w*.105f,cx-w*.28f+w*.56f*line,cy+w*.109f,p); p.shader=null
            p.textAlign=Paint.Align.CENTER; p.typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL); p.textSize=w*.027f; p.color=WHITE
            p.alpha=(235*((progress-.56f)/.19f).coerceIn(0f,1f)).toInt(); canvas.drawText("BLACK & GOLD  •  SMART CONTROL",cx,cy+w*.17f,p)
            p.textSize=w*.026f; p.color=gold; p.alpha=(230*((progress-.70f)/.18f).coerceIn(0f,1f)).toInt(); canvas.drawText("$logoText  •  POWERED BY JIVA",cx,h*.82f,p)
            p.textSize=w*.023f; p.color=0xFFB7C0CA.toInt(); p.alpha=(145*(1f-progress)).toInt(); canvas.drawText("TAP TO ENTER",cx,h*.92f,p)
            p.alpha=255
        }
        private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    }
}
