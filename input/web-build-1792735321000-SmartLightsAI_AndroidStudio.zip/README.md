# Smart Lights AI — Android Studio starter project

This is a native Kotlin + Jetpack Compose Android app source project. It includes:
- Four relay controls
- Polling `/state` every 1.5 seconds while the Lights screen is open
- Direct ESP32 AP URL support (`http://192.168.4.1`) and home-router IP support
- Relay command editor (per-relay label, ON path, OFF path)
- Online AI chat screen using a backend URL configured in Settings

## Open and build
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Android Studio → Open → choose the `SmartLightsAI_AndroidStudio` folder.
4. Allow Gradle sync; install Android SDK Platform 35 if requested.
5. Build → Build APK(s).
6. APK normally appears at `app/build/outputs/apk/debug/app-debug.apk`.

This ZIP is source code, not a precompiled APK. It must be built with Android Studio/Gradle.

## ESP32 HTTP API expected by the app
The app expects:
- `GET /state` returns JSON like `{"relay1":false,"relay2":true,"relay3":false,"relay4":false}`
- `GET /relay/1?state=on` and `/relay/1?state=off` (repeat for relay 2–4) set the requested state, rather than toggling blindly.

You can edit all command paths in the app's **Relay commands** tab. If your firmware uses different endpoints, set the paths to match it. A command URL must return HTTP 2xx on success.

## AI backend
The AI screen sends `POST` to the configured backend URL with:
`{"message":"your question"}`

It expects a JSON response:
`{"reply":"assistant answer"}`

Use an HTTPS backend that keeps provider API keys server-side. Do not put an OpenAI/provider API key in the APK. For production, add authentication, rate limiting, and request validation to the backend.

## Wi-Fi modes
- AP mode: connect the phone to the ESP32 AP (e.g. `SmartLights-S3`) and set base URL to `http://192.168.4.1`.
- Home Wi-Fi mode: connect both devices to the same router and set base URL to the ESP32's DHCP/reserved IP, e.g. `http://192.168.1.50`.
- Android may show “No internet” on the ESP32 AP; choose to stay connected. Internet AI generally won't work over the ESP32-only AP unless the phone also has another internet path.

## Important hardware safety
GPIO values and relay polarity depend on your exact ESP32-S3 Super Mini board and relay interface. Do not connect an unknown 12 V relay board input directly to an ESP32 GPIO. Use a suitable 3.3 V-compatible driver/interface and verify relay module input voltage and polarity first. Keep mains wiring enclosed and have a qualified electrician handle 230 V loads.
