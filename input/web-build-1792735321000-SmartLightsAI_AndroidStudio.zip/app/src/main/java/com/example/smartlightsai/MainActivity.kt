package com.example.smartlightsai

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private data class RelayConfig(
    val name: String,
    val onPath: String,
    val offPath: String
)

private val defaultRelays = listOf(
    RelayConfig("Light 1", "/relay/1?state=on", "/relay/1?state=off"),
    RelayConfig("Light 2", "/relay/2?state=on", "/relay/2?state=off"),
    RelayConfig("Light 3", "/relay/3?state=on", "/relay/3?state=off"),
    RelayConfig("Light 4", "/relay/4?state=on", "/relay/4?state=off")
)

private class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("smart_lights", Context.MODE_PRIVATE)
    var baseUrl: String
        get() = prefs.getString("baseUrl", "http://192.168.4.1") ?: "http://192.168.4.1"
        set(value) = prefs.edit().putString("baseUrl", value.trim().trimEnd('/')).apply()
    var statePath: String
        get() = prefs.getString("statePath", "/state") ?: "/state"
        set(value) = prefs.edit().putString("statePath", value).apply()
    var aiUrl: String
        get() = prefs.getString("aiUrl", "") ?: ""
        set(value) = prefs.edit().putString("aiUrl", value.trim()).apply()
    fun relay(i: Int): RelayConfig {
        val d = defaultRelays[i]
        return RelayConfig(
            prefs.getString("relay_${i}_name", d.name) ?: d.name,
            prefs.getString("relay_${i}_on", d.onPath) ?: d.onPath,
            prefs.getString("relay_${i}_off", d.offPath) ?: d.offPath
        )
    }
    fun saveRelay(i: Int, relay: RelayConfig) {
        prefs.edit()
            .putString("relay_${i}_name", relay.name)
            .putString("relay_${i}_on", relay.onPath)
            .putString("relay_${i}_off", relay.offPath)
            .apply()
    }
}

private fun httpRequest(urlText: String, method: String = "GET", body: String? = null): String {
    val conn = (URL(urlText).openConnection() as HttpURLConnection)
    conn.requestMethod = method
    conn.connectTimeout = 2500
    conn.readTimeout = 2500
    conn.setRequestProperty("Accept", "application/json")
    if (body != null) {
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
    }
    try {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val result = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IllegalStateException("HTTP $code: $result")
        return result
    } finally {
        conn.disconnect()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartLightsApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartLightsApp() {
    val context = LocalContext.current
    val store = remember { SettingsStore(context) }
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("Lights") }
    var baseUrl by remember { mutableStateOf(store.baseUrl) }
    var statePath by remember { mutableStateOf(store.statePath) }
    var aiUrl by remember { mutableStateOf(store.aiUrl) }
    var status by remember { mutableStateOf("Not connected") }
    var busy by remember { mutableStateOf(false) }
    var relayStates by remember { mutableStateOf(listOf(false, false, false, false)) }
    var relayConfigs by remember { mutableStateOf((0..3).map { store.relay(it) }) }
    var chatInput by remember { mutableStateOf("") }
    var chatLines by remember { mutableStateOf(listOf("AI assistant", "Enter your backend URL in Settings to enable online AI chat.")) }

    fun rootUrl() = baseUrl.trim().trimEnd('/')
    fun refreshStates() {
        scope.launch {
            try {
                val raw = withContext(Dispatchers.IO) { httpRequest(rootUrl() + statePath) }
                val json = JSONObject(raw)
                val next = (1..4).map { n ->
                    when {
                        json.has("relay$n") -> json.optBoolean("relay$n", false)
                        json.has("r$n") -> json.optBoolean("r$n", false)
                        json.has("relays") && json.optJSONArray("relays") != null ->
                            json.getJSONArray("relays").optBoolean(n - 1, false)
                        else -> throw IllegalStateException("State JSON needs relay1..relay4, r1..r4, or relays[]")
                    }
                }
                relayStates = next
                status = "Connected • states synced"
            } catch (e: Exception) {
                status = "Offline / unable to read state: ${e.message ?: "connection error"}"
            }
        }
    }

    LaunchedEffect(baseUrl, statePath, page) {
        if (page == "Lights") {
            while (true) {
                refreshStates()
                delay(1500)
            }
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Smart Lights AI", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = { page = "Settings" }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = page == "Lights",
                        onClick = { page = "Lights" },
                        icon = { Icon(Icons.Default.Lightbulb, null) },
                        label = { Text("Lights") }
                    )
                    NavigationBarItem(
                        selected = page == "Commands",
                        onClick = { page = "Commands" },
                        icon = { Icon(Icons.Default.Edit, null) },
                        label = { Text("Relay commands") }
                    )
                    NavigationBarItem(
                        selected = page == "AI",
                        onClick = { page = "AI" },
                        icon = { Icon(Icons.Default.Chat, null) },
                        label = { Text("AI assistant") }
                    )
                }
            }
        ) { padding ->
            when (page) {
                "Lights" -> LazyColumn(
                    modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text("Connection", style = MaterialTheme.typography.titleMedium)
                                Text(rootUrl(), style = MaterialTheme.typography.bodyMedium)
                                Text(status, style = MaterialTheme.typography.bodySmall)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { page = "Settings" }) { Text("Wi-Fi / IP settings") }
                                    Button(onClick = { refreshStates() }) { Text("Sync now") }
                                }
                            }
                        }
                    }
                    itemsIndexed(relayConfigs) { index, relay ->
                        Card {
                            Row(
                                Modifier.fillMaxWidth().padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(relay.name, style = MaterialTheme.typography.titleMedium)
                                    Text(if (relayStates[index]) "ON" else "OFF",
                                        color = if (relayStates[index]) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = relayStates[index],
                                    enabled = !busy,
                                    onCheckedChange = { desired ->
                                        busy = true
                                        scope.launch {
                                            try {
                                                val path = if (desired) relay.onPath else relay.offPath
                                                withContext(Dispatchers.IO) { httpRequest(rootUrl() + path) }
                                                delay(150)
                                                refreshStates()
                                            } catch (e: Exception) {
                                                status = "Command failed: ${e.message ?: "network error"}"
                                            } finally { busy = false }
                                        }
                                    }
                                )
                            }
                        }
                    }
                    item {
                        Text("Tip: connect your phone to SmartLights-S3 for direct AP control, or use the ESP32 IP on your home Wi-Fi.", style = MaterialTheme.typography.bodySmall)
                    }
                }

                "Commands" -> Column(
                    Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Relay command editor", style = MaterialTheme.typography.headlineSmall)
                    Text("Edit each relay's display name and ON/OFF URL path. Paths are appended to the base URL in Settings. Changes are saved on this phone.")
                    relayConfigs.forEachIndexed { i, cfg ->
                        var name by remember(cfg.name) { mutableStateOf(cfg.name) }
                        var onPath by remember(cfg.onPath) { mutableStateOf(cfg.onPath) }
                        var offPath by remember(cfg.offPath) { mutableStateOf(cfg.offPath) }
                        ElevatedCard {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Relay ${i + 1}", style = MaterialTheme.typography.titleMedium)
                                OutlinedTextField(name, { name = it }, label = { Text("Display name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                OutlinedTextField(onPath, { onPath = it }, label = { Text("ON command path") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                OutlinedTextField(offPath, { offPath = it }, label = { Text("OFF command path") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                Button(onClick = {
                                    val updated = cfg.copy(name = name.ifBlank { "Relay ${i + 1}" }, onPath = onPath, offPath = offPath)
                                    store.saveRelay(i, updated)
                                    relayConfigs = relayConfigs.toMutableList().also { it[i] = updated }
                                    status = "Relay ${i + 1} command settings saved"
                                }) { Text("Save relay ${i + 1}") }
                            }
                        }
                    }
                    OutlinedButton(onClick = {
                        relayConfigs = defaultRelays
                        defaultRelays.forEachIndexed { i, r -> store.saveRelay(i, r) }
                        status = "Default relay commands restored"
                    }) { Text("Restore default commands") }
                }

                "AI" -> Column(
                    Modifier.padding(padding).fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Online AI assistant", style = MaterialTheme.typography.headlineSmall)
                    Text("Requires internet and a secure backend URL. Do not put an AI provider API key directly in this APK.")
                    Card(Modifier.weight(1f).fillMaxWidth()) {
                        LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            itemsIndexed(chatLines) { _, line ->
                                Text(line, style = MaterialTheme.typography.bodyMedium)
                                HorizontalDivider()
                            }
                        }
                    }
                    OutlinedTextField(
                        value = chatInput, onValueChange = { chatInput = it },
                        label = { Text("Ask the AI assistant") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        modifier = Modifier.fillMaxWidth(),
                        enabled = chatInput.isNotBlank() && aiUrl.isNotBlank(),
                        onClick = {
                            val question = chatInput.trim()
                            chatInput = ""
                            chatLines = chatLines + "You: $question"
                            scope.launch {
                                try {
                                    val body = JSONObject().put("message", question).toString()
                                    val raw = withContext(Dispatchers.IO) { httpRequest(aiUrl, "POST", body) }
                                    val reply = JSONObject(raw).optString("reply", raw)
                                    chatLines = chatLines + "AI: $reply"
                                } catch (e: Exception) {
                                    chatLines = chatLines + "Error: ${e.message ?: "Could not contact AI backend"}"
                                }
                            }
                        }
                    ) { Text("Send") }
                    Text("Expected backend: POST JSON {\"message\":\"...\"}; reply JSON {\"reply\":\"...\"}.", style = MaterialTheme.typography.bodySmall)
                }

                else -> Column(
                    Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Connection & AI settings", style = MaterialTheme.typography.headlineSmall)
                    Text("Direct access point: connect your phone to the ESP32 Wi-Fi, then use http://192.168.4.1")
                    Text("Home router: connect both phone and ESP32 to the same Wi-Fi and enter the ESP32's assigned IP.")
                    OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("ESP32 base URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(statePath, { statePath = it }, label = { Text("State endpoint path") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(aiUrl, { aiUrl = it }, label = { Text("Online AI backend URL (HTTPS recommended)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = {
                        baseUrl = baseUrl.trim().trimEnd('/')
                        statePath = if (statePath.startsWith("/")) statePath else "/$statePath"
                        store.baseUrl = baseUrl
                        store.statePath = statePath
                        store.aiUrl = aiUrl
                        status = "Settings saved"
                        page = "Lights"
                    }) { Text("Save settings") }
                }
            }
        }
    }
}
