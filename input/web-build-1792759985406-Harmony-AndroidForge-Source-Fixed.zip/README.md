# Harmony Android music app

Free Kotlin Android starter project for AndroidForge.

## Features in this starter
- Local audio selection using Android's file picker
- Playlist queue for the current app session
- Media3 ExoPlayer playback
- Background playback and system media notification via MediaSessionService
- Direct HTTPS audio URL playback for audio you are authorized to stream
- YouTube search opens the official YouTube app/browser
- Device equalizer when supported
- Simple dark/light background toggle
- Manual lyrics text field

## Build with AndroidForge (phone only)
1. Download and unzip this project.
2. Zip the *contents* of the `HarmonyAndroidForge` folder (settings.gradle.kts, build.gradle.kts, app/, etc.) into `Harmony-source.zip`.
3. Open https://github.com/Professional-X/AndroidForge and fork the repository.
4. Open https://professional-x.github.io/AndroidForge/
5. Follow AndroidForge's current instructions to connect your fork and upload the ZIP, then choose Build APK.
6. Download the APK artifact from the completed GitHub Actions run and install it. Android may ask you to allow installs from your browser/files app.

AndroidForge requires a GitHub account and a GitHub Personal Access Token for its web UI flow. Keep the token private and only enter it on the official GitHub Pages interface after checking the URL.

## Important limitations
- This is a starter, not a finished commercial app.
- YouTube search launches YouTube; YouTube playback cannot be converted into background audio or downloaded by this app.
- Offline mode plays files selected by the user. It does not download music from YouTube.
- Lyrics are manual in this first version.
- The playlist is held in memory and resets when the app process is cleared.
- Equalizer behavior depends on the Android device and audio output.
- The online URL field requires a direct HTTPS audio stream URL, not a web page URL.

## Build compatibility fix

This project uses AndroidX Media3 **1.8.0** with `compileSdk = 35` and Android Gradle Plugin **8.7.3**. This avoids the reported AAR metadata error caused by Media3 1.11.0 requiring a newer compile SDK.
