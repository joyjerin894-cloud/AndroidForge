# Smooth + Fast Cinematic Intro

- Intro duration reduced from 5.2 seconds to 2.85 seconds.
- Uses Android hardware-accelerated rendering instead of forced software rendering.
- Particle count reduced from 110 to 56 and beam count from 6 to 5 to reduce per-frame work.
- Glow blur sizes reduced for better performance on mid-range phones.
- Prevents duplicate dashboard launch when the intro is skipped and cancels animation when detached.

Performance still depends on the phone, Android version, display refresh rate, and thermal state. This archive was checked for ZIP integrity; a full Gradle build was not run here.
