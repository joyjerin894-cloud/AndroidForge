# Build and visual update

- Updated dashboard to a colorful midnight/neon design with gradient hero panel, status badge, device cards, JIVA panel, and ESP32 setup entry point.
- Reworked the opening into an original action-cinema-inspired PJ TECHS title reveal with neon beams, particles, ring, glitch bars, and impact flash.
- Aligned Java source/target compatibility and Kotlin JVM target to 17.
- The ZIP contains Android Studio source; no APK build has been run in this environment. Device controls and voice actions remain demo placeholders until ESP32 and speech APIs are integrated.
