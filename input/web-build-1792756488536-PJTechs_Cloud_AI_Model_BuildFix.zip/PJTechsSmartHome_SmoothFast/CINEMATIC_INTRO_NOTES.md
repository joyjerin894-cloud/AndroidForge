# shape — Glass UI Update

- App launcher name and dashboard branding changed to `shape`.
- Deep navy glassmorphism palette with translucent blue-tinted panels, cool cyan highlights, violet glow, and thin luminous borders.
- Opening animation uses a holographic title reveal, floating light particles, rotating glass-tech rings, light sweeps, and a cool impact flash.
- The intro is tap-to-skip and runs for approximately 3.2 seconds.
- Device switches and JIVA commands remain demonstration-only until the ESP32 and voice-control APIs are implemented.


## Black Glass Theme Update
The app branding is “shape” and the interface uses a near-black glassmorphism palette with translucent charcoal panels, subtle silver borders, cool cyan highlights, and violet accents. The cinematic intro background has also been darkened to black.
