# PJ Techs Smart Home — Black & Gold Edition

Android smart-home UI prototype with custom colours, selectable opening animation and logo presets, customizable assistant/equipment names, music picker, and voice/text command demo.

## Build
Open this project in Android Studio or upload its files to the `PJTechsSmartHome_SmoothFast` project directory used by the AndroidForge GitHub Actions workflow. Commit the changes and run **Actions → Build Android APK**.

## Customization
Open **CUSTOMIZE PJ TECHS** in the dashboard to select the UI accent colour, background theme, one of 120 opening animation presets, and an opening logo. Save settings; the selected opening animation and logo are used the next time the app launches. Use **PREVIEW OPENING** to preview the selected style.

## Notes
This is a source ZIP; compilation has not been verified in this environment. Dashboard device toggles are demos until the ESP32 relay API is integrated. See `FEATURES_SHAPE.md` for details and limitations.

Boot audio: open Customization Settings, choose a local audio file, enable “Play selected audio when the app opens,” set the duration in seconds, and save. The app does not include copyrighted music; choose an audio file you have permission to use.

### Custom intro duration
In **CUSTOMIZE PJ TECHS**, set **CINEMATIC INTRO DURATION** from 1 to 30 seconds, then use **PREVIEW CINEMATIC OPENING + AUDIO** to preview it. Save settings to persist the duration. Select a boot audio file, enable playback, and set its separate duration (1–180 seconds) to preview audio with the intro.

### Custom opening logo image
Open Settings → Customization → **Choose Custom Logo Image** and select a PNG, JPG, or other supported image from your device. The app persists access to the selected image and uses it in the cinematic opening animation. Choose “Use text logo instead” to clear the custom image and return to the selected text brand. Preview the opening and save your other settings as usual.

### Slider controls
The customization screen includes sliders for cinematic intro duration (1–30 seconds), opening logo image size (50%–150%), and boot-audio playback duration (1–180 seconds). Values display live while sliding and persist with Save settings.


## Opening theme menu and liquid buttons
- Added a dedicated Opening Look theme menu: Gold Cinema, Ice Neon, Violet Galaxy, Crimson Beast, Emerald Pulse, Arctic Chrome, Solar Flare, and Midnight Blue.
- Selected theme is saved and applied to the cinematic opening/preview palette.
- Clickable app controls use Android ripple feedback with a soft press/rebound animation inspired by liquid-glass interactions.


### Cloud AI model (JIVA)
Open **CUSTOMIZE PJ TECHS** and enter an OpenAI-compatible HTTPS chat-completions endpoint, model name, and API key. The default endpoint is `https://api.openai.com/v1/chat/completions` and the default model name is `gpt-4o-mini`; choose a model available to your provider/account. Save settings, then open **Talk to JIVA** and ask a question. The app sends prompts to the configured cloud model on a background thread and displays/speaks the response. If no API key is configured, the existing local demo commands continue to work.

The API key is encrypted at rest using Android Keystore and is not bundled into the APK. However, a client-side app cannot fully protect a key from a compromised device; for public distribution, use a private backend proxy and never put a shared production key in the app. Cloud requests require internet and may incur provider charges. Cloud AI responses do not control physical devices; ESP32 relay/API integration is still required.

## ESP32 Wi-Fi connection (new)
- The dashboard includes a **CONNECT ESP32** button. Enter the ESP32 IP address (for example `192.168.1.50` on home Wi-Fi or `192.168.4.1` only if AP mode is configured), then tap **TEST CONNECTION**.
- The app tests `GET /api/status`, saves the address after a successful test, and uses `GET /api/relay?id=1&state=on` (relay IDs 1–4, states `on`/`off`) when a device card is tapped.
- The ESP32 firmware must implement both endpoints and return HTTP 2xx. The starter Wi-Fi firmware supplied with the setup instructions is compatible.
- Device cards no longer pretend to switch hardware: they update their state only after a successful ESP32 response.
- The app currently uses local HTTP for a trusted home network. Do not port-forward the ESP32 web server or expose it to the internet; add authentication before production use.

### Animated device switches
The four dashboard device cards use custom animated black-glass/gold ON/OFF switches. They send the same `/api/relay?id=N&state=on|off` commands as the cards and reflect the state after a successful response.


## Dashboard categories and smart scenes update
- Added a horizontal category bar for Home, Devices, Scenes, Voice, Network, and Settings with smooth section navigation.
- Added consistent black-glass / gold section headers for devices, smart scenes, insights, voice assistant, network, and settings.
- Added one-tap Night, Evening, Focus, and Away scenes that sequentially send commands to the connected ESP32 and update switch states only after successful responses.
- Added an illustrative active-load estimate based on saved relay states (12 W, 8 W, 45 W, and 18 W defaults); this is not a meter reading and should be customized for actual devices.
- ZIP integrity checked. A full Android Gradle build was not run in this environment.
