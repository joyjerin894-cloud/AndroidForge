package com.pjtechs.smarthome

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.animation.ValueAnimator
import android.view.View
import android.view.Gravity
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.graphics.drawable.GradientDrawable

private const val BG = 0xFF050505.toInt()
private const val PANEL = 0xFF171717.toInt()
private const val RED = 0xFFE6E6E6.toInt()
private const val MUTED = 0xFF969696.toInt()

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        setContentView(CinematicSplash(this) { showDashboard() })
    }

    private fun showDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(BG)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        page.addView(scroll)

        val brand = TextView(this).apply {
            text = "PJ TECHS"; textSize = 27f; letterSpacing = .12f; setTextColor(RED)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        root.addView(brand)
        root.addView(label("SMART HOME  •  BRIGHTER LIFE", 11f, MUTED).also { it.setPadding(0, dp(3), 0, dp(20)) })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = rounded(PANEL, 22)
        }
        hero.addView(label("YOUR HOME, UNDER YOUR CONTROL", 11f, MUTED))
        hero.addView(label("Good to see you.", 24f, Color.WHITE).also { it.setPadding(0, dp(7), 0, dp(5)) })
        hero.addView(label("Assistant JIVA  •  Local network mode", 13f, 0xFFBDBDBD.toInt()))
        root.addView(hero, lp(match, wrap, 0, 0, 0, 18))

        root.addView(label("QUICK CONTROL", 12f, MUTED).also { it.setPadding(0, 0, 0, dp(10)) })
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(deviceCard("◉", "Living room", "Light", true), LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginEnd = dp(7) })
        row1.addView(deviceCard("◌", "Bedroom", "Light", false), LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginStart = dp(7) })
        row2.addView(deviceCard("✣", "Ceiling fan", "Relay 2", false), LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginEnd = dp(7); topMargin = dp(14) })
        row2.addView(deviceCard("▣", "Auxiliary", "Relay 3", false), LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginStart = dp(7); topMargin = dp(14) })
        grid.addView(row1); grid.addView(row2); root.addView(grid)

        val voice = TextView(this).apply {
            text = "  ◉     Talk to JIVA\n         Tap to see sample voice commands"
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(15)); background = rounded(0xFF202020.toInt(), 18)
            setOnClickListener { showCommands() }
        }
        root.addView(voice, lp(match, dp(76), 0, 18, 0, 12))
        val setup = Button(this).apply {
            text = "SET ESP32 CONNECTION"; setTextColor(Color.WHITE); isAllCaps = false
            background = rounded(RED, 16)
            setOnClickListener { showConnectionDialog() }
        }
        root.addView(setup, lp(match, dp(52)))
        root.addView(label("Demo interface • Configure your ESP32 address before controlling real relays.", 11f, MUTED).also { it.setPadding(2, dp(12), 2, 0) })
        setContentView(page)
    }

    private fun deviceCard(icon: String, title: String, subtitle: String, initiallyOn: Boolean): View {
        var on = initiallyOn
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(13), dp(13), dp(12)); background = rounded(PANEL, 20)
        }
        val glyph = TextView(this).apply { text = icon; textSize = 26f; setTextColor(if (on) RED else MUTED) }
        val name = label(title, 15f, Color.WHITE).also { it.typeface = Typeface.DEFAULT_BOLD; it.setPadding(0, dp(6), 0, 0) }
        val sub = label(if (on) "ON  •  $subtitle" else "OFF  •  $subtitle", 11f, MUTED).also { it.setPadding(0, dp(4), 0, 0) }
        box.addView(glyph); box.addView(name); box.addView(sub)
        box.setOnClickListener {
            on = !on
            glyph.setTextColor(if (on) RED else MUTED)
            sub.text = (if (on) "ON  •  " else "OFF  •  ") + subtitle
            Toast.makeText(this, if (on) "$title switched on (demo)" else "$title switched off (demo)", Toast.LENGTH_SHORT).show()
        }
        return box
    }

    private fun showCommands() {
        val items = arrayOf("JIVA, turn on living room light", "JIVA, turn off bedroom light", "JIVA, turn on fan", "JIVA, all lights off")
        android.app.AlertDialog.Builder(this).setTitle("JIVA • Voice commands")
            .setItems(items) { _, which -> Toast.makeText(this, "Sample command: ${items[which]}", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Close", null).show()
    }

    private fun showConnectionDialog() {
        val input = EditText(this).apply { hint = "http://192.168.1.50"; setTextColor(Color.WHITE); setHintTextColor(MUTED); setSingleLine(true) }
        val holder = LinearLayout(this).apply { setPadding(dp(22), dp(8), dp(22), 0); addView(input) }
        android.app.AlertDialog.Builder(this).setTitle("ESP32 connection")
            .setMessage("Enter the local IP address shown by your ESP32 firmware. This UI template does not send relay commands until the matching API is implemented.")
            .setView(holder).setPositiveButton("Save for setup") { _, _ ->
                val address = input.text.toString().trim()
                Toast.makeText(this, if (address.isBlank()) "No address entered" else "Address entered: $address", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun lp(w: Int, h: Int, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val match get() = LinearLayout.LayoutParams.MATCH_PARENT
    private val wrap get() = LinearLayout.LayoutParams.WRAP_CONTENT

    private class CinematicSplash(activity: MainActivity, val done: () -> Unit) : View(activity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val rect = RectF()
        private var progress = 0f
        private val red = Color.rgb(225, 225, 225)
        private val white = Color.rgb(250, 250, 250)
        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3400L; interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() { override fun onAnimationEnd(animation: android.animation.Animator) { done() } })
        }
        init { setLayerType(View.LAYER_TYPE_SOFTWARE, null); post { animator.start() }; setOnClickListener { if (animator.isRunning) { animator.cancel(); done() } } }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2f; val cy = h * .43f
            canvas.drawColor(Color.rgb(5, 5, 7))
            p.shader = RadialGradient(cx, cy, w * .8f, intArrayOf(0x33222222, 0xFF050505.toInt()), null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            // Sweeping red light and cinematic ring.
            val sweepX = -w * .2f + (w * 1.4f * progress)
            p.shader = LinearGradient(sweepX - w * .12f, 0f, sweepX + w * .12f, 0f, intArrayOf(0x00FFFFFF, 0x22FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            val reveal = ((progress - .12f) / .48f).coerceIn(0f, 1f)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.color = red; p.alpha = (210 * reveal).toInt(); p.setShadowLayer(dp(18).toFloat(), 0f, 0f, red)
            canvas.drawArc(cx - w*.27f, cy - w*.27f, cx + w*.27f, cy + w*.27f, -90f, 320f * reveal, false, p)
            p.clearShadowLayer(); p.style = Paint.Style.FILL; p.alpha = 255
            val titleAlpha = ((progress - .24f) / .34f).coerceIn(0f, 1f)
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            p.textSize = w * .105f; p.color = red; p.alpha = (255 * titleAlpha).toInt(); p.setShadowLayer(dp(18).toFloat(), 0f, 0f, red)
            val scale = .84f + .16f * titleAlpha
            canvas.save(); canvas.scale(scale, scale, cx, cy)
            canvas.drawText("PJ", cx - w*.075f, cy + dp(10), p)
            p.clearShadowLayer(); p.color = white; canvas.drawText("TECHS", cx + w*.105f, cy + dp(10), p)
            canvas.restore()
            p.alpha = 255; p.textSize = w * .026f; p.typeface = Typeface.create("sans-serif", Typeface.NORMAL); p.letterSpacingCompat()
            p.color = white; p.alpha = (220 * ((progress - .52f)/.22f).coerceIn(0f,1f)).toInt()
            canvas.drawText("SMARTER HOME  •  BRIGHTER LIFE", cx, cy + w*.18f, p)
            p.color = red; p.textSize = w * .029f; p.alpha = (210 * ((progress - .68f)/.2f).coerceIn(0f,1f)).toInt()
            canvas.drawText("POWERED BY JIVA", cx, h * .82f, p)
            p.color = 0xFF8B8B8B.toInt(); p.textSize = w * .024f; p.alpha = (180 * (1f-progress)).toInt()
            canvas.drawText("TAP TO CONTINUE", cx, h * .92f, p)
            p.alpha = 255
        }
        private fun Paint.letterSpacingCompat() { /* intentionally no-op for Canvas compatibility */ }
        private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    }
}
