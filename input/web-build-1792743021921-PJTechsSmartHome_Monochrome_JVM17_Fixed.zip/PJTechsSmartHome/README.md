# PJ Techs Smart Home — Android Studio project

A native Kotlin Android starter project with a cinematic, animated PJ TECHS intro and a dark smart-home dashboard.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `PJTechsSmartHome` folder.
4. Allow Gradle sync to finish.
5. Choose **Build → Build APK(s)**.
6. Android Studio shows the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

## What is included
- 3.4-second animated intro: red light sweep, glowing circular reveal, zooming PJ TECHS title, tagline, and tap-to-skip.
- Dark red/black dashboard UI.
- Sample room-light and relay tiles with demo toggles.
- JIVA sample voice-command list.
- ESP32 address setup prompt.

## Important limitations
This is a **buildable UI starter**, not yet a complete hardware controller. Device toggles are demo-only and do not switch a real relay. To control the ESP32, implement HTTP requests that match your firmware endpoints and verify the ESP32 API/IP address. Voice recognition, online AI, device discovery, and music playback are not implemented in this starter. The intro uses original code-drawn graphics; it does not embed the referenced Short or copyrighted film/music assets.

## Compatibility
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- Package: `com.pjtechs.smarthome`


## Monochrome edition
This project variant uses a black, charcoal, white, and grey palette throughout the cinematic splash and dashboard. The relay cards remain demo-only until an ESP32 HTTP API is implemented.
