PJ Techs Monochrome Android project — JVM target fix

Fixed the reported Gradle error:
Inconsistent JVM-target compatibility detected for tasks compileDebugJavaWithJavac (1.8) and compileDebugKotlin (17).

The app module now sets Java sourceCompatibility and targetCompatibility to Java 17, and Kotlin jvmTarget to 17.

Replace the existing project folder in your repository with this folder's contents, commit and push, then rerun the Build Android APK GitHub Actions workflow. This addresses the specific JVM-target mismatch in the supplied log; a new build is still needed to confirm there are no further errors.
