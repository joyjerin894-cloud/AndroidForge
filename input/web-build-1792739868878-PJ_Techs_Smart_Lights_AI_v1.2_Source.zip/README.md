# PJ techs Smart Lights AI — Android Studio source (v1.2)

This ZIP contains Android Studio source code, not a prebuilt APK.

## UI and branding
- Modern dark interface with mint/gold accents and PJ techs branding.
- Original cinematic intro: black screen, animated PJ monogram, wordmark and light sweep. It uses dramatic title-card pacing without copying the Jailer 2 title card.
- Tap anywhere to skip the intro.

## Smart-home features
- Four configurable relay channels with custom names, HTTP ON/OFF paths and voice phrases.
- Custom displayed/spoken assistant name (default: Nova).
- Push-to-talk Android speech recognition and text-to-speech.
- Multiple saved ESP32 controller profiles; choose AP mode (commonly `http://192.168.4.1`) or router/Wi-Fi mode.
- Online AI chat through a user-configured backend endpoint.
- Android 6.0+ minimum (API 23), targeting modern Android.

## Song / background music
No commercial song audio is bundled. To use “One Sun One Moon,” use a legally obtained copy you have permission to use; do not redistribute copyrighted audio in the ZIP. This version's title animation is silent; a local audio picker/player is not included yet.

## ESP32 HTTP contract
- `GET /state` returns JSON such as `{"relay1":false,"relay2":true,"relay3":false,"relay4":false}`.
- Default relay paths are `/relay/1?state=on`, `/relay/1?state=off`, etc. Change them under Relay setup to match firmware.
- Device profiles do not auto-discover controllers; add each controller's address manually.

## Voice limitations
Voice commands are push-to-talk, not always-listening custom wake-word detection. Recognition may rely on an Android speech service and may require internet. The custom assistant name changes the displayed/spoken identity but does not create a new offline wake word.

## Security and electrical safety
- The app uses HTTP for local ESP32 endpoints; keep them on a trusted LAN and do not expose relay endpoints publicly without authentication.
- Keep AI provider credentials on a secure backend, never inside the APK.
- Verify relay module trigger voltage, isolation, and ratings before connecting mains loads. Have 230 V wiring handled by a qualified electrician.

## Build
Open this project in Android Studio with JDK 17 and build the `app` debug variant. The ZIP is source only; dependency resolution and build should be verified in Android Studio.
