package com.harmony.music

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale

class MainActivity : Activity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var player: MediaController? = null
    private var equalizer: Equalizer? = null
    private var isLight = false
    private val queue = mutableListOf<Pair<Uri, String>>()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var titleText: TextView
    private lateinit var urlInput: EditText
    private lateinit var searchInput: EditText
    private lateinit var lyricsInput: EditText
    private lateinit var queueText: TextView

    private val pickAudio = registerForActivityResultCompat()

    // A tiny wrapper keeps this starter project dependency-free beyond AndroidX Media3.
    private fun registerForActivityResultCompat(): AudioPicker {
        return AudioPicker { intent -> startActivityForResult(intent, 1001) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                player = controllerFuture?.get()
                status.text = "Player ready • choose a song"
            } catch (e: Exception) {
                status.text = "Player setup failed: ${e.message}"
            }
        }, { command -> runOnUiThread(command) })
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(20))
            setBackgroundColor(0xFF101018.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply {
            text = "♫  HARMONY"
            textSize = 28f
            setTextColor(0xFFE5D9FF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Your music. Your mood."
            textSize = 14f
            setTextColor(0xFFB6B3C5.toInt())
            setPadding(0, dp(4), 0, dp(14))
        })

        status = label("Connecting player…")
        root.addView(status)

        root.addView(button("Choose music from phone") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "audio/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            pickAudio.launch(intent)
        })

        titleText = label("Nothing playing")
        titleText.textSize = 19f
        titleText.setPadding(0, dp(16), 0, dp(8))
        root.addView(titleText)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(button("⏮", weight()) { player?.seekToPreviousMediaItem() })
        controls.addView(button("▶ / ⏸", weight()) {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        })
        controls.addView(button("⏭", weight()) { player?.seekToNextMediaItem() })
        root.addView(controls)

        root.addView(label("Play a direct audio URL you are allowed to use"))
        urlInput = EditText(this).apply {
            hint = "https://example.com/song.mp3"
            setHintTextColor(0xFF888699.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            setSingleLine(true)
        }
        root.addView(urlInput)
        root.addView(button("Play online audio URL") {
            val raw = urlInput.text.toString().trim()
            if (raw.startsWith("https://")) playUri(Uri.parse(raw), raw.substringAfterLast('/').ifBlank { "Online audio" })
            else toast("Enter a valid HTTPS audio URL.")
        })

        root.addView(label("YouTube search"))
        searchInput = EditText(this).apply {
            hint = "Search songs on YouTube"
            setHintTextColor(0xFF888699.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 14f
            setSingleLine(true)
        }
        root.addView(searchInput)
        root.addView(button("Search YouTube") {
            val q = searchInput.text.toString().trim()
            if (q.isNotEmpty()) {
                val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } else toast("Type a song or artist first.")
        })
        root.addView(label("YouTube opens in its official app/browser. Harmony does not extract or download YouTube audio."))

        root.addView(button("Equalizer / bass boost") { showEqualizer() })
        root.addView(button("Toggle light / dark theme") {
            isLight = !isLight
            root.setBackgroundColor(if (isLight) 0xFFF6F3FF.toInt() else 0xFF101018.toInt())
            status.setTextColor(if (isLight) 0xFF252033.toInt() else 0xFFB6B3C5.toInt())
            titleText.setTextColor(if (isLight) 0xFF252033.toInt() else 0xFFFFFFFF.toInt())
            toast(if (isLight) "Light theme" else "Dark theme")
        })

        root.addView(label("Lyrics (paste or type your lyrics)"))
        lyricsInput = EditText(this).apply {
            hint = "Lyrics appear here…"
            minLines = 3
            gravity = Gravity.TOP
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888699.toInt())
        }
        root.addView(lyricsInput)

        root.addView(label("Playlist"))
        queueText = label("No songs added yet")
        root.addView(queueText)
        root.addView(button("Clear playlist") {
            queue.clear()
            player?.clearMediaItems()
            refreshQueue()
            titleText.text = "Nothing playing"
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1001 || resultCode != RESULT_OK || data == null) return
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) addPicked(clip.getItemAt(i).uri)
        } else data.data?.let { addPicked(it) }
        if (queue.isNotEmpty()) {
            player?.clearMediaItems()
            queue.forEach { (uri, name) ->
                player?.addMediaItem(
                    MediaItem.Builder().setUri(uri)
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(name).build()).build()
                )
            }
            player?.prepare()
            player?.play()
            titleText.text = queue.first().second
            status.text = "Playing local playlist"
        }
        refreshQueue()
    }

    private fun addPicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Local song"
        if (queue.none { it.first == uri }) queue.add(uri to name)
    }

    private fun playUri(uri: Uri, name: String) {
        val p = player
        if (p == null) {
            toast("Player is still starting. Try again in a moment.")
            return
        }
        p.setMediaItem(MediaItem.Builder().setUri(uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(name).build()).build())
        p.prepare()
        p.play()
        titleText.text = name
        status.text = "Playing"
        if (queue.none { it.first == uri }) {
            queue.add(uri to name)
            refreshQueue()
        }
    }

    private fun showEqualizer() {
        val p = player
        if (p == null || p.audioSessionId == 0) {
            toast("Start playing a song first, then open the equalizer.")
            return
        }
        try {
            equalizer?.release()
            equalizer = Equalizer(0, p.audioSessionId).apply { enabled = true }
            val eq = equalizer ?: return
            val bands = eq.numberOfBands.toInt()
            val min = eq.bandLevelRange[0].toInt()
            val max = eq.bandLevelRange[1].toInt()
            val layout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(8), dp(18), dp(8))
            }
            val bass = SeekBar(this).apply {
                max = 100
                progress = 50
            }
            layout.addView(label("Bass boost (simple preamp-style control)"))
            layout.addView(bass)
            val bandBars = mutableListOf<Pair<Short, SeekBar>>()
            for (i in 0 until bands) {
                val band = i.toShort()
                val freq = eq.getCenterFreq(band) / 1000
                layout.addView(label("${freq} Hz"))
                val seek = SeekBar(this).apply {
                    max = max - min
                    progress = -min
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                            if (fromUser) try { eq.setBandLevel(band, (value + min).toShort()) } catch (_: Exception) {}
                        }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    })
                }
                layout.addView(seek)
                bandBars.add(band to seek)
            }
            AlertDialog.Builder(this)
                .setTitle("Harmony Equalizer")
                .setView(ScrollView(this).apply { addView(layout) })
                .setPositiveButton("Done", null)
                .setOnDismissListener { /* Keep effect attached while the player is active. */ }
                .show()
        } catch (e: Exception) {
            toast("Equalizer not supported by this device: ${e.message}")
        }
    }

    private fun refreshQueue() {
        queueText.text = if (queue.isEmpty()) "No songs added yet" else
            queue.mapIndexed { i, pair -> "${i + 1}. ${pair.second}" }.joinToString("\n")
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(0xFFB6B3C5.toInt())
        setPadding(0, dp(8), 0, dp(4))
    }

    private fun button(text: String, params: LinearLayout.LayoutParams? = null, action: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { action() }
            val p = params ?: LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.setMargins(0, dp(4), dp(4), dp(4))
            layoutParams = p
        }
    }

    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        equalizer?.release()
        controllerFuture?.let { MediaController.releaseFuture(it) }
        player = null
        super.onDestroy()
    }

    private class AudioPicker(val launch: (Intent) -> Unit)
}
