# ELECTRO Glass Studio Update

## Changes
- Removed tap-to-skip behavior from the cinematic opening. The title card now completes its selected 1–30 second duration before the dashboard opens. The opening can still be disabled deliberately in Customization Settings.
- Added a custom wallpaper picker using Android's document picker. Selected image permission is persisted and the wallpaper is applied behind translucent dashboard pages.
- Added glass shape presets: Liquid Glass / Ultra Round, Soft Capsule / HyperOS, Crystal Glass / Balanced, and Precision Tech / Squared.
- Added a glass opacity slider and saved its value.
- Preserved the existing accent colour, background palette, 1,000 opening preset list, opening look, custom logo, boot audio, assistant settings, device labels, wattage estimates, master relay control, per-relay controls, scenes, and ESP32 connection screen.

## ESP32 action compatibility
Real relay actions require ESP32 firmware reachable on the same trusted Wi-Fi network and implementing `GET /api/status` and `GET /api/relay?id=N&state=on|off` for relay IDs 1–4. The app includes individual relay controls, master ON/OFF, and Night / Evening / Focus / Away scenes. A cloud AI response alone does not switch hardware. Do not expose the ESP32 web server directly to the public internet.

## Build
Upload the project folder to the AndroidForge repository and run the existing **Build Android APK** GitHub Actions workflow. This ZIP is source code; a full Gradle build could not be verified in this environment.
