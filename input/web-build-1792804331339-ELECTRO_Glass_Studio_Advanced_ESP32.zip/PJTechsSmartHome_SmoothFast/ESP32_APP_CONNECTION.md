# Electro ESP32 app connection

## Firmware contract
`GET /api/status` must return HTTP 200 and JSON, for example:
`{"connected":true,"relays":[false,false,false,false]}`

Relay command format:
`GET /api/relay?id=1&state=on`
where `id` is 1–4 and `state` is `on` or `off`. Return HTTP 200 for a successful command and a JSON status response. The Android app uses this contract in its Connect ESP32 dialog and four device cards.

## Connect
1. Flash compatible firmware to the ESP32-S3 Super Mini.
2. Connect the ESP32 and phone to the same Wi-Fi, or use an ESP32 access point only if the installed firmware explicitly enables AP mode.
3. In Electro, tap **CONNECT ESP32**, enter the board's IP address, and tap **TEST CONNECTION**.
4. Wait for `CONNECTED` and the status JSON. Tap a device card to send a relay command.

The four GPIO assignments and relay polarity belong to the firmware and must be checked against the exact board and relay module. This app integration does not make hardware wiring safe by itself.

## New dashboard power switches
The dashboard now uses animated black-glass power switches with a gold accent. The switch updates only after the ESP32 confirms the relay command, so the UI does not pretend the hardware changed when a request fails. The switch and its device card share the same toggle action.
