# ELECTRO Monochrome Title Card Update

- Default opening migrated to a high-contrast black-and-white action title-card aesthetic: hard diagonal slashes, scan-line accents, sharp white/silver ELECTRO lettering, fast light streaks and a restrained monochrome particle field.
- Added the `BEAST-STYLE • MONOCHROME TITLE CARD` opening theme. This is an original high-energy title-card treatment inspired by action-cinema pacing, not a copy of a film's exact title artwork.
- Replaced the basic animation dropdown with a searchable, dark list view of 1,000 animation presets. Selecting a row updates the chosen preset used by preview and save.
- Added functional settings switches for cinematic opening, switch haptic feedback, and relay-action confirmation. The existing boot-audio checkbox remains functional.
- The relay confirmation option asks before sending ON/OFF commands to the configured ESP32. Haptic feedback runs when enabled.

Build validation: ZIP integrity is checked. A full Android Gradle build must still be confirmed in GitHub Actions.
