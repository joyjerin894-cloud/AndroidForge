# PJ techs Smart Lights AI — Android Studio source v1.2

## Opening animation
The app starts with a smooth, native Compose cinematic title card: near-black background, glowing PJ monogram, slow pulse, moving mint/blue light beam, animated PJ techs wordmark, and a light sweep. Tap anywhere to skip. The animation is original rather than a frame-for-frame copy of the linked YouTube Short; the link could not be previewed by the build environment. Send a screen recording or a few screenshots if you want a closer match.

## Included
- Dark modern UI with mint/gold accents.
- Custom assistant display/spoken name (default Nova).
- Four configurable relay channels, custom names, HTTP paths and voice phrases.
- Multiple saved ESP32 controller profiles.
- Push-to-talk Android speech recognition and text-to-speech.
- Online AI chat via a user-configured backend URL.
- Android minimum API 23 (Android 6.0+), Java 17.

## Important limitations
- Source ZIP only; no compiled APK is included. Open in Android Studio, sync Gradle, then Build > Build APK(s).
- The YouTube video was not accessible for direct inspection, so this is a smooth original cinematic interpretation, not an exact recreation.
- No copyrighted song or video audio is bundled.
- Voice control is push-to-talk, not an always-listening offline wake word.
- Controller profiles require compatible ESP32 HTTP endpoints; default state path is `/state`, relay paths are configurable in Relay setup.

## Safety
Keep local HTTP endpoints on a trusted network. Do not expose relay endpoints publicly without authentication. Keep AI provider keys on a secure backend. Verify relay isolation and ratings; have mains wiring handled by a qualified electrician.
