package com.example.smartlightsai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Ink = Color(0xFF0A1020)
private val Panel = Color(0xFF141D30)
private val Panel2 = Color(0xFF1B2940)
private val Mint = Color(0xFF65E6C4)
private val Gold = Color(0xFFF3B86B)
private val Muted = Color(0xFFAAB6CC)

private data class RelayConfig(val name: String, val onPath: String, val offPath: String, val voiceOn: String, val voiceOff: String)
private data class DeviceProfile(val name: String, val baseUrl: String, val statePath: String)

private val defaultRelays = listOf(
    RelayConfig("Main Lights", "/relay/1?state=on", "/relay/1?state=off", "turn on main lights", "turn off main lights"),
    RelayConfig("Bedroom", "/relay/2?state=on", "/relay/2?state=off", "turn on bedroom", "turn off bedroom"),
    RelayConfig("Fan", "/relay/3?state=on", "/relay/3?state=off", "turn on fan", "turn off fan"),
    RelayConfig("Accent Lights", "/relay/4?state=on", "/relay/4?state=off", "turn on accent lights", "turn off accent lights")
)

private class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("pj_techs_smart_lights", Context.MODE_PRIVATE)
    var baseUrl: String get() = prefs.getString("baseUrl", "http://192.168.4.1") ?: "http://192.168.4.1"
        set(v) { prefs.edit().putString("baseUrl", v.trim().trimEnd('/')).apply() }
    var statePath: String get() = prefs.getString("statePath", "/state") ?: "/state"
        set(v) { prefs.edit().putString("statePath", v).apply() }
    var aiUrl: String get() = prefs.getString("aiUrl", "") ?: ""
        set(v) { prefs.edit().putString("aiUrl", v.trim()).apply() }
    var assistantName: String get() = prefs.getString("assistantName", "Nova") ?: "Nova"
        set(v) { prefs.edit().putString("assistantName", v.trim().ifBlank { "Nova" }).apply() }
    fun relay(i: Int): RelayConfig {
        val d = defaultRelays[i]
        return RelayConfig(prefs.getString("relay_${i}_name", d.name) ?: d.name,
            prefs.getString("relay_${i}_on", d.onPath) ?: d.onPath,
            prefs.getString("relay_${i}_off", d.offPath) ?: d.offPath,
            prefs.getString("relay_${i}_voiceOn", d.voiceOn) ?: d.voiceOn,
            prefs.getString("relay_${i}_voiceOff", d.voiceOff) ?: d.voiceOff)
    }
    fun saveRelay(i: Int, r: RelayConfig) { prefs.edit().putString("relay_${i}_name", r.name).putString("relay_${i}_on", r.onPath)
        .putString("relay_${i}_off", r.offPath).putString("relay_${i}_voiceOn", r.voiceOn).putString("relay_${i}_voiceOff", r.voiceOff).apply() }
    fun devices(): List<DeviceProfile> {
        val raw = prefs.getString("devices", null) ?: return listOf(DeviceProfile("ESP32 Access Point", "http://192.168.4.1", "/state"))
        return try { val a = JSONArray(raw); (0 until a.length()).map { val o = a.getJSONObject(it); DeviceProfile(o.optString("name"), o.optString("url"), o.optString("state", "/state")) } }
        catch (_: Exception) { listOf(DeviceProfile("ESP32 Access Point", "http://192.168.4.1", "/state")) }
    }
    fun saveDevices(list: List<DeviceProfile>) { val a = JSONArray(); list.forEach { a.put(JSONObject().put("name", it.name).put("url", it.baseUrl).put("state", it.statePath)) }; prefs.edit().putString("devices", a.toString()).apply() }
}

private fun httpRequest(urlText: String, method: String = "GET", body: String? = null): String {
    val conn = URL(urlText).openConnection() as HttpURLConnection
    conn.requestMethod = method; conn.connectTimeout = 3500; conn.readTimeout = 3500
    conn.setRequestProperty("Accept", "application/json")
    if (body != null) { conn.doOutput = true; conn.setRequestProperty("Content-Type", "application/json"); conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) } }
    try { val code = conn.responseCode; val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val result = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IllegalStateException("HTTP $code: $result")
        return result
    } finally { conn.disconnect() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PJTechsApp() } }
}

@Composable
private fun BrandMark(compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(if (compact) 42.dp else 52.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Mint, Color(0xFF398BCB)))), contentAlignment = Alignment.Center) {
            Text("PJ", color = Ink, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
        }
        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text("PJ techs", color = Color.White, fontWeight = FontWeight.ExtraBold, style = if (compact) MaterialTheme.typography.titleMedium else MaterialTheme.typography.headlineSmall)
            Text("SMART LIVING  •  CONTROL", color = Mint, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DarkCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Panel), content = content)
}

@Composable
private fun CinematicIntro(onFinish: () -> Unit) {
    var finished by remember { mutableStateOf(false) }
    val transition = rememberInfiniteTransition(label = "introGlow")
    val pulse by transition.animateFloat(
        initialValue = 0.94f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), repeatMode = androidx.compose.animation.core.RepeatMode.Reverse),
        label = "logoPulse"
    )
    val shimmer by transition.animateFloat(
        initialValue = -1.2f, targetValue = 1.8f,
        animationSpec = infiniteRepeatable(tween(2100, easing = FastOutSlowInEasing), repeatMode = androidx.compose.animation.core.RepeatMode.Restart),
        label = "shimmer"
    )
    val reveal = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) {
        reveal.animateTo(1f, tween(1050, easing = FastOutSlowInEasing))
        delay(1650)
        if (!finished) onFinish()
    }
    Box(
        Modifier.fillMaxSize().background(Color(0xFF020305)).clickable {
            if (!finished) { finished = true; onFinish() }
        }, contentAlignment = Alignment.Center
    ) {
        // Soft cinematic glow and a slow moving light beam, rendered natively for smooth Android animation.
        Box(Modifier.fillMaxWidth(0.86f).height(270.dp).offset(x = (shimmer * 26).dp).alpha(0.14f)
            .background(Brush.horizontalGradient(listOf(Color.Transparent, Mint, Color(0xFF6A8CFF), Color.Transparent))))
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(17.dp)) {
            Box(Modifier.size(116.dp).scale(pulse).clip(RoundedCornerShape(30.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFB7F7E8), Color(0xFF65E6C4), Color(0xFF2873A4)))),
                contentAlignment = Alignment.Center) {
                Text("PJ", color = Color(0xFF04070A), fontWeight = FontWeight.Black, style = MaterialTheme.typography.displayMedium)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("PJ techs", color = Color.White, fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.headlineLarge, modifier = Modifier.alpha(reveal.value).scale(0.92f + reveal.value * 0.08f))
                Text("SMART LIVING  •  CONTROL", color = Mint, fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.labelMedium, modifier = Modifier.alpha(reveal.value))
            }
            Box(Modifier.fillMaxWidth(0.58f).height(2.dp).clip(CircleShape).background(Color(0xFF1A2631))) {
                Box(Modifier.fillMaxWidth(reveal.value).fillMaxHeight().background(Brush.horizontalGradient(listOf(Mint, Gold))))
            }
            Text("TAP TO ENTER", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.7f))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PJTechsApp() {
    var showIntro by remember { mutableStateOf(true) }
    val context = LocalContext.current
    val store = remember { SettingsStore(context) }
    val scope = rememberCoroutineScope()
    var page by remember { mutableStateOf("Home") }
    var baseUrl by remember { mutableStateOf(store.baseUrl) }
    var statePath by remember { mutableStateOf(store.statePath) }
    var aiUrl by remember { mutableStateOf(store.aiUrl) }
    var assistantName by remember { mutableStateOf(store.assistantName) }
    var status by remember { mutableStateOf("Ready to connect") }
    var busy by remember { mutableStateOf(false) }
    var relayStates by remember { mutableStateOf(listOf(false, false, false, false)) }
    var relayConfigs by remember { mutableStateOf((0..3).map { store.relay(it) }) }
    var devices by remember { mutableStateOf(store.devices()) }
    var selectedDevice by remember { mutableIntStateOf(0) }
    var newDeviceName by remember { mutableStateOf("") }
    var newDeviceUrl by remember { mutableStateOf("http://192.168.4.1") }
    var newDeviceState by remember { mutableStateOf("/state") }
    var chatInput by remember { mutableStateOf("") }
    var chatLines by remember { mutableStateOf(listOf("${store.assistantName}: Hi! I'm your PJ techs assistant. Set an AI backend in Settings for online chat.")) }
    var voiceStatus by remember { mutableStateOf("Tap the mic to speak a command") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context) { val engine = TextToSpeech(context) { result -> if (result == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }; tts = engine; onDispose { engine.stop(); engine.shutdown(); tts = null } }

    fun rootUrl() = baseUrl.trim().trimEnd('/')
    fun refreshStates() {
        scope.launch { try {
            val raw = withContext(Dispatchers.IO) { httpRequest(rootUrl() + statePath) }; val json = JSONObject(raw)
            relayStates = (1..4).map { n -> when {
                json.has("relay$n") -> json.optBoolean("relay$n", false)
                json.has("r$n") -> json.optBoolean("r$n", false)
                json.has("relays") && json.optJSONArray("relays") != null -> json.getJSONArray("relays").optBoolean(n - 1, false)
                else -> throw IllegalStateException("State response needs relay1..relay4, r1..r4 or relays[]")
            } }; status = "Connected • states synced"
        } catch (e: Exception) { status = "Not connected • ${e.message ?: "check Wi-Fi/IP"}" } }
    }
    fun setRelay(index: Int, on: Boolean) {
        if (busy) return
        busy = true
        scope.launch { try { val path = if (on) relayConfigs[index].onPath else relayConfigs[index].offPath
            withContext(Dispatchers.IO) { httpRequest(rootUrl() + if (path.startsWith("/")) path else "/$path") }
            relayStates = relayStates.toMutableList().also { it[index] = on }; status = "${relayConfigs[index].name} turned ${if (on) "on" else "off"}"; delay(180); refreshStates()
        } catch (e: Exception) { status = "Command failed • ${e.message ?: "network error"}" } finally { busy = false } }
    }
    fun processVoice(phrase: String) {
        val normalized = phrase.lowercase(Locale.getDefault()).trim()
        val match = relayConfigs.withIndex().firstOrNull { (_, r) -> normalized.contains(r.voiceOn.lowercase()) || normalized.contains(r.voiceOff.lowercase()) || normalized.contains("turn on ${r.name.lowercase()}") || normalized.contains("turn off ${r.name.lowercase()}") || normalized.contains("switch on ${r.name.lowercase()}") || normalized.contains("switch off ${r.name.lowercase()}") }
        if (match == null) { voiceStatus = "Heard: $phrase • no matching relay command"; tts?.speak("I heard $phrase, but no relay command matched. Edit voice phrases in Relay setup.", TextToSpeech.QUEUE_FLUSH, null, "voiceResult"); return }
        val r = match.value
        val on = normalized.contains(r.voiceOn.lowercase()) || normalized.contains("turn on ${r.name.lowercase()}") || normalized.contains("switch on ${r.name.lowercase()}")
        voiceStatus = "Command: ${r.name} ${if (on) "on" else "off"}"; tts?.speak("${r.name} ${if (on) "on" else "off"}", TextToSpeech.QUEUE_FLUSH, null, "voiceResult"); setRelay(match.index, on)
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (spoken != null) processVoice(spoken) else voiceStatus = "No speech detected. Tap the mic and try again."
    }
    fun startVoice() {
        try { val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag()); putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a relay command") }; speechLauncher.launch(intent) }
        catch (_: Exception) { voiceStatus = "Speech recognition is not available on this device. Install/enable a speech service." }
    }

    LaunchedEffect(baseUrl, statePath, page) { if (page == "Home") { while (true) { refreshStates(); delay(2500) } } }
    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, secondary = Gold, background = Ink, surface = Panel, onPrimary = Ink, onBackground = Color.White, onSurface = Color.White, surfaceVariant = Panel2, onSurfaceVariant = Muted)) {
        Box(Modifier.fillMaxSize()) {
        Scaffold(containerColor = Ink, topBar = { TopAppBar(title = { BrandMark(compact = true) }, actions = { IconButton(onClick = { page = "Settings" }) { Icon(Icons.Default.Settings, "Settings", tint = Mint) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)) },
            bottomBar = { NavigationBar(containerColor = Panel, contentColor = Mint) {
                NavigationBarItem(selected = page == "Home", onClick = { page = "Home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = page == "Commands", onClick = { page = "Commands" }, icon = { Icon(Icons.Default.Tune, null) }, label = { Text("Relay setup") })
                NavigationBarItem(selected = page == "AI", onClick = { page = "AI" }, icon = { Icon(Icons.Default.ChatBubbleOutline, null) }, label = { Text("Assistant") })
                NavigationBarItem(selected = page == "Settings", onClick = { page = "Settings" }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
            } }) { padding ->
            when (page) {
                "Home" -> LazyColumn(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 20.dp)) {
                    item { Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Color(0xFF1A3445), Color(0xFF172038), Color(0xFF382B38)))).padding(20.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            BrandMark()
                            Text("Your home. Your rules.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Smart control, voice commands and custom scenes — all in one place.", color = Muted)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Box(Modifier.size(8.dp).clip(CircleShape).background(if (status.startsWith("Connected")) Mint else Gold)); Text(status, color = if (status.startsWith("Connected")) Mint else Gold, style = MaterialTheme.typography.bodySmall) }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { refreshStates() }) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Sync") }; OutlinedButton(onClick = { page = "Settings" }) { Icon(Icons.Default.Wifi, null); Spacer(Modifier.width(6.dp)); Text("Connect") } }
                        }
                    } }
                    item { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) { Column { Text("YOUR DEVICES", color = Mint, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold); Text(devices.getOrNull(selectedDevice)?.name ?: "ESP32", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }; TextButton(onClick = { page = "Settings" }) { Icon(Icons.Default.Devices, null); Text("Manage") } } }
                    item { DarkCard { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Active controller", color = Muted, style = MaterialTheme.typography.labelMedium); var expanded by remember { mutableStateOf(false) }
                        Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Devices, null); Spacer(Modifier.width(8.dp)); Text(devices.getOrNull(selectedDevice)?.name ?: "Select device"); Spacer(Modifier.weight(1f)); Text("⌄") }; DropdownMenu(expanded, { expanded = false }) { devices.forEachIndexed { i, d -> DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDevice = i; baseUrl = d.baseUrl; statePath = d.statePath; store.baseUrl = baseUrl; store.statePath = statePath; expanded = false; status = "Selected ${d.name}" }) } } }
                    } } }
                    itemsIndexed(relayConfigs) { index, relay -> DarkCard {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(if (relayStates[index]) Brush.linearGradient(listOf(Mint, Color(0xFF6EB7F4))) else Brush.linearGradient(listOf(Panel2, Color(0xFF263149)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Lightbulb, null, tint = if (relayStates[index]) Ink else Muted, modifier = Modifier.size(28.dp)) }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(relay.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(if (relayStates[index]) "ON  •  ACTIVE" else "OFF  •  STANDBY", color = if (relayStates[index]) Mint else Muted, style = MaterialTheme.typography.labelSmall) }
                            Switch(checked = relayStates[index], enabled = !busy, onCheckedChange = { setRelay(index, it) })
                        }
                    } }
                    item { DarkCard { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.SmartToy, null, tint = Mint); Spacer(Modifier.width(8.dp)); Text("$assistantName voice control", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium) }; Text(voiceStatus, color = Muted, style = MaterialTheme.typography.bodySmall); Button(onClick = { startVoice() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Ink)) { Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("Speak a command", fontWeight = FontWeight.Bold) }; Text("Push-to-talk works with the speech service on your Android device. It is not an always-listening wake word.", color = Muted, style = MaterialTheme.typography.bodySmall) } } }
                }
                "Commands" -> Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Relay studio", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Customize each relay's label, HTTP paths and exact phrases recognized by voice control.", color = Muted)
                    relayConfigs.forEachIndexed { i, cfg -> var name by remember(cfg.name) { mutableStateOf(cfg.name) }; var onPath by remember(cfg.onPath) { mutableStateOf(cfg.onPath) }; var offPath by remember(cfg.offPath) { mutableStateOf(cfg.offPath) }; var voiceOn by remember(cfg.voiceOn) { mutableStateOf(cfg.voiceOn) }; var voiceOff by remember(cfg.voiceOff) { mutableStateOf(cfg.voiceOff) }
                        DarkCard { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("CHANNEL 0${i + 1}", color = Mint, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            OutlinedTextField(name, { name = it }, label = { Text("Relay name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(onPath, { onPath = it }, label = { Text("ON URL path") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(offPath, { offPath = it }, label = { Text("OFF URL path") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(voiceOn, { voiceOn = it }, label = { Text("Voice phrase to turn ON") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(voiceOff, { voiceOff = it }, label = { Text("Voice phrase to turn OFF") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Button(onClick = { val updated = cfg.copy(name = name.ifBlank { "Relay ${i + 1}" }, onPath = onPath, offPath = offPath, voiceOn = voiceOn, voiceOff = voiceOff); store.saveRelay(i, updated); relayConfigs = relayConfigs.toMutableList().also { it[i] = updated }; status = "${updated.name} settings saved" }, modifier = Modifier.fillMaxWidth()) { Text("Save channel") }
                        } }
                    }
                    OutlinedButton(onClick = { defaultRelays.forEachIndexed { i, r -> store.saveRelay(i, r) }; relayConfigs = defaultRelays; status = "Default commands restored" }, modifier = Modifier.fillMaxWidth()) { Text("Restore defaults") }
                }
                "AI" -> Column(Modifier.padding(padding).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    DarkCard { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.SmartToy, null, tint = Mint); Spacer(Modifier.width(8.dp)); Text(assistantName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }; Text("Online assistant connection", color = Muted); if (aiUrl.isBlank()) Text("Add your secure AI backend URL in Settings to enable replies.", color = Gold) } }
                    Card(Modifier.weight(1f).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) { LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { itemsIndexed(chatLines) { _, line -> Text(line, color = if (line.startsWith("${assistantName}:")) Mint else Color.White); HorizontalDivider(color = Panel2) } } }
                    OutlinedTextField(chatInput, { chatInput = it }, label = { Text("Message $assistantName") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { val q = chatInput.trim(); chatInput = ""; chatLines = chatLines + "You: $q"; scope.launch { try { val body = JSONObject().put("message", q).toString(); val raw = withContext(Dispatchers.IO) { httpRequest(aiUrl, "POST", body) }; val reply = JSONObject(raw).optString("reply", raw); chatLines = chatLines + "$assistantName: $reply"; tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "assistantReply") } catch (e: Exception) { chatLines = chatLines + "Connection error: ${e.message ?: "check backend URL"}" } } }, enabled = chatInput.isNotBlank() && aiUrl.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(8.dp)); Text("Send to $assistantName") }
                    Text("For safety, keep AI provider API keys on your backend, not inside the APK.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                else -> Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Personalize your system", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    DarkCard { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { BrandMark(); OutlinedTextField(assistantName, { assistantName = it }, label = { Text("Voice assistant name") }, modifier = Modifier.fillMaxWidth(), singleLine = true); Text("This changes the name shown in the app and spoken replies. The mic is push-to-talk, not a custom wake-word detector.", color = Muted, style = MaterialTheme.typography.bodySmall) } }
                    DarkCard { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("Controller connection", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("Access point: connect to your ESP32 Wi-Fi and use 192.168.4.1. Router mode: phone and controller must share Wi-Fi.", color = Muted)
                        OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("ESP32 base URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(statePath, { statePath = it }, label = { Text("State endpoint path") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(aiUrl, { aiUrl = it }, label = { Text("Online AI backend URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    } }
                    DarkCard { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Devices, null, tint = Mint); Spacer(Modifier.width(8.dp)); Text("Device profiles", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }; Text("Save separate ESP32 controllers by name and switch between them. Devices must expose the configured HTTP endpoints.", color = Muted)
                        devices.forEachIndexed { i, d -> Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(d.name, fontWeight = FontWeight.SemiBold); Text(d.baseUrl, color = Muted, style = MaterialTheme.typography.bodySmall) }; TextButton(onClick = { selectedDevice = i; baseUrl = d.baseUrl; statePath = d.statePath; status = "Selected ${d.name}" }) { Text("Use") }; if (devices.size > 1) TextButton(onClick = { devices = devices.filterIndexed { idx, _ -> idx != i }; store.saveDevices(devices); selectedDevice = 0 }) { Text("Remove", color = Gold) } } }
                        HorizontalDivider(color = Panel2); OutlinedTextField(newDeviceName, { newDeviceName = it }, label = { Text("New device name") }, modifier = Modifier.fillMaxWidth(), singleLine = true); OutlinedTextField(newDeviceUrl, { newDeviceUrl = it }, label = { Text("Device base URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true); OutlinedTextField(newDeviceState, { newDeviceState = it }, label = { Text("State path") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Button(onClick = { val d = DeviceProfile(newDeviceName.ifBlank { "Controller ${devices.size + 1}" }, newDeviceUrl.trim().trimEnd('/'), if (newDeviceState.startsWith("/")) newDeviceState else "/$newDeviceState"); devices = devices + d; store.saveDevices(devices); selectedDevice = devices.lastIndex; baseUrl = d.baseUrl; statePath = d.statePath; newDeviceName = ""; status = "Added ${d.name}" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Add device profile") }
                    } }
                    Button(onClick = { assistantName = assistantName.trim().ifBlank { "Nova" }; baseUrl = baseUrl.trim().trimEnd('/'); statePath = if (statePath.startsWith("/")) statePath else "/$statePath"; store.assistantName = assistantName; store.baseUrl = baseUrl; store.statePath = statePath; store.aiUrl = aiUrl; if (devices.isNotEmpty() && selectedDevice in devices.indices) { devices = devices.toMutableList().also { it[selectedDevice] = it[selectedDevice].copy(baseUrl = baseUrl, statePath = statePath) }; store.saveDevices(devices) }; status = "Settings saved"; page = "Home" }, modifier = Modifier.fillMaxWidth()) { Text("Save all settings") }
                    Text("Compatibility: configured for Android 6.0+ (API 23) and modern Android versions. Speech recognition availability depends on the device's installed speech service.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (showIntro) CinematicIntro(onFinish = { showIntro = false })
        }
    }
}