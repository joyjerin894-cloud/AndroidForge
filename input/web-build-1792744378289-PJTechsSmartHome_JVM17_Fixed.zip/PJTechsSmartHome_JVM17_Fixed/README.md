# PJ Techs Smart Home — Cinematic Android Studio Project

A native Kotlin Android app concept with an original cinematic title-card opening inspired by the broad, high-impact atmosphere of South Indian action-film title reveals, using your Jailer 2 reference as mood inspiration. It does **not** reproduce the movie title/logo, footage, soundtrack, or Rajinikanth's likeness.

## Opening animation
- Approx. 4.8-second native Canvas animation.
- Ember particles, drifting red haze, glowing ring reveal, metallic PJ TECHS typography, red horizon, animated anamorphic light streak, impact flash, and tagline.
- Rendered live at the device's display resolution; it is not a low-resolution pre-rendered splash video.
- Tap the screen to skip the intro.

## Why this ZIP is not 500 MB
The animation is rendered by Android code at runtime, so making the ZIP larger than 500 MB would mean adding unrelated or duplicated data. It would not improve visual quality. This project deliberately stays small and scalable. If you want a true 4K video intro, you would need a separately produced video asset and rights-cleared music; that would increase the APK size and load time.

## Build the APK
1. Extract the ZIP.
2. Open the `PJTechsSmartHome` folder in Android Studio.
3. Install the Android SDK requested by Gradle and sync the project.
4. Choose **Build → Build APK(s)**.
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Current status
- Cinematic splash and smart-home dashboard are included.
- Device cards are demo UI only. The ESP32 address dialog is a setup placeholder; actual relay API and voice-control integration must be implemented and tested before controlling hardware.
- No APK is prebuilt in this ZIP.
