package com.pjtechs.smarthome

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.animation.ValueAnimator
import android.view.View
import android.view.Gravity
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.graphics.drawable.GradientDrawable

private const val BG = 0xFF050505.toInt()
private const val PANEL = 0xFF171717.toInt()
private const val RED = 0xFFE6E6E6.toInt()
private const val MUTED = 0xFF969696.toInt()

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        setContentView(CinematicSplash(this) { showDashboard() })
    }

    private fun showDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(BG)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        page.addView(scroll)

        val brand = TextView(this).apply {
            text = "PJ TECHS"; textSize = 27f; letterSpacing = .12f; setTextColor(RED)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        root.addView(brand)
        root.addView(label("SMART HOME  •  BRIGHTER LIFE", 11f, MUTED).also { it.setPadding(0, dp(3), 0, dp(20)) })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = rounded(PANEL, 22)
        }
        hero.addView(label("YOUR HOME, UNDER YOUR CONTROL", 11f, MUTED))
        hero.addView(label("Good to see you.", 24f, Color.WHITE).also { it.setPadding(0, dp(7), 0, dp(5)) })
        hero.addView(label("Assistant JIVA  •  Local network mode", 13f, 0xFFBDBDBD.toInt()))
        root.addView(hero, lp(match, wrap, 0, 0, 0, 18))

        root.addView(label("QUICK CONTROL", 12f, MUTED).also { it.setPadding(0, 0, 0, dp(10)) })
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(deviceCard("◉", "Living room", "Light", true), LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginEnd = dp(7) })
        row1.addView(deviceCard("◌", "Bedroom", "Light", false), LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginStart = dp(7) })
        row2.addView(deviceCard("✣", "Ceiling fan", "Relay 2", false), LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginEnd = dp(7); topMargin = dp(14) })
        row2.addView(deviceCard("▣", "Auxiliary", "Relay 3", false), LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginStart = dp(7); topMargin = dp(14) })
        grid.addView(row1); grid.addView(row2); root.addView(grid)

        val voice = TextView(this).apply {
            text = "  ◉     Talk to JIVA\n         Tap to see sample voice commands"
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(15), dp(18), dp(15)); background = rounded(0xFF202020.toInt(), 18)
            setOnClickListener { showCommands() }
        }
        root.addView(voice, lp(match, dp(76), 0, 18, 0, 12))
        val setup = Button(this).apply {
            text = "SET ESP32 CONNECTION"; setTextColor(Color.WHITE); isAllCaps = false
            background = rounded(RED, 16)
            setOnClickListener { showConnectionDialog() }
        }
        root.addView(setup, lp(match, dp(52)))
        root.addView(label("Demo interface • Configure your ESP32 address before controlling real relays.", 11f, MUTED).also { it.setPadding(2, dp(12), 2, 0) })
        setContentView(page)
    }

    private fun deviceCard(icon: String, title: String, subtitle: String, initiallyOn: Boolean): View {
        var on = initiallyOn
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(13), dp(13), dp(12)); background = rounded(PANEL, 20)
        }
        val glyph = TextView(this).apply { text = icon; textSize = 26f; setTextColor(if (on) RED else MUTED) }
        val name = label(title, 15f, Color.WHITE).also { it.typeface = Typeface.DEFAULT_BOLD; it.setPadding(0, dp(6), 0, 0) }
        val sub = label(if (on) "ON  •  $subtitle" else "OFF  •  $subtitle", 11f, MUTED).also { it.setPadding(0, dp(4), 0, 0) }
        box.addView(glyph); box.addView(name); box.addView(sub)
        box.setOnClickListener {
            on = !on
            glyph.setTextColor(if (on) RED else MUTED)
            sub.text = (if (on) "ON  •  " else "OFF  •  ") + subtitle
            Toast.makeText(this, if (on) "$title switched on (demo)" else "$title switched off (demo)", Toast.LENGTH_SHORT).show()
        }
        return box
    }

    private fun showCommands() {
        val items = arrayOf("JIVA, turn on living room light", "JIVA, turn off bedroom light", "JIVA, turn on fan", "JIVA, all lights off")
        android.app.AlertDialog.Builder(this).setTitle("JIVA • Voice commands")
            .setItems(items) { _, which -> Toast.makeText(this, "Sample command: ${items[which]}", Toast.LENGTH_SHORT).show() }
            .setNegativeButton("Close", null).show()
    }

    private fun showConnectionDialog() {
        val input = EditText(this).apply { hint = "http://192.168.1.50"; setTextColor(Color.WHITE); setHintTextColor(MUTED); setSingleLine(true) }
        val holder = LinearLayout(this).apply { setPadding(dp(22), dp(8), dp(22), 0); addView(input) }
        android.app.AlertDialog.Builder(this).setTitle("ESP32 connection")
            .setMessage("Enter the local IP address shown by your ESP32 firmware. This UI template does not send relay commands until the matching API is implemented.")
            .setView(holder).setPositiveButton("Save for setup") { _, _ ->
                val address = input.text.toString().trim()
                Toast.makeText(this, if (address.isBlank()) "No address entered" else "Address entered: $address", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun label(text: String, size: Float, color: Int) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color) }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun lp(w: Int, h: Int, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val match get() = LinearLayout.LayoutParams.MATCH_PARENT
    private val wrap get() = LinearLayout.LayoutParams.WRAP_CONTENT

    private class CinematicSplash(activity: MainActivity, val done: () -> Unit) : View(activity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var progress = 0f
        private val red = Color.rgb(235, 35, 48)
        private val white = Color.rgb(244, 240, 232)
        private val emberX = FloatArray(72) { ((it * 73 + 19) % 997) / 997f }
        private val emberY = FloatArray(72) { ((it * 137 + 41) % 991) / 991f }
        private val emberSize = FloatArray(72) { 1.0f + ((it * 7) % 5) }
        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 4800L
            interpolator = android.view.animation.LinearInterpolator()
            repeatCount = 0
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { done() }
            })
        }
        init {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
            post { animator.start() }
            setOnClickListener { if (animator.isRunning) { animator.cancel(); done() } }
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2f; val cy = h * .43f
            canvas.drawColor(Color.rgb(3, 3, 5))
            // Deep red atmospheric glow, like a dramatic action-film title card.
            p.shader = RadialGradient(cx, cy, w * .92f,
                intArrayOf(0x553D090D, 0x2217080A, 0xFF030305.toInt()),
                floatArrayOf(0f, .52f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            // Moving haze bands.
            for (i in 0..3) {
                val y = h * (.22f + i * .16f) + kotlin.math.sin(progress * 6.28f + i) * h * .025f
                p.shader = LinearGradient(0f, y - h*.035f, w, y + h*.035f,
                    intArrayOf(0x00A31B24, 0x229C1822, 0x00A31B24), null, Shader.TileMode.CLAMP)
                canvas.drawRect(0f, y - h*.05f, w, y + h*.05f, p); p.shader = null
            }
            // Ember particles drift upward throughout the reveal.
            for (i in emberX.indices) {
                val x = emberX[i] * w + kotlin.math.sin(progress * 9f + i) * w * .012f
                val travel = (emberY[i] + progress * (.28f + (i % 5) * .035f)) % 1f
                val y = h * (1f - travel)
                val flicker = (.35f + .65f * kotlin.math.abs(kotlin.math.sin(progress * 22f + i))).toFloat()
                p.color = if (i % 4 == 0) 0xFFFFC078.toInt() else red
                p.alpha = (180 * flicker).toInt()
                p.style = Paint.Style.FILL
                canvas.drawCircle(x, y, dp(emberSize[i].toInt().coerceAtLeast(1)).toFloat() * flicker, p)
            }
            p.alpha = 255
            // A quick cinematic flash and subtle camera impact.
            val flash = if (progress in .40f.. .49f) (1f - kotlin.math.abs(progress - .445f) / .045f) else 0f
            if (flash > 0f) {
                p.color = Color.WHITE; p.alpha = (flash * 65).toInt()
                canvas.drawRect(0f, 0f, w, h, p); p.alpha = 255
            }
            // Cinematic title-card accents: a low red horizon, anamorphic light streak,
            // and subtle dark vignette. These are rendered live at the device resolution.
            val atmosphere = ((progress - .08f) / .35f).coerceIn(0f, 1f)
            p.shader = LinearGradient(0f, cy + h*.10f, 0f, cy + h*.36f,
                intArrayOf(0x00F21E32, 0x334E0710, 0x00000000), null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, cy + h*.08f, w, cy + h*.38f, p)
            p.shader = null
            val streak = ((progress - .32f) / .20f).coerceIn(0f, 1f)
            if (streak > 0f) {
                val sx = w * (1.12f - streak * 1.45f)
                p.shader = LinearGradient(sx-w*.22f, cy, sx+w*.22f, cy,
                    intArrayOf(0x00FFFFFF, 0x66FFB7A0, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
                p.alpha = (220 * (1f - streak*.35f)).toInt()
                canvas.drawRect(0f, cy-dp(2).toFloat(), w, cy+dp(2).toFloat(), p)
                p.shader = null; p.alpha = 255
            }
            // A soft edge vignette keeps the title card dramatic on bright displays.
            p.shader = RadialGradient(cx, cy, w*.76f,
                intArrayOf(0x00000000, 0x55000000, 0xCC000000.toInt()),
                floatArrayOf(.42f, .78f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            val reveal = ((progress - .12f) / .42f).coerceIn(0f, 1f)
            val ringScale = .70f + .30f * reveal
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat()
            p.color = red; p.alpha = (230 * reveal).toInt()
            p.setShadowLayer(dp(20).toFloat(), 0f, 0f, red)
            canvas.drawArc(cx-w*.30f*ringScale, cy-w*.30f*ringScale,
                cx+w*.30f*ringScale, cy+w*.30f*ringScale, -105f, 300f*reveal, false, p)
            p.clearShadowLayer(); p.style = Paint.Style.FILL; p.alpha = 255
            // Metallic title reveal with red underglow.
            val titleAlpha = ((progress - .23f) / .30f).coerceIn(0f, 1f)
            val impact = if (progress in .38f.. .52f) 1f + .025f * (1f - kotlin.math.abs(progress - .45f) / .07f) else 1f
            canvas.save(); canvas.scale((.78f + .22f * titleAlpha) * impact, (.78f + .22f * titleAlpha) * impact, cx, cy)
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            p.textSize = w * .112f; p.color = red; p.alpha = (230 * titleAlpha).toInt()
            p.setShadowLayer(dp(22).toFloat(), 0f, 0f, red)
            canvas.drawText("PJ", cx - w*.075f, cy + dp(10), p)
            p.clearShadowLayer()
            p.shader = LinearGradient(cx, cy-w*.075f, cx, cy+w*.055f,
                intArrayOf(0xFFFFFFFF.toInt(), 0xFFE8D9C2.toInt(), 0xFF8B8177.toInt(), 0xFFF4EEE6.toInt(), 0xFF55515A.toInt()),
                floatArrayOf(0f, .24f, .55f, .76f, 1f), Shader.TileMode.CLAMP)
            p.alpha = (255 * titleAlpha).toInt()
            canvas.drawText("TECHS", cx + w*.105f, cy + dp(10), p)
            p.shader = null; canvas.restore()
            p.alpha = 255
            // Fine red separator and tagline.
            val lineReveal = ((progress - .50f) / .18f).coerceIn(0f, 1f)
            p.color = red; p.alpha = (220 * lineReveal).toInt()
            canvas.drawRect(cx-w*.25f, cy+w*.115f, cx-w*.25f + w*.50f*lineReveal, cy+w*.118f, p)
            p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            p.textSize = w * .026f; p.color = white
            p.alpha = (225 * ((progress - .54f)/.20f).coerceIn(0f,1f)).toInt()
            canvas.drawText("SMARTER HOME  •  BRIGHTER LIFE", cx, cy + w*.18f, p)
            p.color = red; p.textSize = w * .030f
            p.alpha = (220 * ((progress - .70f)/.18f).coerceIn(0f,1f)).toInt()
            canvas.drawText("POWERED BY JIVA", cx, h * .82f, p)
            p.color = 0xFFB5A5A5.toInt(); p.textSize = w * .024f
            p.alpha = (150 * (1f-progress)).toInt()
            canvas.drawText("TAP TO CONTINUE", cx, h * .92f, p)
            p.alpha = 255
        }
        private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    }
}
