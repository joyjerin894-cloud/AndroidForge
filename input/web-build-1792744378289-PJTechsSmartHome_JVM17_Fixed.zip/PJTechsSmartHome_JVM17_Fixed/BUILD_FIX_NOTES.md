PJ Techs Android project — JVM target fix

Fixed the reported Gradle error: Java compile target 1.8 vs Kotlin target 17.

The app module now sets Java sourceCompatibility and targetCompatibility to Java 17, and Kotlin jvmTarget to 17. This addresses the specific mismatch in the supplied GitHub Actions log.

To use: replace the PJTechsSmartHome project folder in your repository with this folder's contents, commit and push, then rerun the Build Android APK workflow. The new CI run is needed to confirm the full build succeeds.
