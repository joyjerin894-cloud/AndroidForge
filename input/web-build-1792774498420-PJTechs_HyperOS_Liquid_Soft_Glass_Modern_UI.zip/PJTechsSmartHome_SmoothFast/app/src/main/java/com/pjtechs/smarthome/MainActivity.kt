package com.pjtechs.smarthome

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.*
import android.animation.ValueAnimator
import android.view.View
import android.view.Gravity
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.content.Intent
import android.net.Uri
import android.media.MediaPlayer
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import org.json.JSONArray
import kotlin.math.abs
import kotlin.math.sin

private const val BG = 0xFF050607.toInt()
private const val PANEL = 0x66303036.toInt()
private const val GLASS_EDGE = 0x889DAAB8.toInt()
private const val GLASS_FILL = 0x332C333D.toInt()
private const val WHITE = 0xFFF5F6F8.toInt()
private const val MUTED = 0xFF9BA3AD.toInt()
private const val CYAN = 0xFF8DEBFF.toInt()
private const val VIOLET = 0xFFB4A5FF.toInt()
private const val PINK = 0xFFB8C4D1.toInt()
private const val AMBER = 0xFFD5DCE5.toInt()

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("shape_settings", MODE_PRIVATE) }
    private var accent = 0xFFFFC56A.toInt()
    private var uiBackground = 0xFF050505.toInt()
    private var animationStyle = 0
    private var openingLogo = "PJ TECHS"
    private var musicPlayer: MediaPlayer? = null
    private var musicUri: Uri? = null
    private var bootAudioPlayer: MediaPlayer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var stopBootAudioTask: Runnable? = null
    private var tts: TextToSpeech? = null
    private var assistantName: String = "JIVA"
    private val equipmentDefaults = arrayOf("Living room", "Bedroom", "Ceiling fan", "Accent strip")
    private var assistantInput: EditText? = null
    @Volatile private var esp32Connected = false
    private var esp32DashboardButton: TextView? = null
    private val relaySwitchRefreshers = mutableMapOf<Int, (Boolean) -> Unit>()

    /** Apply an iOS-inspired liquid ripple and soft press/release motion to every clickable view. */
    override fun setContentView(view: View) {
        super.setContentView(view)
        applyLiquidEffects(view)
    }

    private fun applyLiquidEffects(view: View) {
        if (view.isClickable && view !is CinematicSplash) {
            val rippleColor = ColorStateList.valueOf((accent and 0x00FFFFFF) or 0x55000000)
            val mask = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(18).toFloat() }
            view.foreground = RippleDrawable(rippleColor, null, mask)
            view.setOnTouchListener { target, event ->
                when (event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> target.animate().scaleX(.975f).scaleY(.975f).alpha(.92f).setDuration(100).start()
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> target.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(220).setInterpolator(android.view.animation.OvershootInterpolator(1.15f)).start()
                }
                false
            }
        }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) applyLiquidEffects(view.getChildAt(i))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode == 7002) {
            val spoken = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            assistantInput?.setText(spoken)
            if (spoken.isNotBlank()) submitAssistantPrompt(spoken)
            return
        }
        val selectedUri = data.data ?: return
        if (requestCode == 7001) {
            musicUri = selectedUri
            prefs.edit().putString("music_uri", musicUri.toString()).apply()
            try {
                musicPlayer?.release()
                musicPlayer = MediaPlayer().apply {
                    setDataSource(this@MainActivity, musicUri!!)
                    isLooping = true
                    setOnPreparedListener { it.start(); Toast.makeText(this@MainActivity, "Background music playing", Toast.LENGTH_SHORT).show() }
                    setOnErrorListener { _, _, _ -> Toast.makeText(this@MainActivity, "Could not play this audio file", Toast.LENGTH_SHORT).show(); true }
                    prepareAsync()
                }
            } catch (_: Exception) { Toast.makeText(this, "Could not open this audio file", Toast.LENGTH_SHORT).show() }
        } else if (requestCode == 7003) {
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(selectedUri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            prefs.edit().putString("boot_audio_uri", selectedUri.toString()).apply()
            Toast.makeText(this, "Boot audio selected. Enable it and save settings.", Toast.LENGTH_LONG).show()
        } else if (requestCode == 7004) {
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(selectedUri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            prefs.edit().putString("custom_logo_uri", selectedUri.toString()).apply()
            Toast.makeText(this, "Custom logo selected. Preview it and save settings.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        musicPlayer?.release(); musicPlayer = null
        stopBootAudioTask?.let { mainHandler.removeCallbacks(it) }
        bootAudioPlayer?.release(); bootAudioPlayer = null
        tts?.shutdown(); tts = null
        super.onDestroy()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assistantName = prefs.getString("assistant_name", "JIVA") ?: "JIVA"
        accent = prefs.getInt("accent_color", 0xFFFFC56A.toInt())
        uiBackground = prefs.getInt("ui_background", 0xFF050505.toInt())
        animationStyle = prefs.getInt("opening_animation", 0)
        openingLogo = prefs.getString("opening_logo", "PJ TECHS") ?: "PJ TECHS"
        window.statusBarColor = uiBackground
        window.navigationBarColor = uiBackground
        window.decorView.systemUiVisibility = 0
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
        setContentView(CinematicSplash(this, animationStyle, openingLogo, accent, uiBackground, prefs.getInt("intro_duration_seconds", 5), prefs.getString("custom_logo_uri", null), prefs.getInt("logo_scale_percent", 100) / 100f, prefs.getInt("opening_theme", 0)) { showDashboard() })
        playBootAudioIfEnabled()
    }

    private fun playBootAudioIfEnabled() {
        if (!prefs.getBoolean("boot_audio_enabled", false)) return
        val uriText = prefs.getString("boot_audio_uri", null) ?: return
        val seconds = prefs.getInt("boot_audio_seconds", 8).coerceIn(1, 180)
        try {
            stopBootAudioTask?.let { mainHandler.removeCallbacks(it) }
            bootAudioPlayer?.release()
            bootAudioPlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, Uri.parse(uriText))
                isLooping = true
                setOnPreparedListener { player ->
                    player.start()
                    stopBootAudioTask = Runnable { try { if (player.isPlaying) player.pause(); player.seekTo(0) } catch (_: Exception) {} }
                    mainHandler.postDelayed(stopBootAudioTask!!, seconds * 1000L)
                }
                setOnErrorListener { _, _, _ -> Toast.makeText(this@MainActivity, "Unable to play boot audio. Select the file again in Settings.", Toast.LENGTH_LONG).show(); true }
                prepareAsync()
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Boot audio unavailable. Select the audio file again in Settings.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showDashboard() {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(uiBackground) }
        val pager = ViewFlipper(this).apply {
            setInAnimation(this@MainActivity, android.R.anim.slide_in_left)
            setOutAnimation(this@MainActivity, android.R.anim.slide_out_right)
            layoutParams = LinearLayout.LayoutParams(match, 0, 1f)
        }
        fun makePageRoot(): Pair<ScrollView, LinearLayout> {
            val sc = ScrollView(this).apply { clipToPadding = false; isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
            val content = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(20), dp(18), dp(20), dp(30))
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF10151D.toInt(), 0xFF0C0F14.toInt(), 0xFF070809.toInt()))
            }
            sc.addView(content)
            pager.addView(sc, LinearLayout.LayoutParams(match, match))
            return sc to content
        }
        val homePair = makePageRoot(); val homeRoot = homePair.second
        val devicesRoot = makePageRoot().second
        val scenesRoot = makePageRoot().second
        val voiceRoot = makePageRoot().second
        val settingsRoot = makePageRoot().second
        var root = homeRoot
        page.addView(pager)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = TextView(this).apply {
            text = openingLogo.take(2); textSize = 16f; gravity = Gravity.CENTER; setTextColor(BG)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFFE2A0.toInt(), 0xFF9A671F.toInt())).apply { cornerRadius = dp(15).toFloat() }
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val brandCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(11), 0, 0, 0) }
        brandCol.addView(label(openingLogo.lowercase(Locale.ROOT), 20f, WHITE, true))
        brandCol.addView(label("BLACK & GOLD SMART LIVING", 9f, accent, true).apply { letterSpacing = .14f; setPadding(0, dp(2), 0, 0) })
        top.addView(brandCol, LinearLayout.LayoutParams(0, wrap, 1f))
        val profile = TextView(this).apply { text = "✦"; textSize = 22f; gravity = Gravity.CENTER; setTextColor(AMBER); background = glass(0x44373B42, 16, 0x66D9E3EF) }
        top.addView(profile, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(top)

        root.addView(label("YOUR SPACE. YOUR RULES.", 11f, MUTED, true).apply { letterSpacing = .18f; setPadding(0, dp(25), 0, dp(7)) })
        root.addView(label("Welcome back 👋", 28f, WHITE, true))
        root.addView(label("Make every moment feel just right.", 13f, MUTED).apply { setPadding(0, dp(5), 0, dp(14)) })

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(19), dp(18), dp(18), dp(17))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x664B5665.toInt(), 0x44343D49.toInt(), 0x33202731.toInt())).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), 0x99DDE7F3.toInt()) }
        }
        val heroTop = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val live = TextView(this).apply { text = "● SYSTEM ONLINE"; textSize = 10f; letterSpacing = .08f; setTextColor(accent); background = rounded(0x334C3A1B, 20); setPadding(dp(10), dp(7), dp(10), dp(7)) }
        heroTop.addView(live)
        val spacer = Space(this); heroTop.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        heroTop.addView(label("⌁", 26f, accent, true))
        hero.addView(heroTop)
        hero.addView(label("A smarter home\nstarts here.", 26f, WHITE, true).apply { setPadding(0, dp(15), 0, dp(7)) })
        hero.addView(label("Control your lights and connected devices from one beautiful dashboard.", 12f, 0xFFC3CAD2.toInt()))
        val heroButton = TextView(this).apply {
            text = "  EXPLORE CONTROLS     ↗"; textSize = 11f; letterSpacing = .05f; typeface = Typeface.DEFAULT_BOLD; setTextColor(BG); gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFFFE5A3.toInt(), 0xFFC18A36.toInt())).apply { cornerRadius = dp(13).toFloat() }
            setPadding(dp(13), 0, dp(13), 0); setOnClickListener { Toast.makeText(this@MainActivity, "Choose a device below", Toast.LENGTH_SHORT).show() }
        }
        hero.addView(heroButton, LinearLayout.LayoutParams(wrap, dp(42)).apply { topMargin = dp(17) })
        root.addView(hero, lp(match, wrap, 0, 0, 0, 18))

        // Master power remains visible and interactive even before ESP32 connects.
        val allRelaysOn = (1..4).all { prefs.getBoolean("relay_$it", false) }
        val masterCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(17), dp(14), dp(16), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0x554B5360, 0x44303640)).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), 0x88DDE7F3.toInt())
            }
        }
        val masterGlyph = TextView(this).apply {
            text = "⏻"; textSize = 27f; gravity = Gravity.CENTER; setTextColor(accent)
            background = rounded(0x334C3A1B, 14)
        }
        masterCard.addView(masterGlyph, LinearLayout.LayoutParams(dp(48), dp(48)))
        val masterText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        masterText.addView(label("MASTER POWER", 14f, WHITE, true))
        val masterSubtitle = label(if (allRelaysOn) "ALL DEVICES ON" else "CONTROL ALL 4 DEVICES", 10f, if (allRelaysOn) accent else MUTED, true)
        masterSubtitle.setPadding(0, dp(4), 0, 0)
        masterText.addView(masterSubtitle)
        masterCard.addView(masterText, LinearLayout.LayoutParams(0, wrap, 1f))
        val masterToggle = PremiumPowerSwitch(this, accent).apply { isOn = allRelaysOn; contentDescription = "Master power for all four relays" }
        masterCard.addView(masterToggle, LinearLayout.LayoutParams(dp(72), dp(36)))
        masterCard.setOnClickListener {
            val target = !((1..4).all { prefs.getBoolean("relay_$it", false) })
            val address = prefs.getString("esp32_address", "").orEmpty()
            if (address.isBlank()) {
                Toast.makeText(this, "Connect your ESP32 to control all devices", Toast.LENGTH_SHORT).show()
                showConnectionDialog()
                return@setOnClickListener
            }
            masterToggle.isEnabled = false
            masterSubtitle.text = if (target) "TURNING ALL ON…" else "TURNING ALL OFF…"
            setAllRelaysOnEsp32(address, target) { success, message ->
                masterToggle.isEnabled = true
                val nowAllOn = (1..4).all { prefs.getBoolean("relay_$it", false) }
                masterToggle.isOn = nowAllOn
                masterSubtitle.text = if (nowAllOn) "ALL DEVICES ON" else "CONTROL ALL 4 DEVICES"
                masterSubtitle.setTextColor(if (nowAllOn) accent else MUTED)
                if (!success) Toast.makeText(this, "Master command incomplete: $message", Toast.LENGTH_LONG).show()
            }
        }
        root.addView(masterCard, lp(match, wrap, 0, 0, 0, 22))

        root = devicesRoot
        val section = sectionHeader("DEVICES", "QUICK CONTROL  •  4 DEVICES")
        root.addView(section, lp(match, wrap, 0, 0, 0, 12))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(deviceCard(1, "☼", equipmentName(0), "MAIN LIGHT", accent), LinearLayout.LayoutParams(0, dp(160), 1f).apply { marginEnd = dp(7) })
        row1.addView(deviceCard(2, "◒", equipmentName(1), "AMBIENT", accent), LinearLayout.LayoutParams(0, dp(160), 1f).apply { marginStart = dp(7) })
        row2.addView(deviceCard(3, "✣", equipmentName(2), "RELAY 02", accent), LinearLayout.LayoutParams(0, dp(160), 1f).apply { marginEnd = dp(7) })
        row2.addView(deviceCard(4, "▣", equipmentName(3), "RGB PIXELS", accent), LinearLayout.LayoutParams(0, dp(160), 1f).apply { marginStart = dp(7) })
        root.addView(row1); root.addView(row2, lp(match, wrap, 0, 13, 0, 22))

        root = scenesRoot
        val scenesHeader = sectionHeader("SCENES", "SMART SCENES  •  ONE-TAP ROUTINES")
        root.addView(scenesHeader, lp(match, wrap, 0, 0, 0, 10))
        val scenesGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sceneRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val sceneRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        sceneRow1.addView(sceneButton("☾", "NIGHT", "Soft, low-light setup") { applyScene("NIGHT", booleanArrayOf(false, false, false, false)) }, LinearLayout.LayoutParams(0, dp(88), 1f).apply { marginEnd = dp(6) })
        sceneRow1.addView(sceneButton("☀", "EVENING", "Main + ambient") { applyScene("EVENING", booleanArrayOf(true, true, false, true)) }, LinearLayout.LayoutParams(0, dp(88), 1f).apply { marginStart = dp(6) })
        sceneRow2.addView(sceneButton("◎", "FOCUS", "Main light only") { applyScene("FOCUS", booleanArrayOf(true, false, false, false)) }, LinearLayout.LayoutParams(0, dp(88), 1f).apply { marginEnd = dp(6) })
        sceneRow2.addView(sceneButton("⏻", "AWAY", "Switch everything off") { applyScene("AWAY", booleanArrayOf(false, false, false, false)) }, LinearLayout.LayoutParams(0, dp(88), 1f).apply { marginStart = dp(6) })
        scenesGrid.addView(sceneRow1); scenesGrid.addView(sceneRow2, lp(match, wrap, 0, 10, 0, 20))
        root.addView(scenesGrid)

        root = homeRoot
        val insightHeader = sectionHeader("INSIGHTS", "SMART INSIGHTS  •  ESTIMATED ACTIVE LOAD")
        root.addView(insightHeader, lp(match, wrap, 0, 0, 0, 10))
        val activeWatts = (1..4).sumOf { i -> if (prefs.getBoolean("relay_$i", false)) intArrayOf(12, 8, 45, 18)[i - 1] else 0 }
        val insightCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = glass(0x332A3038, 18, 0x668A96A5.toInt())
        }
        insightCard.addView(label("◉", 26f, accent, true), LinearLayout.LayoutParams(dp(42), dp(42)))
        val insightText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        insightText.addView(label("ESTIMATED LOAD", 10f, MUTED, true))
        insightText.addView(label("$activeWatts W active", 18f, WHITE, true).apply { setPadding(0, dp(4), 0, 0) })
        insightText.addView(label("Illustrative estimate; customise device wattage for accuracy.", 9f, MUTED).apply { setPadding(0, dp(3), 0, 0) })
        insightCard.addView(insightText, LinearLayout.LayoutParams(0, wrap, 1f))
        val energySettings = TextView(this).apply { text = "EDIT"; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(BG); background = goldButton(); setPadding(dp(12), dp(9), dp(12), dp(9)); setOnClickListener { showSettingsDialog() } }
        insightCard.addView(energySettings)
        root.addView(insightCard, lp(match, wrap, 0, 0, 0, 20))

        root = voiceRoot
        val voiceHeader = sectionHeader("VOICE", "VOICE ASSISTANT  •  HANDS-FREE CONTROL")
        root.addView(voiceHeader, lp(match, wrap, 0, 0, 0, 10))
        val voice = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(15), dp(14), dp(15), dp(14))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0x55404750.toInt(), 0x4430353D.toInt())).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), 0x8899D9FF.toInt()) }
            setOnClickListener { showCommands() }
        }
        val mic = TextView(this).apply { text = "◉"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(accent); background = rounded(0x334C3A1B, 15) }
        voice.addView(mic, LinearLayout.LayoutParams(dp(50), dp(50)))
        val voiceCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        voiceCol.addView(label("Talk to $assistantName", 16f, WHITE, true))
        voiceCol.addView(label("Tap to view voice commands", 11f, MUTED).apply { setPadding(0, dp(3), 0, 0) })
        voice.addView(voiceCol, LinearLayout.LayoutParams(0, wrap, 1f))
        voice.addView(label("↗", 20f, accent, true))
        root.addView(voice, lp(match, wrap, 0, 0, 0, 15))

        root = settingsRoot
        val connectionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val connectEsp = TextView(this).apply {
            text = if (esp32Connected) "●  ESP32 CONNECTED  •  MANAGE" else "⌁  CONNECT ESP32"
            textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (esp32Connected) 0xFF9FFFC4.toInt() else BG)
            background = if (esp32Connected) glass(0x3335A76B, 15, 0x889FFFC4.toInt()) else goldButton()
            setOnClickListener { showConnectionDialog() }
        }
        esp32DashboardButton = connectEsp
        connectionRow.addView(connectEsp, LinearLayout.LayoutParams(match, dp(50)))
        root.addView(connectionRow, lp(match, wrap, 0, 0, 0, 9))
        val networkHeader = sectionHeader("NETWORK", "DEVICE CONNECTION  •  LOCAL WI-FI")
        root.addView(networkHeader, lp(match, wrap, 0, 8, 0, 10))

        val settingsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val settings = TextView(this).apply {
            text = "⚙  CUSTOMIZE PJ TECHS"; textSize = 12f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; setTextColor(WHITE)
            background = glass(0x332D3036, 15, 0x887D8794.toInt()); setOnClickListener { showSettingsDialog() }
        }
        settingsRow.addView(settings, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(8) })
        root.addView(settingsRow)
        val settingsHeader = sectionHeader("SETTINGS", "PERSONALISE YOUR EXPERIENCE")
        root.addView(settingsHeader, lp(match, wrap, 0, 18, 0, 8))
        root.addView(label("shape  •  BLACK GLASS / GOLD EDITION", 9f, 0xFF9299A3.toInt(), true).apply { gravity = Gravity.CENTER; letterSpacing = .12f; setPadding(0, dp(18), 0, 0) })
        // HyperOS-inspired floating liquid-glass navigation dock with a springy moving capsule.
        val nav = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xE82D333C.toInt(), 0xE8161A20.toInt(), 0xF20B0D11.toInt())).apply {
                cornerRadius = dp(27).toFloat()
                setStroke(dp(1), 0x66FFFFFF)
            }
            elevation = dp(18).toFloat()
            setPadding(dp(7), dp(7), dp(7), dp(8))
        }
        nav.clipChildren = false
        nav.clipToPadding = false
        val navItems = listOf("⌂" to "Home", "▦" to "Devices", "✦" to "Scenes", "◉" to "Voice", "⚙" to "Settings")
        val navButtons = mutableListOf<TextView>()
        val slidingIndicator = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0x55FFFFFF, 0x334E5968, 0x443D321B)).apply {
                cornerRadius = dp(21).toFloat()
                setStroke(dp(1), 0x88FFFFFF.toInt())
            }
            elevation = dp(1).toFloat()
        }
        // A subtle specular line makes the capsule read as soft glass rather than a flat tab.
        val specular = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF)).apply { cornerRadius = dp(2).toFloat() }
            alpha = .72f
        }
        val navRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        nav.addView(slidingIndicator, FrameLayout.LayoutParams(0, dp(58), Gravity.TOP or Gravity.START))
        nav.addView(navRow, FrameLayout.LayoutParams(match, dp(58), Gravity.TOP or Gravity.START))
        nav.addView(specular, FrameLayout.LayoutParams(dp(58), dp(2), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(1) })

        fun selectPage(index: Int) {
            val target = index.coerceIn(0, pager.childCount - 1)
            val previous = pager.displayedChild
            if (target != previous) {
                if (target > previous) {
                    pager.inAnimation = android.view.animation.AnimationUtils.loadAnimation(this, android.R.anim.slide_in_right)
                    pager.outAnimation = android.view.animation.AnimationUtils.loadAnimation(this, android.R.anim.slide_out_left)
                } else {
                    pager.inAnimation = android.view.animation.AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left)
                    pager.outAnimation = android.view.animation.AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right)
                }
                pager.setDisplayedChild(target)
            }
            navButtons.forEachIndexed { i, button ->
                val selected = i == target
                button.setTextColor(if (selected) 0xFFFFD98A.toInt() else 0xFFB4BCC7.toInt())
                button.alpha = if (selected) 1f else .76f
                button.scaleX = if (selected) 1f else .94f
                button.scaleY = if (selected) 1f else .94f
                button.typeface = Typeface.create("sans-serif", if (selected) Typeface.BOLD else Typeface.NORMAL)
            }
            val moveIndicator = {
                if (navButtons.size == navItems.size && nav.width > 0) {
                    val selectedButton = navButtons[target]
                    val targetWidth = selectedButton.width
                    val params = slidingIndicator.layoutParams as FrameLayout.LayoutParams
                    if (params.width != targetWidth) {
                        params.width = targetWidth
                        slidingIndicator.layoutParams = params
                    }
                    slidingIndicator.animate().cancel()
                    slidingIndicator.animate()
                        .translationX(selectedButton.x)
                        .setDuration(360)
                        .setInterpolator(android.view.animation.OvershootInterpolator(0.82f))
                        .start()
                }
            }
            if (nav.isLaidOut) moveIndicator() else nav.post { moveIndicator() }
        }
        navItems.forEachIndexed { index, item ->
            val button = TextView(this).apply {
                text = "${item.first}\n${item.second}"
                textSize = 10f
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                setTextColor(0xFFB4BCC7.toInt())
                setLineSpacing(dp(1).toFloat(), 1f)
                setPadding(dp(2), dp(5), dp(2), dp(5))
                isAllCaps = false
                background = null
                contentDescription = item.second
                setOnClickListener { selectPage(index) }
            }
            navButtons.add(button)
            navRow.addView(button, LinearLayout.LayoutParams(0, dp(58), 1f).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
            })
        }
        selectPage(0)
        // Horizontal swipes work on the page surfaces while vertical scrolling stays native.
        for (i in 0 until pager.childCount) {
            var pageDownX = 0f
            pager.getChildAt(i).setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> { pageDownX = event.x; false }
                    android.view.MotionEvent.ACTION_UP -> {
                        val delta = event.x - pageDownX
                        if (kotlin.math.abs(delta) > dp(70)) {
                            selectPage((pager.displayedChild + if (delta < 0) 1 else -1).coerceIn(0, pager.childCount - 1))
                            true
                        } else false
                    }
                    else -> false
                }
            }
        }
        var downX = 0f
        pager.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> { downX = event.x; true }
                android.view.MotionEvent.ACTION_UP -> {
                    val delta = event.x - downX
                    if (kotlin.math.abs(delta) > dp(55)) {
                        selectPage((pager.displayedChild + if (delta < 0) 1 else -1).coerceIn(0, pager.childCount - 1))
                    }
                    true
                }
                else -> true
            }
        }
        page.addView(nav, LinearLayout.LayoutParams(match, wrap))
        setContentView(page)
    }

    private fun sectionHeader(title: String, detail: String): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0x55463822, 0x33252A32, 0x2221262D)).apply {
                cornerRadius = dp(12).toFloat(); setStroke(dp(1), 0x66D9AA4D.toInt())
            }
        }
        bar.addView(label("▎", 17f, accent, true), LinearLayout.LayoutParams(dp(18), wrap))
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(5), 0, 0, 0) }
        text.addView(label(title, 11f, WHITE, true).apply { letterSpacing = .08f })
        text.addView(label(detail, 9f, MUTED, true).apply { setPadding(0, dp(3), 0, 0) })
        bar.addView(text)
        return bar
    }

    private fun sceneButton(icon: String, title: String, subtitle: String, action: () -> Unit): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13), dp(10), dp(10), dp(9))
            background = glass(0x44303843, 16, 0x77D9AA4D.toInt())
            addView(label(icon, 20f, accent, true))
            addView(label(title, 11f, WHITE, true).apply { setPadding(0, dp(4), 0, dp(2)) })
            addView(label(subtitle, 9f, MUTED))
            isClickable = true
            setOnClickListener { action() }
        }
    }

    private fun applyScene(sceneName: String, states: BooleanArray) {
        val address = prefs.getString("esp32_address", "").orEmpty()
        if (address.isBlank()) {
            Toast.makeText(this, "Connect ESP32 before running a scene", Toast.LENGTH_SHORT).show()
            showConnectionDialog()
            return
        }
        Toast.makeText(this, "Applying $sceneName scene…", Toast.LENGTH_SHORT).show()
        fun next(index: Int) {
            if (index >= states.size) {
                prefs.edit().putString("last_scene", sceneName).apply()
                Toast.makeText(this, "$sceneName scene applied", Toast.LENGTH_SHORT).show()
                return
            }
            setRelayOnEsp32(address, index + 1, states[index]) { success, message ->
                if (!success) {
                    Toast.makeText(this, "$sceneName stopped at relay ${index + 1}: $message", Toast.LENGTH_LONG).show()
                } else {
                    relaySwitchRefreshers[index + 1]?.invoke(states[index])
                    next(index + 1)
                }
            }
        }
        next(0)
    }

    private fun deviceCard(relayIndex: Int, icon: String, title: String, subtitle: String, accent: Int): View {
        var on = prefs.getBoolean("relay_$relayIndex", false)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(13), dp(12), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (on) (accent and 0x00FFFFFF) or 0x44303A50 else 0x4432363D, 0x2221262D)).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), if (on) (accent and 0x00FFFFFF) or 0x99000000.toInt() else 0x669DAAB8.toInt()) }
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val glyph = TextView(this).apply { text = icon; textSize = 28f; gravity = Gravity.CENTER; setTextColor(accent); background = rounded(0x33424852, 14) }
        top.addView(glyph, LinearLayout.LayoutParams(dp(49), dp(49)))
        top.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        val dot = TextView(this).apply { text = if (on) "●" else "○"; textSize = 13f; setTextColor(if (on) accent else MUTED) }
        top.addView(dot)
        box.addView(top)
        box.addView(label(title, 14f, WHITE, true).apply { setPadding(0, dp(12), 0, dp(3)) })
        val sub = label((if (on) "ON  •  " else "OFF  •  ") + subtitle, 9f, if (on) accent else MUTED, true).apply { letterSpacing = .03f }
        box.addView(sub)
        val toggle = PremiumPowerSwitch(this, accent).apply {
            isOn = on
            contentDescription = "Toggle $title"
            setOnClickListener { box.performClick() }
        }
        box.addView(toggle, LinearLayout.LayoutParams(dp(62), dp(31)).apply { topMargin = dp(10) })
        relaySwitchRefreshers[relayIndex] = { state ->
            on = state
            toggle.isOn = state
            prefs.edit().putBoolean("relay_$relayIndex", state).apply()
            dot.text = if (state) "●" else "○"
            dot.setTextColor(if (state) accent else MUTED)
            sub.text = (if (state) "ON  •  " else "OFF  •  ") + subtitle
            sub.setTextColor(if (state) accent else MUTED)
            box.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if (state) (accent and 0x00FFFFFF) or 0x44303A50 else 0x4432363D, 0x2221262D)).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), if (state) (accent and 0x00FFFFFF) or 0x99000000.toInt() else 0x669DAAB8.toInt()) }
        }
        box.setOnClickListener {
            val targetState = !on
            val address = prefs.getString("esp32_address", "").orEmpty()
            if (address.isBlank()) {
                Toast.makeText(this, "Connect your ESP32 first", Toast.LENGTH_SHORT).show()
                showConnectionDialog()
                return@setOnClickListener
            }
            setRelayOnEsp32(address, relayIndex, targetState) { success, message ->
                if (success) {
                    relaySwitchRefreshers[relayIndex]?.invoke(targetState)
                    Toast.makeText(this, "$title ${if (targetState) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
                } else {
                    esp32Connected = false
                    Toast.makeText(this, "ESP32 command failed: $message", Toast.LENGTH_LONG).show()
                }
            }
        }
        return box
    }

    private fun normalizeEsp32Address(raw: String): String {
        var address = raw.trim().trimEnd('/')
        if (address.isNotBlank() && !address.startsWith("http://", true) && !address.startsWith("https://", true)) {
            address = "http://$address"
        }
        return address
    }

    private fun esp32Request(rawAddress: String, path: String, callback: (Boolean, String) -> Unit) {
        val base = normalizeEsp32Address(rawAddress)
        if (base.isBlank() || !(base.startsWith("http://", true) || base.startsWith("https://", true))) {
            callback(false, "Enter a valid ESP32 address")
            return
        }
        Thread {
            var connection: HttpURLConnection? = null
            var ok = false
            var body = ""
            try {
                connection = URL(base + path).openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 3500
                connection.readTimeout = 3500
                connection.setRequestProperty("Accept", "application/json")
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                ok = code in 200..299
                if (!ok) body = "HTTP $code ${body.take(120)}".trim()
            } catch (e: Exception) {
                body = e.message ?: "Could not reach ESP32"
            } finally { connection?.disconnect() }
            val finalOk = ok
            val finalBody = body
            runOnUiThread { callback(finalOk, finalBody) }
        }.start()
    }

    private fun setAllRelaysOnEsp32(address: String, on: Boolean, callback: (Boolean, String) -> Unit) {
        fun sendNext(relay: Int) {
            if (relay > 4) {
                callback(true, "All four relays updated")
                return
            }
            setRelayOnEsp32(address, relay, on) { success, message ->
                if (!success) {
                    callback(false, "Relay $relay: $message")
                } else {
                    relaySwitchRefreshers[relay]?.invoke(on)
                    sendNext(relay + 1)
                }
            }
        }
        sendNext(1)
    }

    private fun setRelayOnEsp32(address: String, relayIndex: Int, on: Boolean, callback: (Boolean, String) -> Unit) {
        val state = if (on) "on" else "off"
        esp32Request(address, "/api/relay?id=$relayIndex&state=$state") { success, body ->
            if (success) {
                esp32Connected = true
                esp32DashboardButton?.let { button ->
                    button.text = "●  ESP32 CONNECTED  •  MANAGE"
                    button.setTextColor(0xFF9FFFC4.toInt())
                    button.background = glass(0x3335A76B, 15, 0x889FFFC4.toInt())
                }
            }
            callback(success, body)
        }
    }

    private fun showCommands() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val input = EditText(this).apply { hint = "Try: turn on living room light"; setTextColor(WHITE); setHintTextColor(MUTED); setSingleLine(false) }
        assistantInput = input
        panel.addView(input, lp(match, wrap, 0, 0, 0, 10))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val mic = TextView(this).apply { text = "🎙  SPEAK"; gravity = Gravity.CENTER; setTextColor(WHITE); background = glass(0x44282E38, 14, 0x887D8794.toInt()); setPadding(dp(12), dp(12), dp(12), dp(12)); setOnClickListener { startSpeechInput() } }
        val send = TextView(this).apply { text = "  ASK JIVA AI  ➜  "; gravity = Gravity.CENTER; setTextColor(0xFF08090B.toInt()); background = goldButton(); setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener { submitAssistantPrompt(input.text.toString()) } }
        actions.addView(mic, LinearLayout.LayoutParams(0, wrap, 1f).apply { marginEnd = dp(8) }); actions.addView(send, LinearLayout.LayoutParams(0, wrap, 1f))
        panel.addView(actions)
        AlertDialog.Builder(this).setTitle("$assistantName • Smart assistant")
            .setMessage(if (loadCloudApiKey().isNotBlank()) "Cloud AI is configured. Ask questions or get smart-home help. Connect your ESP32 in the dashboard to control real devices." else "Configure a cloud-compatible AI endpoint, model and API key in Customization Settings to enable AI chat. Without a key, local demo commands still work. Connect your ESP32 in the dashboard to control real devices.")
            .setView(panel)
            .setPositiveButton("Ask AI / run command") { _, _ -> submitAssistantPrompt(input.text.toString()) }
            .setNeutralButton("Speak") { _, _ -> startSpeechInput() }
            .setNegativeButton("Close", null).show()
    }

    private fun submitAssistantPrompt(raw: String) {
        val prompt = raw.trim()
        if (prompt.isBlank()) {
            Toast.makeText(this, "Enter a question or command", Toast.LENGTH_SHORT).show()
            return
        }
        if (loadCloudApiKey().isNotBlank()) askCloudAI(prompt) else handleAssistantCommand(prompt)
    }

    /** Calls an OpenAI-compatible chat-completions endpoint off the UI thread. */
    private fun askCloudAI(prompt: String) {
        val apiKey = loadCloudApiKey()
        if (apiKey.isBlank()) {
            handleAssistantCommand(prompt)
            return
        }
        val endpoint = prefs.getString("cloud_ai_endpoint", "https://api.openai.com/v1/chat/completions")
            ?: "https://api.openai.com/v1/chat/completions"
        val model = prefs.getString("cloud_ai_model", "gpt-4o-mini") ?: "gpt-4o-mini"
        if (!endpoint.startsWith("https://", ignoreCase = true)) {
            showAssistantReply("Cloud AI needs an HTTPS endpoint to protect your request and API key.")
            return
        }
        Toast.makeText(this, "Connecting to cloud AI…", Toast.LENGTH_SHORT).show()
        Thread {
            var connection: HttpURLConnection? = null
            val answer: String = try {
                val body = JSONObject().apply {
                    put("model", model)
                    put("messages", JSONArray().apply {
                        put(JSONObject().put("role", "system").put("content", "You are JIVA, a helpful smart-home assistant inside the PJ Techs app. Be concise. You may explain device commands, but do not claim hardware was changed; the app's ESP32 integration may not be configured."))
                        put(JSONObject().put("role", "user").put("content", prompt))
                    })
                    put("temperature", 0.7)
                }
                connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 25000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                }
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val detail = try { JSONObject(responseText).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                    "Cloud AI error ($code): ${detail?.takeIf { it.isNotBlank() } ?: responseText.take(220).ifBlank { "Request failed" }}"
                } else {
                    val json = JSONObject(responseText)
                    val content = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.opt("content")
                    val text = when (content) {
                        is String -> content
                        is JSONArray -> (0 until content.length()).mapNotNull { i -> content.optJSONObject(i)?.optString("text") }.joinToString("\n")
                        else -> ""
                    }
                    text.ifBlank { "The cloud model returned no text. Check the model name and endpoint." }
                }
            } catch (e: Exception) {
                "Unable to reach cloud AI: ${e.message ?: "network error"}. Check internet access, endpoint, model and API key."
            } finally {
                connection?.disconnect()
            }
            runOnUiThread { showAssistantReply(answer) }
        }.start()
    }

    private fun showAssistantReply(message: String) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this).setTitle("$assistantName • Cloud AI").setMessage(message)
            .setPositiveButton("OK", null).show()
        try { tts?.speak(message.take(1200), TextToSpeech.QUEUE_FLUSH, null, "jiva-cloud-response") } catch (_: Exception) {}
    }

    private fun saveCloudApiKey(secret: String) {
        try {
            val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val secretKey = if (keyStore.containsAlias("pjtechs_cloud_ai_key")) {
                keyStore.getKey("pjtechs_cloud_ai_key", null) as SecretKey
            } else {
                val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
                generator.init(KeyGenParameterSpec.Builder("pjtechs_cloud_ai_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build())
                generator.generateKey()
            }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val encrypted = cipher.doFinal(secret.toByteArray(Charsets.UTF_8))
            val packed = cipher.iv + encrypted
            prefs.edit().putString("cloud_ai_key_enc", Base64.encodeToString(packed, Base64.NO_WRAP)).apply()
        } catch (_: Exception) {
            Toast.makeText(this, "Could not securely save API key on this device", Toast.LENGTH_LONG).show()
        }
    }

    private fun loadCloudApiKey(): String {
        return try {
            val packed = Base64.decode(prefs.getString("cloud_ai_key_enc", null) ?: return "", Base64.NO_WRAP)
            if (packed.size <= 12) return ""
            val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val secretKey = keyStore.getKey("pjtechs_cloud_ai_key", null) as? SecretKey ?: return ""
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, packed.copyOfRange(0, 12)))
            String(cipher.doFinal(packed.copyOfRange(12, packed.size)), Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    private fun clearCloudApiKey() {
        prefs.edit().remove("cloud_ai_key_enc").apply()
        try {
            val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (keyStore.containsAlias("pjtechs_cloud_ai_key")) keyStore.deleteEntry("pjtechs_cloud_ai_key")
        } catch (_: Exception) { }
    }

    private fun handleAssistantCommand(raw: String) {
        val command = raw.trim().lowercase(Locale.ROOT)
        val response = when {
            command.isBlank() -> "Please enter a command."
            "connect" in command && "esp32" in command -> { showConnectionDialog(); "Opening ESP32 setup." }
            "setting" in command || "custom" in command -> { showSettingsDialog(); "Opening customization settings." }
            "music" in command -> { chooseMusic(); "Choose an audio file for background music." }
            "turn off all" in command || "all lights off" in command -> "All-off command recognized. Use the ESP32 connection button to connect hardware first."
            "turn on" in command || "switch on" in command -> "On command recognized: $raw. Connect ESP32 in the dashboard to send hardware commands."
            "turn off" in command || "switch off" in command -> "Off command recognized: $raw. Connect ESP32 in the dashboard to send hardware commands."
            "hello" in command || "hi" == command -> "Hello! I'm $assistantName. How can I help with your smart home?"
            else -> "I can help with lights, devices, music, settings and ESP32 setup. This is an offline demo assistant, not a cloud AI model."
        }
        AlertDialog.Builder(this).setTitle(assistantName).setMessage(response).setPositiveButton("OK", null).show()
        try { tts?.speak(response, TextToSpeech.QUEUE_FLUSH, null, "shape-response") } catch (_: Exception) {}
    }

    private fun startSpeechInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a smart-home command")
            }
            startActivityForResult(intent, 7002)
        } catch (_: Exception) { Toast.makeText(this, "Speech recognition is not available on this device", Toast.LENGTH_LONG).show() }
    }

    private fun equipmentName(index: Int) = prefs.getString("equipment_$index", equipmentDefaults[index]) ?: equipmentDefaults[index]

    private fun showSettingsDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(6), dp(20), 0) }
        fun edit(hintText: String, value: String): EditText = EditText(this).apply {
            hint = hintText; setText(value); setTextColor(WHITE); setHintTextColor(MUTED); setSingleLine(true)
        }
        val assistant = edit("Assistant name", assistantName)
        panel.addView(label("AI ASSISTANT NAME", 10f, accent, true)); panel.addView(assistant, lp(match, wrap, 0, 0, 0, 8))
        panel.addView(label("CLOUD AI MODEL", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(2)) })
        panel.addView(label("OpenAI-compatible chat endpoint • requires internet", 11f, MUTED).apply { setPadding(0, 0, 0, dp(4)) })
        val cloudEndpoint = edit("https://api.openai.com/v1/chat/completions", prefs.getString("cloud_ai_endpoint", "https://api.openai.com/v1/chat/completions") ?: "https://api.openai.com/v1/chat/completions")
        panel.addView(cloudEndpoint, lp(match, wrap, 0, 0, 0, 4))
        val cloudModel = edit("Model name, e.g. gpt-4o-mini", prefs.getString("cloud_ai_model", "gpt-4o-mini") ?: "gpt-4o-mini")
        panel.addView(cloudModel, lp(match, wrap, 0, 0, 0, 4))
        val cloudKey = edit("API key (leave blank to keep saved key)", "")
        cloudKey.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        panel.addView(cloudKey, lp(match, wrap, 0, 0, 0, 3))
        panel.addView(label(if (loadCloudApiKey().isBlank()) "API key not configured" else "API key saved securely on this device ✓", 11f, MUTED).apply { setPadding(0, 0, 0, dp(4)) })
        val clearCloudKey = TextView(this).apply {
            text = "Clear saved cloud AI key"; setTextColor(MUTED); gravity = Gravity.CENTER; setPadding(dp(8), dp(6), dp(8), dp(8))
            setOnClickListener { clearCloudApiKey(); Toast.makeText(this@MainActivity, "Saved cloud AI key cleared", Toast.LENGTH_SHORT).show() }
        }
        panel.addView(clearCloudKey)
        panel.addView(label("Use an HTTPS endpoint. API usage may cost money; the provider's terms and limits apply.", 10f, MUTED).apply { setPadding(0, 0, 0, dp(8)) })
        val names = Array(4) { edit("Equipment ${it + 1} name", equipmentName(it)) }
        panel.addView(label("EQUIPMENT NAMES", 10f, accent, true))
        names.forEachIndexed { i, field -> panel.addView(field, lp(match, wrap, 0, 0, 0, 3)) }
        panel.addView(label("ACCENT COLOUR", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(5)) })
        val colors = linkedMapOf("Gold" to 0xFFFFC56A.toInt(), "Ice cyan" to CYAN, "Violet" to VIOLET, "Emerald" to 0xFF65E6B3.toInt(), "Rose" to 0xFFFF86AD.toInt(), "White" to 0xFFF5F6F8.toInt())
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        colors.forEach { (name, color) ->
            val swatch = TextView(this).apply { text = "●"; textSize = 26f; gravity = Gravity.CENTER; setTextColor(color); contentDescription = name; setOnClickListener { accent = color; prefs.edit().putInt("accent_color", color).apply(); Toast.makeText(this@MainActivity, "$name accent selected", Toast.LENGTH_SHORT).show() } }
            colorRow.addView(swatch, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        panel.addView(colorRow)
        panel.addView(label("UI BACKGROUND THEME", 10f, accent, true).apply { setPadding(0, dp(10), 0, dp(4)) })
        val backgrounds = linkedMapOf("Obsidian Black" to 0xFF050505.toInt(), "Midnight Blue" to 0xFF07111D.toInt(), "Forest Black" to 0xFF07150F.toInt(), "Plum Black" to 0xFF160B18.toInt(), "Warm Charcoal" to 0xFF17120B.toInt(), "Slate" to 0xFF111820.toInt())
        val bgSpinner = Spinner(this)
        bgSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, backgrounds.keys.toList())
        val savedBg = prefs.getInt("ui_background", 0xFF050505.toInt())
        bgSpinner.setSelection(backgrounds.values.indexOf(savedBg).coerceAtLeast(0))
        bgSpinner.setBackgroundColor(0xFF252525.toInt())
        panel.addView(bgSpinner, lp(match, dp(48), 0, 0, 0, 6))
        panel.addView(label("OPENING ANIMATION • 120 PRESETS", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        val animationSpinner = Spinner(this)
        val animationNames = (1..120).map { i -> String.format(Locale.ROOT, "%03d • %s", i, arrayOf("Gold Cinematic", "Neon Orbit", "Particle Storm", "Laser Sweep", "Pulse Reveal", "Prism Burst", "Ring Reactor", "Starlight", "Glitch Flash", "Aurora Flow")[((i - 1) % 10)] + " ${((i - 1) / 10) + 1}") }
        animationSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, animationNames)
        animationSpinner.setSelection(prefs.getInt("opening_animation", 0).coerceIn(0, 119))
        animationSpinner.setBackgroundColor(0xFF252525.toInt())
        panel.addView(animationSpinner, lp(match, dp(48), 0, 0, 0, 6))
        panel.addView(label("OPENING LOOK • THEME MENU", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        val openingThemes = listOf("Gold Cinema", "Ice Neon", "Violet Galaxy", "Crimson Beast", "Emerald Pulse", "Arctic Chrome", "Solar Flare", "Midnight Blue")
        val themeSpinner = Spinner(this)
        themeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, openingThemes)
        themeSpinner.setSelection(prefs.getInt("opening_theme", 0).coerceIn(openingThemes.indices))
        themeSpinner.setBackgroundColor(0xFF252525.toInt())
        panel.addView(themeSpinner, lp(match, dp(48), 0, 0, 0, 6))
        panel.addView(label("OPENING LOGO • CHOOSE BRAND", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        val logoChoices = listOf("PJ TECHS", "PJ", "SHAPE", "JIVA", "NOVA", "ONYX", "AURA", "PULSE", "VOLT", "LUX", "NEXUS", "ORBIT", "PHANTOM", "BEAST", "APEX", "INFINITY")
        val logoSpinner = Spinner(this)
        logoSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, logoChoices)
        logoSpinner.setSelection(logoChoices.indexOf(openingLogo).coerceAtLeast(0))
        logoSpinner.setBackgroundColor(0xFF252525.toInt())
        panel.addView(logoSpinner, lp(match, dp(48), 0, 0, 0, 8))
        val customLogoStatus = TextView(this).apply {
            text = if (prefs.getString("custom_logo_uri", null).isNullOrBlank()) "No custom image selected — using text logo" else "Custom image logo selected ✓"
            textSize = 12f; setTextColor(MUTED); setPadding(dp(2), dp(2), dp(2), dp(6))
        }
        panel.addView(customLogoStatus)
        val customLogoButton = TextView(this).apply {
            text = "▣  CHOOSE CUSTOM LOGO IMAGE"; gravity = Gravity.CENTER; setTextColor(WHITE)
            background = glass(0x442D3038, 14, 0x88FFC56A.toInt()); setPadding(dp(10), dp(13), dp(10), dp(13))
            setOnClickListener { chooseCustomLogo() }
        }
        panel.addView(customLogoButton, lp(match, wrap, 0, 2, 0, 8))
        val clearLogoButton = TextView(this).apply {
            text = "Use text logo instead"; gravity = Gravity.CENTER; setTextColor(MUTED); setPadding(dp(8), dp(6), dp(8), dp(8))
            setOnClickListener { prefs.edit().remove("custom_logo_uri").apply(); customLogoStatus.text = "No custom image selected — using text logo"; Toast.makeText(this@MainActivity, "Custom logo cleared; save settings to apply", Toast.LENGTH_SHORT).show() }
        }
        panel.addView(clearLogoButton)
        panel.addView(label("CINEMATIC INTRO DURATION • SLIDE TO ADJUST", 10f, accent, true).apply { setPadding(0, dp(8), 0, dp(2)) })
        val introDurationLabel = TextView(this).apply { setTextColor(WHITE); textSize = 14f }
        val introDurationSeek = SeekBar(this).apply { max = 29; progress = (prefs.getInt("intro_duration_seconds", 5).coerceIn(1, 30) - 1); progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(accent) }
        introDurationLabel.text = "${introDurationSeek.progress + 1} seconds"
        introDurationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { introDurationLabel.text = "${progress + 1} seconds" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        panel.addView(introDurationLabel); panel.addView(introDurationSeek, lp(match, wrap, 0, 0, 0, 8))
        panel.addView(label("OPENING LOGO SIZE", 10f, accent, true).apply { setPadding(0, dp(4), 0, dp(2)) })
        val logoScaleLabel = TextView(this).apply { setTextColor(WHITE); textSize = 14f }
        val logoScaleSeek = SeekBar(this).apply { max = 100; progress = (prefs.getInt("logo_scale_percent", 100).coerceIn(50, 150) - 50); progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(accent) }
        logoScaleLabel.text = "${logoScaleSeek.progress + 50}%"
        logoScaleSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { logoScaleLabel.text = "${progress + 50}%" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        panel.addView(logoScaleLabel); panel.addView(logoScaleSeek, lp(match, wrap, 0, 0, 0, 8))
        val preview = TextView(this).apply { text = "▶  PREVIEW CINEMATIC OPENING + AUDIO"; gravity = Gravity.CENTER; setTextColor(0xFF090909.toInt()); background = goldButton(); setPadding(dp(10), dp(12), dp(10), dp(12)); setOnClickListener {
            animationStyle = animationSpinner.selectedItemPosition; openingLogo = logoSpinner.selectedItem.toString(); uiBackground = backgrounds.values.toList()[bgSpinner.selectedItemPosition]
            window.statusBarColor = uiBackground; window.navigationBarColor = uiBackground
            val previewDuration = introDurationSeek.progress + 1
            if (prefs.getBoolean("boot_audio_enabled", false)) previewBootAudio(prefs.getInt("boot_audio_seconds", 8).coerceIn(1, 180))
            setContentView(CinematicSplash(this@MainActivity, animationStyle, openingLogo, accent, uiBackground, previewDuration, prefs.getString("custom_logo_uri", null), (logoScaleSeek.progress + 50) / 100f, themeSpinner.selectedItemPosition) { showDashboard() })
        } }
        panel.addView(preview, lp(match, wrap, 0, 2, 0, 8))
        val music = TextView(this).apply { text = "♫  CHOOSE BACKGROUND MUSIC"; gravity = Gravity.CENTER; setTextColor(WHITE); background = glass(0x442D3038, 14, 0x88FFC56A.toInt()); setPadding(dp(10), dp(13), dp(10), dp(13)); setOnClickListener { chooseMusic() } }
        panel.addView(music, lp(match, wrap, 0, 8, 0, 8))
        val stopMusic = TextView(this).apply { text = "■  STOP MUSIC"; gravity = Gravity.CENTER; setTextColor(MUTED); setPadding(dp(10), dp(10), dp(10), dp(10)); setOnClickListener { musicPlayer?.pause(); Toast.makeText(this@MainActivity, "Music paused", Toast.LENGTH_SHORT).show() } }
        panel.addView(stopMusic)
        panel.addView(label("BOOT AUDIO • PLAY DURING OPENING", 10f, accent, true).apply { setPadding(0, dp(12), 0, dp(4)) })
        val bootAudioInfo = TextView(this).apply {
            val selected = prefs.getString("boot_audio_uri", null)
            text = if (selected.isNullOrBlank()) "No boot audio selected. Choose your own ‘One Sun One Moon’ audio file." else "Boot audio file selected ✓"
            textSize = 12f; setTextColor(MUTED); setPadding(dp(2), dp(2), dp(2), dp(8))
        }
        panel.addView(bootAudioInfo)
        val chooseBootAudio = TextView(this).apply {
            text = "♫  CHOOSE BOOT AUDIO FILE"; gravity = Gravity.CENTER; setTextColor(WHITE)
            background = glass(0x442D3038, 14, 0x88FFC56A.toInt()); setPadding(dp(10), dp(13), dp(10), dp(13))
            setOnClickListener { chooseBootAudio() }
        }
        panel.addView(chooseBootAudio, lp(match, wrap, 0, 2, 0, 6))
        val bootAudioEnabled = CheckBox(this).apply {
            text = "Play selected audio when the app opens"; setTextColor(WHITE)
            buttonTintList = ColorStateList.valueOf(accent)
            isChecked = prefs.getBoolean("boot_audio_enabled", false)
        }
        panel.addView(bootAudioEnabled)
        panel.addView(label("AUDIO PLAYBACK DURATION • SLIDE TO ADJUST", 10f, accent, true).apply { setPadding(0, dp(4), 0, dp(2)) })
        val bootDurationLabel = TextView(this).apply { setTextColor(WHITE); textSize = 14f }
        val bootDurationSeek = SeekBar(this).apply { max = 179; progress = prefs.getInt("boot_audio_seconds", 8).coerceIn(1, 180) - 1; progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(accent) }
        bootDurationLabel.text = "${bootDurationSeek.progress + 1} seconds"
        bootDurationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { bootDurationLabel.text = "${progress + 1} seconds" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        panel.addView(bootDurationLabel); panel.addView(bootDurationSeek, lp(match, wrap, 0, 0, 0, 8))
        applyLiquidEffects(panel)
        AlertDialog.Builder(this).setTitle("shape • Customization")
            .setView(ScrollView(this).apply { addView(panel) })
            .setPositiveButton("Save settings") { _, _ ->
                assistantName = assistant.text.toString().trim().ifBlank { "JIVA" }
                animationStyle = animationSpinner.selectedItemPosition
                openingLogo = logoSpinner.selectedItem.toString()
                uiBackground = backgrounds.values.toList()[bgSpinner.selectedItemPosition]
                window.statusBarColor = uiBackground; window.navigationBarColor = uiBackground
                val endpointValue = cloudEndpoint.text.toString().trim().ifBlank { "https://api.openai.com/v1/chat/completions" }
                val modelValue = cloudModel.text.toString().trim().ifBlank { "gpt-4o-mini" }
                if (!endpointValue.startsWith("https://", ignoreCase = true)) {
                    Toast.makeText(this@MainActivity, "Cloud AI endpoint must use HTTPS", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val enteredKey = cloudKey.text.toString().trim()
                if (enteredKey.isNotBlank()) saveCloudApiKey(enteredKey)
                val edit = prefs.edit().putString("assistant_name", assistantName)
                    .putString("cloud_ai_endpoint", endpointValue).putString("cloud_ai_model", modelValue)
                    .putInt("opening_animation", animationStyle).putString("opening_logo", openingLogo)
                    .putInt("intro_duration_seconds", introDurationSeek.progress + 1)
                    .putInt("logo_scale_percent", logoScaleSeek.progress + 50)
                    .putInt("opening_theme", themeSpinner.selectedItemPosition)
                    .putInt("ui_background", uiBackground).putInt("accent_color", accent)
                    .putBoolean("boot_audio_enabled", bootAudioEnabled.isChecked)
                    .putInt("boot_audio_seconds", bootDurationSeek.progress + 1)
                names.forEachIndexed { i, field -> edit.putString("equipment_$i", field.text.toString().trim().ifBlank { equipmentDefaults[i] }) }
                edit.apply(); showDashboard()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun chooseCustomLogo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try { startActivityForResult(intent, 7004) }
        catch (_: Exception) { Toast.makeText(this, "No image picker available", Toast.LENGTH_SHORT).show() }
    }

    private fun chooseMusic() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        try { startActivityForResult(intent, 7001) } catch (_: Exception) { Toast.makeText(this, "No audio picker available", Toast.LENGTH_SHORT).show() }
    }

    private fun previewBootAudio(seconds: Int) {
        val uriText = prefs.getString("boot_audio_uri", null)
        if (uriText.isNullOrBlank()) {
            Toast.makeText(this, "Choose a boot audio file first", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            stopBootAudioTask?.let { mainHandler.removeCallbacks(it) }
            bootAudioPlayer?.release()
            bootAudioPlayer = MediaPlayer().apply {
                setDataSource(this@MainActivity, Uri.parse(uriText))
                isLooping = true
                setOnPreparedListener { player ->
                    player.start()
                    stopBootAudioTask = Runnable { try { if (player.isPlaying) player.pause(); player.seekTo(0) } catch (_: Exception) {} }
                    mainHandler.postDelayed(stopBootAudioTask!!, seconds * 1000L)
                }
                setOnErrorListener { _, _, _ -> Toast.makeText(this@MainActivity, "Unable to preview selected audio", Toast.LENGTH_SHORT).show(); true }
                prepareAsync()
            }
        } catch (_: Exception) { Toast.makeText(this, "Unable to preview selected audio", Toast.LENGTH_SHORT).show() }
    }

    private fun chooseBootAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
        try { startActivityForResult(intent, 7003) } catch (_: Exception) { Toast.makeText(this, "No audio picker available", Toast.LENGTH_SHORT).show() }
    }

    private fun goldButton() = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFFFD783.toInt(), 0xFFC18A36.toInt())).apply { cornerRadius = dp(13).toFloat() }

    private fun showConnectionDialog() {
        val input = EditText(this).apply {
            hint = "192.168.1.50 or 192.168.4.1"
            setText(prefs.getString("esp32_address", "") ?: "")
            setTextColor(WHITE); setHintTextColor(MUTED); setSingleLine(true)
        }
        val status = TextView(this).apply {
            text = "Enter the IP printed by ESP32 Serial Monitor. Direct AP default: 192.168.4.1"
            textSize = 12f; setTextColor(MUTED); setPadding(0, dp(10), 0, dp(8))
        }
        val test = TextView(this).apply {
            text = "  TEST CONNECTION  "; gravity = Gravity.CENTER; setTextColor(BG)
            background = goldButton(); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val save = TextView(this).apply {
            text = "  SAVE ADDRESS  "; gravity = Gravity.CENTER; setTextColor(WHITE)
            background = glass(0x332D3036, 14, 0x887D8794.toInt()); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(test, LinearLayout.LayoutParams(0, wrap, 1f).apply { marginEnd = dp(6) })
        buttons.addView(save, LinearLayout.LayoutParams(0, wrap, 1f).apply { marginStart = dp(6) })
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(4))
            addView(label("ESP32 IP ADDRESS", 10f, accent, true))
            addView(input, lp(match, wrap, 0, 6, 0, 2))
            addView(status, lp(match, wrap, 0, 0, 0, 8))
            addView(buttons, lp(match, wrap))
        }
        val dialog = AlertDialog.Builder(this).setTitle("Connect ESP32")
            .setMessage("Connect the phone and ESP32 to the same Wi-Fi, or use the ESP32 access point if your firmware provides it. This app expects /api/status and /api/relay endpoints.")
            .setView(holder).setNegativeButton("Close", null).create()
        test.setOnClickListener {
            val address = normalizeEsp32Address(input.text.toString())
            if (address.isBlank()) {
                status.text = "Enter an IP address first"; status.setTextColor(0xFFFF8A80.toInt()); return@setOnClickListener
            }
            status.text = "Testing connection…"; status.setTextColor(MUTED)
            esp32Request(address, "/api/status") { success, body ->
                if (success) {
                    prefs.edit().putString("esp32_address", address).apply()
                    esp32Connected = true
                    esp32DashboardButton?.let { button ->
                        button.text = "●  ESP32 CONNECTED  •  MANAGE"
                        button.setTextColor(0xFF9FFFC4.toInt())
                        button.background = glass(0x3335A76B, 15, 0x889FFFC4.toInt())
                    }
                    status.text = "CONNECTED ✓  $address\n${body.take(160)}"
                    status.setTextColor(0xFF9FFFC4.toInt())
                    Toast.makeText(this, "ESP32 connected", Toast.LENGTH_SHORT).show()
                } else {
                    esp32Connected = false
                    esp32DashboardButton?.let { button ->
                        button.text = "⌁  CONNECT ESP32"
                        button.setTextColor(BG)
                        button.background = goldButton()
                    }
                    status.text = "Connection failed: $body\nCheck Wi-Fi, IP and firmware endpoints."
                    status.setTextColor(0xFFFF8A80.toInt())
                }
            }
        }
        save.setOnClickListener {
            val address = normalizeEsp32Address(input.text.toString())
            if (address.isBlank()) {
                status.text = "Enter an IP address first"; status.setTextColor(0xFFFF8A80.toInt())
            } else {
                prefs.edit().putString("esp32_address", address).apply()
                status.text = "Address saved. Tap TEST CONNECTION to verify it."
                status.setTextColor(accent)
                Toast.makeText(this, "ESP32 address saved", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun glass(color: Int, radius: Int, edge: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf((color and 0x00FFFFFF) or 0x663F4854, color, (color and 0x00FFFFFF) or 0x3310141B)).apply {
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), edge)
    }
    private fun lp(w: Int, h: Int, left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { setMargins(dp(left), dp(top), dp(right), dp(bottom)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val match get() = LinearLayout.LayoutParams.MATCH_PARENT
    private val wrap get() = LinearLayout.LayoutParams.WRAP_CONTENT

    /** Cinematic intro: smooth light curtains, ember particles and a configurable duration. */
    private class CinematicSplash(activity: MainActivity, private val style: Int, private val logoText: String, private val accentColor: Int, private val backgroundColor: Int, private val durationSeconds: Int, private val customLogoUri: String?, private val logoScale: Float, private val openingTheme: Int, val done: () -> Unit) : View(activity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val customLogo: Bitmap? = try {
            if (customLogoUri.isNullOrBlank()) null else activity.contentResolver.openInputStream(Uri.parse(customLogoUri))?.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null }
        private var progress = 0f
        private val themeAccent = intArrayOf(0xFFFFC56A.toInt(), 0xFF64E7FF.toInt(), 0xFFB99AFF.toInt(), 0xFFFF4D6D.toInt(), 0xFF65E6B3.toInt(), 0xFFEAF5FF.toInt(), 0xFFFF8C42.toInt(), 0xFF6BA9FF.toInt())[openingTheme.coerceIn(0, 7)]
        private val gold = if (openingTheme == 0) accentColor else themeAccent
        private val red = intArrayOf(0xFFB8873E.toInt(), 0xFF54C9FF.toInt(), 0xFF9A69FF.toInt(), 0xFFFF4D6D.toInt(), 0xFF65E6B3.toInt(), 0xFFB9D9FF.toInt(), 0xFFFF8C42.toInt(), 0xFF6BA9FF.toInt())[openingTheme.coerceIn(0, 7)]
        private val ember = intArrayOf(0xFFEEE4D3.toInt(), 0xFFDDFBFF.toInt(), 0xFFE8DEFF.toInt(), 0xFFFFDDE3.toInt(), 0xFFD9FFED.toInt(), 0xFFF4FAFF.toInt(), 0xFFFFE5C9.toInt(), 0xFFDCEBFF.toInt())[openingTheme.coerceIn(0, 7)]
        private val particleX = FloatArray(64) { ((it * 83 + 37) % 997) / 997f }
        private val particleY = FloatArray(64) { ((it * 149 + 13) % 991) / 991f }
        private val particleSize = FloatArray(64) { 1f + ((it * 11) % 4) }
        private var finished = false
        private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationSeconds.coerceIn(1, 30) * 1000L
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { if (!finished) { finished = true; done() } }
            })
        }
        init {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            post { if (isAttachedToWindow && !finished) animator.start() }
            setOnClickListener { finishNow() }
        }
        private fun finishNow() {
            if (finished) return
            finished = true
            if (animator.isRunning) animator.cancel()
            done()
        }
        override fun onDetachedFromWindow() {
            if (animator.isRunning) animator.cancel()
            super.onDetachedFromWindow()
        }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2f; val cy = h * .445f
            canvas.drawColor(backgroundColor)
            p.shader = RadialGradient(cx, cy, w * .9f, intArrayOf((themeAccent and 0x00FFFFFF) or 0x33202020, 0xFF101010.toInt(), 0xFF030303.toInt()), floatArrayOf(0f, .48f, 1f), Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            // Deep-red cinematic light curtains slide across the screen.
            for (i in 0..3) {
                val drift = (progress * 1.25f + i * .29f) % 1.7f
                val x = w * (drift - .28f)
                p.shader = LinearGradient(x - w*.16f, 0f, x + w*.16f, h,
                    intArrayOf(0x00000000, if (i % 2 == 0) 0x33FFC56A else 0x33B8873E, 0x00000000), null, Shader.TileMode.CLAMP)
                canvas.save(); canvas.rotate(-11f, cx, cy); canvas.drawRect(x-w*.16f, 0f, x+w*.16f, h, p); canvas.restore(); p.shader = null
            }
            // Floating ember particles.
            for (i in particleX.indices) {
                val x = particleX[i] * w + sin(progress * 6f + i).toFloat() * w * .018f
                val y = h * (1f - ((particleY[i] + progress * (.2f + (i % 6) * .025f)) % 1f))
                val flicker = .22f + .78f * abs(sin(progress * 17f + i)).toFloat()
                p.color = when (i % 3) { 0 -> gold; 1 -> red; else -> ember }
                p.alpha = (210 * flicker).toInt()
                canvas.drawCircle(x, y, dp(particleSize[i].toInt().coerceAtLeast(1)).toFloat() * flicker, p)
            }
            p.alpha = 255
            // Thin ice-blue corner marks draw in like a glass-tech frame.
            val frame = ((progress - .04f) / .26f).coerceIn(0f, 1f)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(1).toFloat(); p.color = gold; p.alpha = (190 * frame).toInt()
            val inset = w * (.09f + .035f * (1f-frame)); val top = h*.20f; val bottom = h*.72f; val len = w*.15f*frame
            canvas.drawLine(inset,top,inset+len,top,p); canvas.drawLine(inset,top,inset,top+len,p)
            canvas.drawLine(w-inset,top,w-inset-len,top,p); canvas.drawLine(w-inset,top,w-inset,top+len,p)
            canvas.drawLine(inset,bottom,inset+len,bottom,p); canvas.drawLine(inset,bottom,inset,bottom-len,p)
            canvas.drawLine(w-inset,bottom,w-inset-len,bottom,p); canvas.drawLine(w-inset,bottom,w-inset,bottom-len,p)
            p.style = Paint.Style.FILL; p.alpha = 255
            // Two rotating rings form a clean tech insignia behind the logo.
            val reveal = ((progress-.10f)/.34f).coerceIn(0f,1f)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2).toFloat(); p.color = gold; p.alpha = (215*reveal).toInt(); p.setShadowLayer(dp(9).toFloat(),0f,0f,gold)
            canvas.drawArc(cx-w*.31f,cy-w*.31f,cx+w*.31f,cy+w*.31f,-100f+progress*(100f + (style % 12) * 20f),280f*reveal,false,p)
            p.clearShadowLayer(); p.color = red; p.alpha = (190*reveal).toInt(); p.strokeWidth = dp(1).toFloat()
            canvas.drawArc(cx-w*.35f,cy-w*.35f,cx+w*.35f,cy+w*.35f,70f-progress*120f,95f*reveal,false,p)
            p.style = Paint.Style.FILL; p.alpha = 255
            // A cool holographic flash as the title locks into place.
            val flash = if (progress in .42f.. .49f) 1f-abs(progress-.455f)/.035f else 0f
            if (flash > 0f) { p.color = 0xFFE8FAFF.toInt(); p.alpha = (flash*95).toInt(); canvas.drawRect(0f,0f,w,h,p); p.alpha=255 }
            val titleAlpha = ((progress-.23f)/.28f).coerceIn(0f,1f)
            val scale = (.68f + .32f*DecelerateInterpolator().getInterpolation(titleAlpha)) * (if (progress in .40f.. .53f) 1f+.022f*(1f-abs(progress-.465f)/.065f) else 1f)
            canvas.save(); canvas.scale(scale,scale,cx,cy)
            if (customLogo != null && !customLogo.isRecycled) {
                val maxW = w * .64f * logoScale.coerceIn(.5f, 1.5f); val maxH = w * .48f * logoScale.coerceIn(.5f, 1.5f)
                val factor = minOf(maxW / customLogo.width, maxH / customLogo.height)
                val dw = customLogo.width * factor; val dh = customLogo.height * factor
                val dst = RectF(cx - dw/2f, cy - dh/2f, cx + dw/2f, cy + dh/2f)
                p.alpha = (255*titleAlpha).toInt(); p.setShadowLayer(dp(14).toFloat(), 0f, dp(2).toFloat(), gold)
                canvas.drawBitmap(customLogo, null, dst, p); p.clearShadowLayer(); p.alpha = 255
            } else {
                p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.create("sans-serif-black",Typeface.BOLD); p.textSize = w*.137f
                p.color = red; p.alpha = (170*titleAlpha).toInt(); p.setShadowLayer(dp(13).toFloat(),0f,dp(2).toFloat(),red); canvas.drawText(logoText,cx+dp(2),cy+dp(8),p); p.clearShadowLayer()
                p.shader = LinearGradient(cx,cy-w*.10f,cx,cy+w*.02f,intArrayOf(0xFFFFFFFF.toInt(),(gold and 0x00FFFFFF) or 0xFF000000.toInt(),(red and 0x00FFFFFF) or 0xFF000000.toInt(),0xFFFFF5DB.toInt()),null,Shader.TileMode.CLAMP)
                p.alpha = (255*titleAlpha).toInt(); canvas.drawText(logoText,cx,cy+dp(5),p); p.shader=null
            }
            // Brief horizontal light streaks give the title a sharp cinematic finish.
            if (progress in .38f.. .58f) {
                val gp=(progress-.38f)/.20f; p.alpha=(150*(1f-abs(gp-.5f)*2f)).toInt(); p.color=gold
                canvas.drawRect(cx-w*.39f,cy-w*.075f,cx-w*.18f,cy-w*.068f,p)
                p.color=red; canvas.drawRect(cx+w*.17f,cy+w*.015f,cx+w*.39f,cy+w*.022f,p)
            }
            canvas.restore(); p.alpha=255
            val line=((progress-.51f)/.16f).coerceIn(0f,1f)
            p.shader=LinearGradient(cx-w*.28f,cy+w*.105f,cx+w*.28f,cy+w*.105f,intArrayOf(0x00FFC56A,gold,red,0x00ED593D),null,Shader.TileMode.CLAMP)
            canvas.drawRect(cx-w*.28f,cy+w*.105f,cx-w*.28f+w*.56f*line,cy+w*.109f,p); p.shader=null
            p.textAlign=Paint.Align.CENTER; p.typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL); p.textSize=w*.027f; p.color=WHITE
            p.alpha=(235*((progress-.56f)/.19f).coerceIn(0f,1f)).toInt(); canvas.drawText("${arrayOf("GOLD CINEMA", "ICE NEON", "VIOLET GALAXY", "CRIMSON BEAST", "EMERALD PULSE", "ARCTIC CHROME", "SOLAR FLARE", "MIDNIGHT BLUE")[openingTheme.coerceIn(0, 7)]}  •  SMART CONTROL",cx,cy+w*.17f,p)
            p.textSize=w*.026f; p.color=gold; p.alpha=(230*((progress-.70f)/.18f).coerceIn(0f,1f)).toInt(); canvas.drawText("$logoText  •  POWERED BY JIVA",cx,h*.82f,p)
            p.textSize=w*.023f; p.color=0xFFB7C0CA.toInt(); p.alpha=(145*(1f-progress)).toInt(); canvas.drawText("TAP TO ENTER",cx,h*.92f,p)
            p.alpha=255
        }
        private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    }
}


/** Animated black-glass / gold power switch used by the four dashboard device cards. */
private class PremiumPowerSwitch(context: android.content.Context, private val accentColor: Int) : View(context) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var position = 0f
    var isOn: Boolean = false
        set(value) {
            field = value
            val target = if (value) 1f else 0f
            ValueAnimator.ofFloat(position, target).apply {
                duration = 220L
                interpolator = DecelerateInterpolator()
                addUpdateListener { position = it.animatedValue as Float; invalidate() }
                start()
            }
            contentDescription = if (value) "Power on" else "Power off"
        }

    init {
        isClickable = true
        isFocusable = true
        position = 0f
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (62 * density).toInt()
        val h = (31 * density).toInt()
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        val pad = 1.5f * density
        val track = RectF(pad, pad, w - pad, h - pad)
        val gold = if (accentColor != 0) accentColor else 0xFFFFC56A.toInt()
        paint.style = Paint.Style.FILL
        paint.shader = if (position > .01f) LinearGradient(0f, 0f, w, h, intArrayOf(0xFF332414.toInt(), (gold and 0x00FFFFFF) or 0xFF000000.toInt()), null, Shader.TileMode.CLAMP) else null
        paint.color = if (position > .01f) gold else 0xFF202329.toInt()
        canvas.drawRoundRect(track, h / 2f, h / 2f, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = density
        paint.color = if (position > .5f) (gold and 0x00FFFFFF) or 0xFF000000.toInt() else 0xFF626A75.toInt()
        canvas.drawRoundRect(track, h / 2f, h / 2f, paint)
        paint.style = Paint.Style.FILL
        val radius = h * .36f
        val left = h / 2f + 2f * density
        val right = w - h / 2f - 2f * density
        val cx = left + (right - left) * position
        val cy = h / 2f
        if (position > .05f) {
            paint.setShadowLayer(7f * density, 0f, 0f, gold)
        }
        paint.color = if (position > .5f) 0xFFFFF7E5.toInt() else 0xFFB7BEC8.toInt()
        canvas.drawCircle(cx, cy, radius, paint)
        paint.clearShadowLayer()
        paint.color = if (position > .5f) 0xFF6D4A13.toInt() else 0xFF555C66.toInt()
        paint.textSize = 7f * density
        paint.typeface = Typeface.create("sans-serif-bold", Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(if (position > .5f) "ON" else "OFF", if (position > .5f) w * .27f else w * .73f, cy + 2.5f * density, paint)
    }
}
