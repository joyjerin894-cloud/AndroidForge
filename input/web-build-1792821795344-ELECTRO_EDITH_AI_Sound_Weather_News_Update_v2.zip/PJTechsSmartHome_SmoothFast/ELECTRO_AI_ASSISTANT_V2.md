# ELECTRO AI Assistant v2

## What this update does
- Android voice input uses the phone's speech-recognition service; responses can be spoken using Android text-to-speech.
- When the user says an explicit command such as “turn on living room”, “turn off relay 2”, “turn on all” or “turn off all”, the app sends a real command to the configured ESP32 address and reports success only after an HTTP success response.
- Optional “Confirm relay actions” setting can require confirmation before sending commands.
- Other questions go to the configured OpenAI-compatible cloud chat endpoint if an API key is configured. The app does not include a free API key; providers may require billing and model-specific endpoints/keys.
- `ELECTRO_ESP32_S3_AI_Companion.ino` provides the HTTP API used by the app and a Wi-Fi AP fallback.

## Setup
1. In Arduino IDE install ESP32 board support. No extra Arduino library is required for this sketch.
2. Open `ELECTRO_ESP32_S3_AI_Companion.ino`.
3. Set `WIFI_SSID` and `WIFI_PASSWORD`. If station Wi-Fi fails, it creates `ELECTRO-Setup` with password `electro123`; change this password before use.
4. Verify `RELAY_PINS` and `RELAY_ACTIVE_LOW` for your exact board/module. The pins in this example are provisional and must not be assumed safe for your hardware.
5. Flash the firmware and open Serial Monitor at 115200 baud to find the board IP.
6. In ELECTRO app, open Connect ESP32 and enter the printed IP (or `192.168.4.1` while connected to its AP).
7. In Customization Settings, set a compatible HTTPS AI endpoint, model name and your own API key for cloud Q&A.
8. In Voice, tap Speak and say a command. Android speech recognition availability and language depend on the phone.

## Limits / safety
This is Alexa-like phone-mediated control, not a fully standalone always-listening ESP32 wake-word assistant. The INMP441 microphone alone does not provide wake-word detection, speech-to-text or cloud AI. A separate ESP-SR/ESP-IDF wake-word pipeline or a secure speech service would be needed for hands-free operation when the phone is not listening. Keep this HTTP control endpoint on a trusted local network; it has no authentication and must not be port-forwarded to the internet. Do not switch mains loads until relay isolation, ratings, enclosure, fusing and wiring are verified by a qualified person.
