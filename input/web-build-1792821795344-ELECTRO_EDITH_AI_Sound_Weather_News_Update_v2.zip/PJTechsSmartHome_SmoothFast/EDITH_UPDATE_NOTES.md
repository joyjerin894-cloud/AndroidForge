# EDITH assistant update

- Default assistant name changed from JIVA to EDITH (existing saved custom names remain respected).
- Added the newly uploaded “EDITH — Even Dead I’m The Hero” MP3 as the assistant reply sound effect. The sound is bundled as `app/src/main/res/raw/edith_ai_sound.mp3`.
- Added local current time/date answers.
- Added current weather lookup using the free Open-Meteo geocoding and forecast endpoints; supports prompts such as `weather in Kochi`. If no city is specified, it uses Irinjalakuda as the default location and can be changed in the prompt.
- Added India headlines using Google News RSS. These features require internet access.
- Existing cloud AI request code was not changed by this update; Gemini 401 errors may still require fixing its endpoint/request format.

## Rebuild
Upload this ZIP to your AndroidForge repository or replace the matching project files, then run the existing GitHub Actions APK build workflow. The MP3 is included under `app/src/main/res/raw/edith_ai_sound.mp3`.
