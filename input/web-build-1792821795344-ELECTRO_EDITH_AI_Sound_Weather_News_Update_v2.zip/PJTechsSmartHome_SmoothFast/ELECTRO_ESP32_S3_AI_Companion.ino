/* ELECTRO Smart Home - ESP32-S3 companion firmware (Arduino IDE)
 * App API: GET /api/status and GET /api/relay?id=1&state=on|off
 * IMPORTANT: Confirm your relay board's input voltage, active polarity, and GPIOs
 * before connecting loads. This sketch is not an always-listening wake-word AI engine.
 * The Android app handles speech recognition / cloud conversation and sends commands
 * over Wi-Fi. Do not expose this unauthenticated HTTP API to the public internet.
 */
#include <WiFi.h>
#include <WebServer.h>

const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* AP_SSID = "ELECTRO-Setup";
const char* AP_PASSWORD = "electro123"; // Change before use; minimum 8 chars.

// PROVISIONAL pins only. Verify the exact ESP32-S3 Super Mini pinout and relay board.
const uint8_t RELAY_PINS[4] = {4, 5, 6, 7};
const bool RELAY_ACTIVE_LOW = true;
bool relayOn[4] = {false, false, false, false};
WebServer server(80);

void writeRelay(uint8_t index, bool on) {
  relayOn[index] = on;
  digitalWrite(RELAY_PINS[index], RELAY_ACTIVE_LOW ? (on ? LOW : HIGH) : (on ? HIGH : LOW));
}

void sendStatus() {
  String out = "{\"connected\":true,\"relays\":[";
  for (uint8_t i = 0; i < 4; ++i) {
    if (i) out += ",";
    out += relayOn[i] ? "true" : "false";
  }
  out += "]}";
  server.send(200, "application/json", out);
}

void handleRelay() {
  if (!server.hasArg("id") || !server.hasArg("state")) {
    server.send(400, "application/json", "{\"error\":\"Use id=1..4 and state=on|off\"}");
    return;
  }
  int id = server.arg("id").toInt();
  String state = server.arg("state"); state.toLowerCase();
  if (id < 1 || id > 4 || (state != "on" && state != "off")) {
    server.send(400, "application/json", "{\"error\":\"Invalid relay id or state\"}");
    return;
  }
  writeRelay((uint8_t)(id - 1), state == "on");
  sendStatus();
}

void setup() {
  Serial.begin(115200);
  for (uint8_t i = 0; i < 4; ++i) {
    pinMode(RELAY_PINS[i], OUTPUT);
    writeRelay(i, false); // Keep all relay outputs OFF at startup.
  }
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
    delay(300); Serial.print('.');
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("\nELECTRO IP: "); Serial.println(WiFi.localIP());
  } else {
    WiFi.mode(WIFI_AP);
    WiFi.softAP(AP_SSID, AP_PASSWORD);
    Serial.print("\nELECTRO AP IP: "); Serial.println(WiFi.softAPIP());
    Serial.println("Connect phone to ELECTRO-Setup; password electro123 (change it first).");
  }
  server.on("/", HTTP_GET, []() {
    server.send(200, "text/plain", "ELECTRO ESP32-S3 ready. Use /api/status or /api/relay?id=1&state=on");
  });
  server.on("/api/status", HTTP_GET, sendStatus);
  server.on("/api/relay", HTTP_GET, handleRelay);
  server.onNotFound([]() { server.send(404, "application/json", "{\"error\":\"not found\"}"); });
  server.begin();
}

void loop() { server.handleClient(); }
