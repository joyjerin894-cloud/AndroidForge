# PJ Techs Smart Home — Neon Cinematic Android Studio Project

A native Kotlin Android project with a colorful, premium-feeling smart-home dashboard and an original cinematic PJ TECHS opening.

## Visual update
- Neon cyan, violet, pink and amber accents over a deep midnight interface.
- Layered gradient panels, device cards, status indicator, JIVA voice-command sample panel and ESP32 setup entry point.
- Original 5.2-second title-card animation with floating particles, diagonal light beams, energy rings, metallic lettering, glitch accents, and an impact flash.
- Canvas animation is rendered at the device's screen resolution. Tap the intro to skip it.
- Java and Kotlin compile targets are both set to JVM 17 for GitHub Actions compatibility.

The intro uses broad action-cinema visual language, not a direct recreation of *Beast*, its exact title design, footage, or soundtrack.

## Build the APK
1. Extract this ZIP.
2. Open the extracted project folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by the project if prompted.
4. Select **Build → Build APK(s)**.
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

You can also upload/replace the project files in your GitHub repository and run the existing Actions workflow.

## Important functionality note
The quick device cards currently toggle demo states locally. The JIVA panel shows sample commands, and the ESP32 dialog is a setup placeholder. Real voice recognition, saving the ESP32 address, and relay API communication still need to be implemented and tested before controlling physical hardware.

No prebuilt APK is included. The ZIP is kept compact because the intro is drawn by code; adding unrelated padding files would not improve animation quality.
